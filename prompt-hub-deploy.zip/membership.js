/**
 * 会员状态、档位与置顶配额（本地 + 云同步 account 字段）
 */
(function () {
  const LS_MEMBERSHIP = 'promptrepo_membership';
  const PIN_LIMIT_FREE = 2;
  const PIN_LIMIT_BASIC = 3;

  /** 会员生图积分折扣（乘数） */
  const GEN_DISCOUNT_BY_TIER = {
    basic: 0.9,
    standard: 0.8,
    pro: 0.7
  };

  function loadJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function saveJson(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
  }

  function accountKey() {
    const uid = window.SupabaseSync?.getUserId?.();
    return uid || 'guest';
  }

  function readRow() {
    const all = loadJson(LS_MEMBERSHIP, {});
    const row = all[accountKey()];
    if (!row || typeof row !== 'object') return { active: false, until: null, tier: null };
    return {
      active: !!row.active,
      until: row.until || null,
      tier: row.tier || null
    };
  }

  function writeRow(row) {
    const all = loadJson(LS_MEMBERSHIP, {});
    all[accountKey()] = row;
    saveJson(LS_MEMBERSHIP, all);
  }

  function isMember() {
    const row = readRow();
    if (!row.active) return false;
    if (row.until && Date.now() > row.until) {
      writeRow({ active: false, until: null, tier: null });
      return false;
    }
    return true;
  }

  function getMemberTier() {
    if (!isMember()) return null;
    const tier = readRow().tier;
    if (tier === 'basic' || tier === 'standard' || tier === 'pro') return tier;
    return 'basic';
  }

  function getGenDiscountMultiplier() {
    const tier = getMemberTier();
    if (!tier) return 1;
    return GEN_DISCOUNT_BY_TIER[tier] ?? 1;
  }

  function getGenDiscountLabel() {
    const tier = getMemberTier();
    if (!tier) return '';
    const map = { basic: '9折', standard: '8折', pro: '7折' };
    return map[tier] || '';
  }

  function getPinLimit() {
    const tier = getMemberTier();
    if (!tier) return PIN_LIMIT_FREE;
    if (tier === 'basic') return PIN_LIMIT_BASIC;
    if (tier === 'standard' || tier === 'pro') return Infinity;
    return PIN_LIMIT_BASIC;
  }

  function isUnlimitedPins() {
    const tier = getMemberTier();
    return tier === 'standard' || tier === 'pro';
  }

  function activateByCode() {
    return null;
  }

  function isMemberCode() {
    return false;
  }

  function getAccountPayload() {
    const row = readRow();
    return {
      isMember: isMember(),
      until: row.until || null,
      tier: getMemberTier()
    };
  }

  function syncFromPayload(account) {
    if (!account || typeof account !== 'object') return;
    if (account.isMember) {
      writeRow({
        active: true,
        until: account.until || null,
        tier: account.tier || 'basic'
      });
    }
  }

  function getMembershipDisplay() {
    if (!isMember()) {
      return {
        active: false,
        tierLabel: '免费用户',
        untilLabel: '',
        summary: '未开通 · 完成任务可免费领会员'
      };
    }
    const row = readRow();
    const tierLabels = { basic: '基础会员', standard: '标准会员', pro: '专业会员' };
    const tierLabel = tierLabels[row.tier] || '基础会员';
    let untilLabel = '长期有效';
    if (row.until) {
      const d = new Date(row.until);
      untilLabel = `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} 到期`;
    }
    return {
      active: true,
      tierLabel,
      untilLabel,
      summary: `${tierLabel} · ${untilLabel}`
    };
  }

  /** 与 GET /api/v1/me 的 membership 字段对齐 */
  function applyServerState(membership) {
    if (!membership || typeof membership !== 'object') return;
    if (membership.active && membership.tier) {
      const untilMs = membership.until
        ? new Date(membership.until).getTime()
        : null;
      writeRow({
        active: true,
        until: untilMs,
        tier: membership.tier
      });
      if (typeof window.updateImageGenPricingUI === 'function') {
        window.updateImageGenPricingUI();
      }
      window.SubscriptionUI?.refreshOfferUI?.();
      return;
    }
    writeRow({ active: false, until: null, tier: null });
    if (typeof window.updateImageGenPricingUI === 'function') {
      window.updateImageGenPricingUI();
    }
    window.SubscriptionUI?.refreshOfferUI?.();
  }

  function onAccountSwitch() {}

  window.Membership = {
    PIN_LIMIT_FREE,
    PIN_LIMIT_BASIC,
    GEN_DISCOUNT_BY_TIER,
    isMember,
    getMemberTier,
    getGenDiscountMultiplier,
    getGenDiscountLabel,
    getPinLimit,
    isUnlimitedPins,
    activateByCode,
    isMemberCode,
    getAccountPayload,
    syncFromPayload,
    applyServerState,
    getMembershipDisplay,
    onAccountSwitch
  };
})();
