
  function isGeneratedWarehouseCard(card) {
    if (!card) return false;
    const tags = Array.isArray(card.tags) ? card.tags : [];
    if (tags.includes('图片生成')) return true;
    const inspireTag = window.INSPIRE_DRAW_TAG || '灵感抽卡';
    if (tags.includes(inspireTag)) return true;
    return !!(card.genJobId || card.genSourceId);
  }


  function recordCreationDeletion(id, jobId) {
    if (id == null) return;
    try {
      const key = 'promptrepo_deleted_creations';
      const raw = localStorage.getItem(key);
      const map = raw ? JSON.parse(raw) : {};
      map[String(id)] = Date.now();
      localStorage.setItem(key, JSON.stringify(map));
    } catch (e) { /* ignore */ }
    if (typeof window.recordCreationDeletionGlobal === 'function') {
      window.recordCreationDeletionGlobal(id, jobId);
    }
  }


  function highlightCreationCard(id) {
    document.querySelectorAll('#creationsGrid .creation-post-card').forEach(el => {
      el.classList.toggle('selected', el.dataset.creationId === id);
    });
  }


  function openCreationsSidePanel(id) {
    const c = creations.find(x => x.id === id);
    if (!c) return;
    creationsSideId = id;
    ensureFeatureSidePanelDocked('creationsSidePanel');
    mountFeatureSidePanel('creationsSidePanel');
    document.getElementById('creationsSidePanel')?.classList.remove('hidden');
    syncCommunityPanelOpenClass();
    if (isMobileViewport()) window.MobileUI?.closeDrawers?.();
    void renderCreationsSidePanel(id);
    if (!isMobileViewport()) {
      relayoutFeedGridAfterSidePanel('creationsGrid');
      requestAnimationFrame(() => relayoutFeedGridAfterSidePanel('creationsGrid'));
    }
  }


  async function renderCreationsSidePanel(id) {
    const body = document.getElementById('creationsSideBody');
    const c = creations.find(x => x.id === id);
    if (!body || !c) return;
    const badge = c.visibility === 'published' ? '已发布' : '私密';
    const storageAttr = feedImgStorageAttr(c.image);
    const jobAttr = c.jobId ? ` data-job-id="${esc(c.jobId)}"` : '';
    const showImg = c.image && isDisplayableImage(c.image);
    const imgHtml = showImg
      ? `<button type="button" class="community-side-img-btn" data-side-zoom title="点击放大"><img class="community-side-img" src="${IMG_LOADING_PLACEHOLDER}" data-image-ref="${esc(c.image)}"${storageAttr}${jobAttr} alt=""></button>`
      : '';
    body.innerHTML = `
      ${imgHtml}
      <p class="community-side-author">${esc(badge)} · ${esc((c.resolution || '1k').toUpperCase())} · ${esc(formatExpiryLabel(c))}</p>
      <div class="community-side-prompt">${esc(c.prompt || '')}</div>
      <div class="community-side-actions">
        <button type="button" class="btn btn-secondary" data-action="remix">再生成</button>
        <button type="button" class="btn btn-secondary" data-action="del">删除记录</button>
      </div>
      <p class="panel-hint">生成记录保留 1～3 天。发布到社区请打开卡片库对应卡片并开启「发布到提示词社区」</p>`;
    bindCommunitySideImageZoom(body, null, c.image, id, { jobId: c.jobId || null });
    body.querySelector('[data-action="remix"]')?.addEventListener('click', () => remixCreation(id));
    body.querySelector('[data-action="del"]')?.addEventListener('click', () => {
      const doDel = () => {
        deleteCreation(id);
        closeCreationsSidePanel();
      };
      if (typeof window.customConfirm === 'function') {
        window.customConfirm('确定删除该创作？无回收站，删除后不可恢复。', doDel);
      } else if (confirm('确定删除该创作？')) doDel();
    });
    highlightCreationCard(id);
    if (showImg) await hydrateFeedImages(body);
  }


  function closeCreationsSidePanel() {
    document.getElementById('creationsSidePanel')?.classList.add('hidden');
    unmountFeatureSidePanel('creationsSidePanel');
    ensureFeatureSidePanelDocked('creationsSidePanel');
    syncCommunityPanelOpenClass();
    creationsSideId = null;
    communitySidePostId = null;
    openPostId = null;
    document.querySelectorAll('#creationsGrid .community-post-card.selected').forEach(el => el.classList.remove('selected'));
    if (!isMobileViewport()) {
      requestAnimationFrame(() => {
        scheduleCommunityLayout('creationsGrid', { force: true, immediate: true });
      });
    }
  }


  async function renderCreations() {
    renderMyHomeProfile();
    const container = document.getElementById('creationsGrid');
    const hintEl = document.getElementById('creationsHint');
    if (!container) return;
    const user = getActiveUser();
    if (window.__promptHubCards?.length) {
      ensureCommunityFromCardsThrottled(false);
    } else {
      dedupeCommunityPosts();
      migrateCommunityAuthorIds();
    }
    if (hintEl) {
      hintEl.textContent = user.id === 'guest'
        ? '登录后在此查看你发布到社区的作品'
        : '你在卡片库公开到社区的作品 · 按最新发布排序 · 点击卡片查看详情';
    }
    if (user.id === 'guest') {
      window.FeedLayout?.destroyLayout?.('creationsGrid');
      closeCreationsSidePanel();
      container.innerHTML = '<div class="feature-empty"><p>请先登录后查看发布作品</p><button type="button" class="btn btn-primary" onclick="openAuthModal()">登录</button></div>';
      return;
    }
    const list = getMyPublishedPosts();
    const sig = feedListSignature(list, 'creationsGrid');
    if (container.dataset.feedSig === sig && container.querySelector('.community-post-card')) {
      patchFeedLikeLabels(container, list);
      if (isCreationsFeedLayoutStale(container)) {
        delete container.dataset.feedSig;
        delete container.dataset.feedDistributed;
        delete container.dataset.feedDistributedCols;
        repairCreationsFeedLayout(true);
      } else {
        requestAnimationFrame(() => syncCommunityFeedColumnCount('creationsGrid'));
      }
      return;
    }
    renderLikeRewardRules();
    window.FeedLayout?.destroyLayout?.('creationsGrid');
    if (!list.length) {
      closeCreationsSidePanel();
      container.innerHTML = '<div class="feature-empty"><p>暂无发布作品</p><p class="panel-hint">在卡片库保存作品并开启「发布到提示词社区」，或在生图页开启「生成后公开」</p><button type="button" class="btn btn-primary" onclick="switchAppPage(\'warehouse\')">去卡片库</button></div>';
      return;
    }
    void renderPostsIntoContainer(list, 'creationsGrid').then(() => {
      if (useFeedPagedRender('creationsGrid')) {
        void drainCommunityFeedPages('creationsGrid', isMobileViewport() ? 8 : 6);
      }
      requestAnimationFrame(() => {
        layoutFeedFlexColumns('creationsGrid', { force: true, forceReflow: true, recalcCols: true });
        syncCommunityFeedColumnCount('creationsGrid');
      });
    });
  }


  function publishCreation(id, opts) {
    toast('发布到社区请先在卡片库保存该作品，并开启「发布到提示词社区」');
  }


  function confirmDeleteCreation(id) {
    const msg = '确定删除该生成记录？无回收站，删除后不可恢复。';
    const doDel = () => deleteCreation(id);
    if (typeof window.customConfirm === 'function') {
      window.customConfirm(msg, doDel, null, { danger: true, confirmLabel: '删除' });
    } else if (confirm(msg)) doDel();
  }


  function deleteCreation(id) {
    if (creationsSideId === id) closeCreationsSidePanel();
    if (imageGenPreviewId === id) closeImageGenPreview();
    const removed = creations.find(c => c.id === id);
    if (removed?.communityPostId) {
      const post = findPost(removed.communityPostId);
      if (post?.sourceCreationId === id && !post?.sourceCardId) {
        performCommunityPostRemoval(removed.communityPostId, { silent: true });
      }
    }
    recordCreationDeletion(id, removed?.jobId);
    const baseJobId = normalizeGenJobBaseId(removed?.jobId);
    if (baseJobId) {
      window.recordGenerationJobDeletion?.(baseJobId);
      if (removed?.jobId && String(removed.jobId) !== baseJobId) {
        window.recordGenerationJobDeletion?.(removed.jobId);
      }
      const whCards = (window.__promptHubCards || []).filter((c) => {
        if (!c?.genJobId) return false;
        const cBase = normalizeGenJobBaseId(c.genJobId);
        return c.genJobId === removed.jobId || cBase === baseJobId;
      });
      for (const wh of whCards) {
        if (typeof window.deleteCardPermanently === 'function') {
          void window.deleteCardPermanently(wh.id, false, { skipRender: true, silent: true });
        }
      }
    }
    creations = creations.filter(c => c.id !== id);
    persistCreations();
    renderCreations();
    if (document.getElementById('pageImageGen')?.classList.contains('active')) {
      renderImageGenFeed();
    }
    toast('已删除');
  }


  function remixCreation(id) {
    const c = creations.find(x => x.id === id);
    if (!c) return;
    if (typeof switchAppPage === 'function') switchAppPage('imagegen');
    imageGenFeedTab = 'warehouse';
    document.querySelectorAll('[data-feed-tab]').forEach(b => {
      b.classList.toggle('active', b.dataset.feedTab === 'warehouse');
    });
    updateImageGenFeedHint();
    applyHistoryToForm(c);
  }