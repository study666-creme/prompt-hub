/**
 * 生图卡列表缩略图：优先 CDN batch 签 grid；warehouse-thumbs 仅补缺归档的极少数卡。
 */
(function () {
  'use strict';

  const cache = new Map();
  const inflight = new Map();
  let pending = [];
  let flushTimer = null;
  const MAX_BATCH = 4;
  const BATCH_DELAY_MS = 80;
  let thumb503CooldownUntil = 0;
  let thumb503Strike = 0;

  function mobileBatchTuning() {
    const p = window.MobileUI?.getPerf?.();
    if (!p) return { delay: BATCH_DELAY_MS, max: MAX_BATCH };
    return { delay: p.warehouseThumbDelay ?? BATCH_DELAY_MS, max: p.warehouseThumbBatch ?? MAX_BATCH };
  }

  function slotJobId(baseJobId, slot) {
    const base = String(baseJobId || '').replace(/#\d+$/, '');
    if (!Number.isFinite(slot) || slot <= 0) return base;
    return `${base}#${slot + 1}`;
  }

  function cacheKey(jobId, slot) {
    return `${String(jobId || '').replace(/#\d+$/, '')}:${Number(slot) || 0}`;
  }

  function gallerySlotFromJobId(jobId) {
    const m = String(jobId || '').match(/#(\d+)$/);
    if (!m) return 0;
    const n = Number(m[1]);
    return Number.isFinite(n) && n > 1 ? n - 1 : 0;
  }

  function isGridUrl(url) {
    return !!(url && window.SupabaseSync?.isGridDisplayUrl?.(url));
  }

  function cachedGridUrl(image, assetId, jobId, slot) {
    const base = String(jobId || '').replace(/#\d+$/, '');
    const ck = cacheKey(base, slot);
    if (cache.has(ck)) return cache.get(ck);
    if (assetId && window.SupabaseSync?.getListDisplayImageSrc) {
      const url = window.SupabaseSync.getListDisplayImageSrc(image, assetId, {
        jobId: slotJobId(base, slot),
        allowFullFallback: false
      });
      if (url && isGridUrl(url)) return url;
    }
    return '';
  }

  function canSignGridLocally(image, cardId) {
    if (!image || !window.SupabaseSync?.isStorageRef?.(image)) return false;
    const p = window.SupabaseSync?.primaryImagePath?.(image, cardId);
    if (!p || window.SupabaseSync?.isPathKnownMissing?.(p.replace(/^\//, ''))) return false;
    const grid = window.SupabaseSync?.gridPathFromPrimary?.(p.replace(/^\//, ''));
    if (!grid) return false;
    return window.SupabaseSync?.shouldSignGridPath?.(grid.replace(/^\//, ''), cardId) !== false;
  }

  async function trySignGridFallback(image, cardId, jobId) {
    if (!image || !cardId) return '';
    const hit = cachedGridUrl(image, cardId, jobId, 0);
    if (hit) return hit;
    if (window.MediaPipeline?.resolveListUrl) {
      const url = await window.MediaPipeline.resolveListUrl(image, {
        assetId: cardId,
        cardId,
        jobId: jobId || undefined,
        galleryIndex: 0,
        allowFullFallback: false,
        tryAllPaths: false
      });
      if (url && isGridUrl(url)) return url;
    }
    if (window.SupabaseSync?.resolveDisplayUrl) {
      const url = await window.SupabaseSync.resolveDisplayUrl(image, {
        assetId: cardId,
        cardId,
        jobId: jobId || undefined,
        variant: 'grid',
        listOnly: true,
        allowFullFallback: false
      });
      if (url && isGridUrl(url)) return url;
    }
    return '';
  }

  /** 仅当 CDN 无法签 grid 且不在 503 冷却期时才走 warehouse-thumbs */
  function needsServerThumb(image, jobId, opts) {
    if (Date.now() < thumb503CooldownUntil) return false;
    if (!jobId || !window.PromptHubApi?.postWarehouseThumbs) return false;
    if (!window.SupabaseSync?.isLoggedIn?.()) return false;
    const slot = Number.isFinite(opts?.galleryIndex) ? opts.galleryIndex : gallerySlotFromJobId(jobId);
    const base = String(jobId).replace(/#\d+$/, '');
    if (cachedGridUrl(image, opts?.assetId || opts?.cardId, base, slot)) return false;
    if (canSignGridLocally(image, opts?.cardId || opts?.assetId)) return false;
    return true;
  }

  function rememberUrl(key, url, cardId) {
    if (!url) return '';
    cache.set(key, url);
    if (cardId && window.SupabaseSync?.markGridThumbReady) {
      window.SupabaseSync.markGridThumbReady(cardId);
    }
    return url;
  }

  function markThumb503() {
    thumb503Strike += 1;
    const sec = Math.min(120, 12 * thumb503Strike);
    thumb503CooldownUntil = Date.now() + sec * 1000;
  }

  function scheduleFlush() {
    if (flushTimer) return;
    if (Date.now() < thumb503CooldownUntil) return;
    const { delay } = mobileBatchTuning();
    flushTimer = setTimeout(() => {
      flushTimer = null;
      void flushPending();
    }, delay);
  }

  async function flushPending() {
    if (Date.now() < thumb503CooldownUntil) {
      const batch = pending.splice(0, pending.length);
      for (const item of batch) {
        const fb = await trySignGridFallback(item.image, item.cardId, item.baseJobId);
        item.resolve(fb || '');
      }
      return;
    }
    const { max } = mobileBatchTuning();
    const batch = pending.splice(0, max);
    if (!batch.length) return;
    if (pending.length) scheduleFlush();

    const grouped = new Map();
    for (const item of batch) {
      const ck = cacheKey(item.baseJobId, item.slot);
      const hit = cache.get(ck);
      if (hit) {
        item.resolve(hit);
        continue;
      }
      const fb = await trySignGridFallback(item.image, item.cardId, item.baseJobId);
      if (fb) {
        rememberUrl(ck, fb, item.cardId);
        item.resolve(fb);
        continue;
      }
      if (!grouped.has(ck)) {
        grouped.set(ck, {
          baseJobId: item.baseJobId,
          slot: item.slot,
          cardId: item.cardId,
          image: item.image,
          waiters: []
        });
      }
      grouped.get(ck).waiters.push(item.resolve);
    }
    if (!grouped.size) return;

    const jobs = [...grouped.values()].map((g) => ({
      jobId: slotJobId(g.baseJobId, g.slot),
      slot: g.slot || 0
    }));

    let thumbs = {};
    let serverFailed = false;
    try {
      const res = await window.PromptHubApi.postWarehouseThumbs(jobs);
      if (!res || res.ok === false) {
        serverFailed = true;
        if (res?.status === 503 || res?.code === 503 || /503|unavailable|rate/i.test(String(res?.message || ''))) {
          markThumb503();
        }
        console.warn('[WarehouseThumb] batch rejected', res?.message || res?.code);
      }
      thumbs = res?.data?.thumbs || res?.thumbs || {};
    } catch (e) {
      serverFailed = true;
      if (/503|429|502|failed|CORS/i.test(String(e?.message || e))) markThumb503();
      console.warn('[WarehouseThumb] batch failed', e);
    }

    for (const [ck, g] of grouped) {
      let out = thumbs[ck] || '';
      if (out && isGridUrl(out)) {
        out = rememberUrl(ck, out, g.cardId);
      } else if (serverFailed) {
        out = await trySignGridFallback(g.image, g.cardId, g.baseJobId);
        if (out) rememberUrl(ck, out, g.cardId);
      } else {
        out = '';
      }
      g.waiters.forEach((fn) => fn(out || ''));
    }
  }

  function enqueue(baseJobId, slot, cardId, image) {
    const ck = cacheKey(baseJobId, slot);
    const hit = cache.get(ck);
    if (hit) return Promise.resolve(hit);

    if (inflight.has(ck)) return inflight.get(ck);

    const p = new Promise((resolve) => {
      pending.push({ baseJobId, slot, cardId, image, resolve });
      scheduleFlush();
    }).finally(() => {
      inflight.delete(ck);
    });
    inflight.set(ck, p);
    return p;
  }

  async function resolveForCard(image, opts) {
    const o = opts && typeof opts === 'object' ? opts : {};
    const jobId = o.jobId ? String(o.jobId) : '';
    if (!jobId) return '';
    const slot = Number.isFinite(o.galleryIndex) ? o.galleryIndex : gallerySlotFromJobId(jobId);
    const baseJobId = jobId.replace(/#\d+$/, '');
    const cardId = o.assetId || o.cardId || '';

    const cached = cachedGridUrl(image, cardId, baseJobId, slot);
    if (cached) return cached;

    const signed = await trySignGridFallback(image, cardId, baseJobId);
    if (signed) return signed;

    if (!needsServerThumb(image, jobId, o)) return '';

    const url = await enqueue(baseJobId, slot, cardId, image);
    return url || '';
  }

  async function resolveForCardModel(card) {
    if (!card?.id) return '';
    window.SupabaseSync?.clearPathMissingForCard?.(card.id, card.image);
    const meta = window.PromptHubCardGallery?.getWarehouseListThumbMeta?.(card);
    if (!meta?.hasImage) return '';
    const jobId = meta.jobId || meta.thumbMeta?.slotJobId
      || window.PromptHubCardGallery?.resolveGenJobIdFromCard?.(card)
      || (card.genJobId ? String(card.genJobId).replace(/#\d+$/, '') : '');
    const ref = meta.ref || card.image || '';
    const galleryIndex = meta.isMjComposite ? 0 : (meta.galleryIndex ?? 0);
    if (meta.cachedUrl && isGridUrl(meta.cachedUrl)) return meta.cachedUrl;

    const signed = await trySignGridFallback(ref, card.id, jobId);
    if (signed) return signed;

    if (jobId) {
      const wh = await resolveForCard(ref, {
        jobId: meta.thumbMeta?.slotJobId || slotJobId(jobId, galleryIndex),
        assetId: card.id,
        cardId: card.id,
        galleryIndex
      });
      if (wh) return wh;
    }
    if (window.MediaPipeline?.resolveListUrl) {
      return window.MediaPipeline.resolveListUrl(ref, {
        assetId: card.id,
        cardId: card.id,
        jobId: jobId || undefined,
        galleryIndex,
        tryAllPaths: true
      });
    }
    return '';
  }

  async function prefetchForCards(cards, opts) {
    const list = Array.isArray(cards) ? cards : [];
    const max = Math.min(opts?.max || 4, list.length);
    if (!max || Date.now() < thumb503CooldownUntil) return;
    const tasks = [];
    for (let i = 0; i < max; i += 1) {
      const card = list[i];
      if (!card?.id) continue;
      const meta = window.PromptHubCardGallery?.getWarehouseListThumbMeta?.(card);
      if (!meta?.hasImage) continue;
      if (needsServerThumb(meta.ref || card.image, meta.jobId, { cardId: card.id, assetId: card.id })) {
        tasks.push(resolveForCardModel(card));
      }
    }
    if (!tasks.length) return;
    await Promise.allSettled(tasks);
    const wh = document.getElementById('cardsContainer');
    const ig = document.getElementById('imageGenFeed');
    if (wh && document.getElementById('pageWarehouse')?.classList.contains('active')) {
      window.MediaPipeline?.patchContainerFromCache?.(wh, { visibleFirst: true, max: 12 });
      window.CardImageLoader?.boostWarehouseImages?.(wh, 12);
    }
    if (ig && document.getElementById('pageImageGen')?.classList.contains('active')) {
      window.MediaPipeline?.patchContainerFromCache?.(ig, { visibleFirst: true, max: 12 });
      window.CardImageLoader?.boostImageGenWarehouseImages?.(ig, 12);
    }
  }

  window.WarehouseThumb = {
    resolveForCard,
    resolveForCardModel,
    needsServerThumb,
    prefetchForCards,
    cacheKey,
    slotJobId
  };
})();
