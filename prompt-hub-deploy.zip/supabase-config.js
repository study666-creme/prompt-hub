// 填入 Supabase 项目 Settings → API 里的两项（anon public 密钥可放前端）
window.SUPABASE_URL = 'https://yibawjvhmqcysdovscss.supabase.co';
window.SUPABASE_ANON_KEY = 'sb_publishable_PGhXkT83iWKzx5244I9t4w_HSBITvgF';
