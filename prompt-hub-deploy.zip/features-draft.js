/**
 * 提示词社区 / 我的创作 / 图片生成 — 功能草案
 */
(function () {
  const LS_COMMUNITY = 'promptrepo_community_posts';
  const LS_CREATIONS = 'promptrepo_creations';
  const LS_LIKES = 'promptrepo_community_likes';
  const LS_FAVS = 'promptrepo_community_favorites';
  const LS_IMAGEGEN = 'promptrepo_imagegen_draft';
  const PREFILL_KEY = 'promptrepo_imagegen_prefill';

  const GEN_RETENTION_MIN_MS = 1 * 24 * 60 * 60 * 1000;
  const GEN_RETENTION_MAX_MS = 3 * 24 * 60 * 60 * 1000;
  const MIN_COMMUNITY_PROMPT_LEN = 15;

  function randomGenRetentionMs() {
    return GEN_RETENTION_MIN_MS + Math.floor(Math.random() * (GEN_RETENTION_MAX_MS - GEN_RETENTION_MIN_MS + 1));
  }

  const finishingJobIds = new Set();

  function isGenerationJobDeleted(jobId) {
    if (!jobId) return false;
    const t = window.getDeletedGenerationJobTombstones?.() || {};
    return !!t[String(jobId)];
  }

  function dedupeCreationsByJobId(list) {
    const noJob = [];
    const byJob = new Map();
    for (const c of list || []) {
      if (!c?.id) continue;
      const j = c.jobId;
      if (!j) {
        noJob.push(c);
        continue;
      }
      const prev = byJob.get(j);
      if (!prev || (c.createdAt || 0) >= (prev.createdAt || 0)) byJob.set(j, c);
    }
    const merged = [...noJob, ...byJob.values()];
    merged.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    return merged;
  }

  let communityPosts = [];
  let creations = [];
  let likedIds = new Set();
  let favIds = new Set();
  let creationsTab = 'private';
  let communitySort = 'hot';
  let communityMediaFilter = 'all';
  let communityScope = 'all';
  let follows = new Set();
  let notifications = [];
  let communityEvents = [];
  let imageGenGenPublicSession = null;
  let cardPublishSessionOverride = null;
  let openPostId = null;
  let openProfileAuthorId = null;
  const MAX_REF_IMAGES = 16;
  let imageGenRefImages = [];
  let imageGenLastResult = null;
  let imageGenActiveHistoryId = null;
  let imageGenFeedTab = 'warehouse';
  /** @type {Array<{id:string,prompt:string,model:string,modelLabel:string,resolution:string,quality:string,size:string,cost:number,startedAt:number,jobId?:string}>} */
  let imageGenPendingJobs = [];
  /** null = 本次进入生图页尚未手动改过；离开后再进会重置 */
  let imageGenAutoPublishSession = null;
  let imageGenAutoSaveSession = null;
  let imageGenMasonry = null;
  let imageGenWhGroup = 'all';
  let imageGenWhTag = 'all';
  let communityMasonry = null;
  let profileMasonry = null;
  let creationsMasonry = null;
  let communitySidePostId = null;
  let creationsSideId = null;
  let imageGenPreviewId = null;
  let imageGenPreviewKind = null;
  let layoutCommunityTimer = null;
  let communityFeedRenderGen = 0;
  let imageGenLayoutTimer = null;
  const displayUrlCache = new Map();

  function esc(s) {
    const d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
  }

  function toast(msg) {
    if (typeof showToast === 'function') showToast(msg);
    else alert(msg);
  }

  function loadJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function saveJson(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
  }

  function genId(prefix) {
    return prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  }

  function getActiveUser() {
    const uid = window.SupabaseSync?.getUserId?.();
    const email = document.getElementById('authUserEmail')?.textContent?.trim()
      || window.SupabaseSync?.getUserEmail?.() || '';
    if (uid) {
      return { id: uid, name: email ? email.split('@')[0] : '用户', email };
    }
    if (email) return { id: 'local_' + email, name: email.split('@')[0] || '用户', email };
    return { id: 'guest', name: '访客', email: '' };
  }

  function getCardColumns() {
    return Math.min(5, Math.max(1, Number(getComputedStyle(document.documentElement).getPropertyValue('--card-columns')) || 4));
  }

  function getMasonryGap() {
    const v = getComputedStyle(document.documentElement).getPropertyValue('--card-row-gap').trim();
    const n = parseFloat(v);
    return Number.isFinite(n) ? n : 16;
  }

  function filterCreationsForCloud(list) {
    const tomb = window.getDeletedCreationTombstones?.() || {};
    return (list || []).filter((c) => c && c.id != null && !tomb[String(c.id)]);
  }

  function filterCommunityPostsForDisplay(list) {
    const postTomb = window.getDeletedCommunityPostTombstones?.() || {};
    const cardTomb = window.getDeletedCardTombstones?.() || {};
    const creTomb = window.getDeletedCreationTombstones?.() || {};
    return (list || []).filter((p) => {
      if (!p || p.isMock) return false;
      if (postTomb[String(p.id)]) return false;
      if (p.sourceCardId && cardTomb[String(p.sourceCardId)]) return false;
      if (p.sourceCreationId && creTomb[String(p.sourceCreationId)]) return false;
      return true;
    });
  }

  function pruneOrphanFeatureData() {
    const beforeP = communityPosts.length;
    communityPosts = filterCommunityPostsForDisplay(communityPosts);
    if (communityPosts.length !== beforeP) persistCommunity();
    const creTomb = window.getDeletedCreationTombstones?.() || {};
    const beforeC = creations.length;
    creations = creations.filter((c) => c && c.id != null && !creTomb[String(c.id)]);
    if (creations.length !== beforeC) persistCreations();
  }

  /** 退出登录：清私人创作/互动数据；社区帖保留供游客浏览 */
  function clearSensitiveLocalStateOnSignOut() {
    creations = [];
    saveJson(LS_CREATIONS, []);
    likedIds = new Set();
    favIds = new Set();
    saveJson(LS_LIKES, []);
    saveJson(LS_FAVS, []);
    communityEvents = [];
    notifications = [];
    persistNotifications();
    updateNotifyBadge();
    closeCommunitySidePanel();
    closeCreationsSidePanel();
    closeUserProfile();
    if (document.getElementById('pageCommunity')?.classList.contains('active')) renderCommunity();
    if (document.getElementById('pageCreations')?.classList.contains('active')) void renderCreations();
    if (document.getElementById('pageImageGen')?.classList.contains('active')) renderImageGenFeed();
  }

  function reloadStores() {
    loadStores();
  }

  function loadStores() {
    communityPosts = filterCommunityPostsForDisplay(loadJson(LS_COMMUNITY, []));
    creations = dedupeCreationsByJobId(filterCreationsForCloud(loadJson(LS_CREATIONS, [])));
    likedIds = new Set(loadJson(LS_LIKES, []));
    favIds = new Set(loadJson(LS_FAVS, []));
    loadFollows();
    loadNotifications();
    updateNotifyBadge();
    stripDemoCreations();
    pruneCreations();
    migrateCommunityAuthorIds();
    pruneOrphanFeatureData();
  }

  /** 登录后 uid 变化时，把旧 local_/guest 作者帖归到当前账号 */
  function migrateCommunityAuthorIds() {
    const user = getActiveUser();
    if (user.id === 'guest') return;
    const cardIds = new Set((window.__promptHubCards || []).map((c) => c.id));
    let changed = false;
    for (const p of communityPosts) {
      if (!p || p.isMock) continue;
      const aid = String(p.authorId || '');
      const isLegacyGuest = aid === 'guest' || p.authorName === '访客';
      const ownsCard = p.sourceCardId && cardIds.has(p.sourceCardId);
      const emailMatch = user.email && aid === 'local_' + user.email;
      if (aid.startsWith('local_') && (ownsCard || emailMatch)) {
        p.authorId = user.id;
        p.authorName = user.name;
        changed = true;
        continue;
      }
      if (isLegacyGuest && ownsCard) {
        p.authorId = user.id;
        p.authorName = user.name;
        changed = true;
      }
    }
    if (changed) persistCommunity();
  }

  function ensureCommunityFromCards() {
    const cards = window.__promptHubCards || [];
    if (!cards.length) return 0;
    migrateCommunityAuthorIds();
    reconcileCommunityWithCards(cards);
    let added = materializeCommunityFromCards(cards);
    if (!getAllCommunityPosts().length) {
      added += syncEligibleCardsToCommunity({ silent: true, skipRender: true });
    }
    return added;
  }

  function stripDemoCreations() {
    const before = creations.length;
    creations = creations.filter(c => !isDemoPlaceholderImage(c?.image));
    if (creations.length !== before) persistCreations();
  }

  function pruneCreations() {
    const now = Date.now();
    const before = creations.length;
    creations = creations.filter(c =>
      c.visibility === 'published' || c.permanent || !c.expiresAt || c.expiresAt > now
    );
    if (creations.length !== before) persistCreations();
  }

  function getDefaultPublishChecked() {
    if (typeof window.getDefaultPublishCommunity === 'function') {
      return window.getDefaultPublishCommunity();
    }
    return true;
  }

  function isCommunityPromptEligible(prompt) {
    return String(prompt || '').trim().length >= MIN_COMMUNITY_PROMPT_LEN;
  }

  /** globalDefaultOn：设置里是否开启默认；sessionOverride：用户手动切换 null=跟随规则 */
  function computeAutoCommunityToggle(prompt, globalDefaultOn, sessionOverride) {
    if (sessionOverride === true) return true;
    if (sessionOverride === false) return false;
    if (!globalDefaultOn) return false;
    return isCommunityPromptEligible(prompt);
  }

  function getCardFormPromptText() {
    return (
      document.getElementById('cardPrompt')?.value
      || document.getElementById('floatingPromptText')?.value
      || ''
    );
  }

  function syncCardPublishFromPrompt(prompt) {
    const btn = document.getElementById('cardPublishToggle');
    if (!btn) return;
    if (cardPublishSessionOverride !== null) {
      btn.classList.toggle('is-on', cardPublishSessionOverride);
      btn.setAttribute('aria-pressed', cardPublishSessionOverride ? 'true' : 'false');
      return;
    }
    if (typeof window.__promptHubIsNewCard === 'function' && !window.__promptHubIsNewCard()) return;
    const on = computeAutoCommunityToggle(
      prompt,
      getDefaultPublishChecked(),
      null
    );
    btn.classList.toggle('is-on', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function persistCommunity() {
    dedupeCommunityPosts({ persist: false });
    saveJson(LS_COMMUNITY, communityPosts.filter(p => !p.isMock));
    if (window.SupabaseSync?.isLoggedIn?.()) {
      window.scheduleCloudPush?.();
    }
  }

  function persistCreations() {
    saveJson(LS_CREATIONS, creations);
    if (window.SupabaseSync?.isLoggedIn?.()) {
      window.scheduleCloudPush?.();
    }
  }

  function persistLikes() {
    saveJson(LS_LIKES, [...likedIds]);
  }

  function persistFavs() {
    saveJson(LS_FAVS, [...favIds]);
  }

  function getAllCommunityPosts() {
    return filterCommunityPostsForDisplay(communityPosts);
  }

  function communityPostDedupeKey(p, userId) {
    if (!p) return '';
    if (p.sourceCardId) return `card:${p.sourceCardId}`;
    if (p.sourceCreationId) return `cre:${p.sourceCreationId}`;
    if (String(p.authorId) === String(userId)) {
      const prompt = String(p.prompt || p.title || '').trim().slice(0, 200).toLowerCase();
      if (prompt) return `prompt:${prompt}`;
    }
    return `id:${p.id}`;
  }

  function dedupeCommunityPosts(opts = {}) {
    const persist = opts.persist !== false;
    const user = getActiveUser();
    const cardTomb = window.getDeletedCardTombstones?.() || {};
    const keptOthers = [];
    const ownByKey = new Map();
    const before = communityPosts.length;

    for (const p of communityPosts) {
      if (!p || p.isMock) continue;
      if (String(p.authorId) !== String(user.id)) {
        keptOthers.push(p);
        continue;
      }
      if (p.sourceCardId && cardTomb[String(p.sourceCardId)]) continue;
      const key = communityPostDedupeKey(p, user.id);
      const prev = ownByKey.get(key);
      const ts = p.updatedAt || p.createdAt || 0;
      const prevTs = prev ? (prev.updatedAt || prev.createdAt || 0) : -1;
      if (!prev || ts >= prevTs) ownByKey.set(key, p);
    }

    communityPosts = [...keptOthers, ...ownByKey.values()];
    if (communityPosts.length !== before && persist) {
      saveJson(LS_COMMUNITY, communityPosts.filter((p) => !p.isMock));
      if (window.SupabaseSync?.isLoggedIn?.()) window.scheduleCloudPush?.();
    }
    return communityPosts;
  }

  /** 与卡片库对齐：去掉演示帖、孤儿帖、同一卡片的重复社区帖；对齐 communityPostId */
  function reconcileCommunityWithCards(cardList) {
    const list = Array.isArray(cardList) ? cardList : [];
    const user = getActiveUser();
    migrateCommunityAuthorIds();
    dedupeCommunityPosts({ persist: false });
    if (user.id === 'guest') {
      pruneOrphanFeatureData();
      return list;
    }
    if (list.length === 0) {
      return list;
    }
    const cardIds = new Set(list.map(c => c.id));
    const ownBySource = new Map();
    const kept = [];
    for (const p of communityPosts) {
      if (p.isMock) continue;
      if (p.authorId !== user.id) {
        kept.push(p);
        continue;
      }
      if (!p.sourceCardId) {
        kept.push(p);
        continue;
      }
      const tomb = window.getDeletedCardTombstones?.() || {};
      if (tomb[String(p.sourceCardId)]) continue;
      if (!cardIds.has(p.sourceCardId)) {
        continue;
      }
      const prev = ownBySource.get(p.sourceCardId);
      const ts = p.updatedAt || p.createdAt || 0;
      const prevTs = prev ? (prev.updatedAt || prev.createdAt || 0) : -1;
      if (!prev || ts >= prevTs) ownBySource.set(p.sourceCardId, p);
    }
    communityPosts = [...kept, ...ownBySource.values()];
    dedupeCommunityPosts({ persist: false });
    for (const c of list) {
      const post = communityPosts.find((p) => p.sourceCardId === c.id);
      if (post) {
        c.publishedToCommunity = true;
        c.communityPostId = post.id;
      } else if (c.communityPostId && !communityPosts.some((p) => p.id === c.communityPostId)) {
        c.publishedToCommunity = false;
        c.communityPostId = null;
      }
    }
    materializeCommunityFromCards(list);
    persistCommunity();
    pruneOrphanFeatureData();
    return list;
  }

  /** 将已标记「发布到社区」的卡片补成社区帖（修复仅有卡片、无 communityPosts 的情况） */
  function materializeCommunityFromCards(cardList) {
    const list = Array.isArray(cardList) ? cardList : [];
    const user = getActiveUser();
    if (user.id === 'guest') return 0;
    let added = 0;
    for (const c of list) {
      if (!c?.id) continue;
      if (!(c.publishedToCommunity || c.communityPostId)) continue;
      if (!isCommunityPromptEligible(c.prompt)) continue;
      const hasPost = communityPosts.some((p) => p.sourceCardId === c.id);
      if (hasPost) {
        const post = communityPosts.find((p) => p.sourceCardId === c.id);
        if (post && (post.prompt !== (c.prompt || '') || post.image !== (c.image ?? null) || post.title !== ((c.title || '').trim()))) {
          syncCardToCommunity(c, true, { silent: true });
        }
        continue;
      }
      const before = communityPosts.length;
      syncCardToCommunity(c, true, { silent: true, keepPublishFlag: true });
      if (communityPosts.length > before) added += 1;
    }
    return added;
  }

  function syncEligibleCardsToCommunity(opts = {}) {
    const list = window.__promptHubCards || [];
    if (!list.length) {
      if (!opts.silent) toast('卡片库暂无作品');
      return 0;
    }
    let added = 0;
    for (const c of list) {
      if (!c?.id || !isCommunityPromptEligible(c.prompt)) continue;
      if (communityPosts.some((p) => p.sourceCardId === c.id)) continue;
      const before = communityPosts.length;
      syncCardToCommunity(c, true, { silent: true });
      if (communityPosts.length > before) {
        c.publishedToCommunity = true;
        added += 1;
      }
    }
    if (added > 0) {
      persistCommunity();
      if (typeof window.persistPromptHubCards === 'function') void window.persistPromptHubCards();
    }
    if (!opts.skipRender) {
      renderCommunity();
      if (document.getElementById('pageCreations')?.classList.contains('active')) void renderCreations();
    }
    return added;
  }
  window.syncEligibleCardsToCommunity = syncEligibleCardsToCommunity;

  function refreshFeedsAfterCardsSync() {
    if (window.__promptHubCards?.length) ensureCommunityFromCards();
    if (document.getElementById('pageCommunity')?.classList.contains('active')) renderCommunity();
    if (document.getElementById('pageCreations')?.classList.contains('active')) void renderCreations();
  }

  function featureImgSrc(image) {
    if (!image) return '';
    if (window.SupabaseSync?.safeImgSrc) return window.SupabaseSync.safeImgSrc(image);
    if (window.SupabaseSync?.isStorageRef?.(image)) {
      const c = window.SupabaseSync.getCachedDisplayUrl?.(image, { variant: 'grid' });
      return c && !c.startsWith('storage://') ? c : '';
    }
    return image;
  }

  function isDemoPlaceholderImage(image) {
    if (typeof image !== 'string' || !image.startsWith('data:image/')) return false;
    return image.includes('演示生成');
  }

  function isDisplayableImage(image) {
    if (!image || typeof image !== 'string') return false;
    if (isDemoPlaceholderImage(image)) return false;
    return true;
  }

  async function resolveImageDisplayUrl(image, jobId, assetId) {
    if (!image) return '';
    const cacheKey = jobId ? `job:${jobId}` : (assetId ? `${assetId}:${image}` : image);
    const hit = displayUrlCache.get(cacheKey);
    if (hit) return hit;
    let url = '';
    const cached = window.SupabaseSync?.getCachedDisplayUrl?.(image, { assetId, variant: 'grid' });
    if (cached && /^https?:\/\//i.test(cached) && !cached.includes('/object/public/')) url = cached;
    const isStorageLike = window.SupabaseSync?.isStorageRef?.(image) || String(image).startsWith('storage://');
    if (!url && window.SupabaseSync?.resolveDisplayUrl && isStorageLike) {
      try {
        const communityFeed = !window.SupabaseSync?.isLoggedIn?.();
        url = await window.SupabaseSync.resolveDisplayUrl(image, { assetId, variant: 'grid', communityFeed });
      } catch (e) {
        console.warn('resolve image failed', e);
      }
    }
    if (!url && jobId && window.PromptHubApi?.getGenerationImageUrl) {
      const r = await window.PromptHubApi.getGenerationImageUrl(jobId);
      if (r.ok && r.data?.url) url = r.data.url;
    }
    if (!url && window.SupabaseSync?.resolveDisplayUrl) {
      try {
        url = await window.SupabaseSync.resolveDisplayUrl(image, { assetId });
      } catch (e) {
        console.warn('resolve image failed', e);
      }
    }
    if (!url && typeof image === 'string' && /^https?:\/\//i.test(image)) {
      const isPrivateBucket = /\/storage\/v1\/object\/(public|sign|authenticated)\/card-images\//i.test(image);
      if (!isPrivateBucket) url = image;
    }
    if (url && !url.startsWith('storage://') && !url.startsWith('data:image/svg')) displayUrlCache.set(cacheKey, url);
    return url || '';
  }

  const IMG_LOADING_PLACEHOLDER = 'data:image/svg+xml,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"><rect fill="%232a2a30" width="16" height="16"/></svg>'
  );

  function bindFeedImgErrorFallback(img) {
    if (!img || img.dataset.feedImgErrBound) return;
    img.dataset.feedImgErrBound = '1';
    img.addEventListener('error', () => {
      if (img.dataset.feedImgRetry === '1') return;
      img.dataset.feedImgRetry = '1';
      const ref = img.getAttribute('data-image-ref');
      const jobId = img.getAttribute('data-job-id') || '';
      if (!ref) return;
      void resolveImageDisplayUrl(ref, jobId || null).then((url) => {
        if (url && !url.startsWith('storage://')) {
          img.src = url;
          img.classList.remove('img-load-failed');
          return;
        }
        img.src = IMG_LOADING_PLACEHOLDER;
      });
    });
  }

  async function applyFeedImageSrc(img, ref, jobId) {
    const feedMedia = img.closest('.imagegen-feed-media');
    const cardMedia = img.closest('.card-media');
    if (!ref || !isDisplayableImage(ref)) return false;
    bindFeedImgErrorFallback(img);
    const assetId = img.closest('.card[data-id]')?.dataset?.id
      || img.closest('.card[data-post-id]')?.dataset?.postId
      || img.closest('.card[data-creation-id]')?.dataset?.creationId
      || img.closest('[data-feed-id]')?.dataset?.feedId?.replace(/^wh_/, '')
      || undefined;
    let url = displayUrlCache.get(jobId ? `job:${jobId}` : (assetId ? `${assetId}:${ref}` : ref)) || '';
    if (!url) {
      const cached = window.SupabaseSync?.getCachedDisplayUrl?.(ref, { assetId, variant: 'grid' });
      if (cached && typeof cached === 'string' && !cached.startsWith('storage://') && !cached.startsWith('data:image/svg') && !cached.includes('/object/public/')) {
        url = cached;
      }
    }
    if (!url) url = await resolveImageDisplayUrl(ref, jobId || null, assetId);
    if (!url || url.startsWith('storage://') || url.startsWith('data:image/svg')) {
      feedMedia?.classList.add('is-loading');
      feedMedia?.classList.remove('card-media--missing', 'card-media--load-failed');
      return false;
    }
    const endLoad = () => {
      const media = img.closest('.imagegen-feed-media, .card-media');
      if (typeof window.finishCardMediaShine === 'function') window.finishCardMediaShine(media);
      else media?.classList.remove('is-loading');
    };
    const tryFullFallback = () => {
      if (img.dataset.imgFallback === '1' || !window.SupabaseSync?.resolveDisplayUrl) {
        cardMedia?.classList.add('card-media--load-failed');
        endLoad();
        return;
      }
      img.dataset.imgFallback = '1';
      void window.SupabaseSync.resolveDisplayUrl(ref, { assetId, variant: 'full' }).then((full) => {
        if (full && /^https?:\/\//i.test(full) && !full.startsWith('storage://')) {
          img.addEventListener('load', endLoad, { once: true });
          img.src = full;
          if (img.complete && img.naturalWidth > 0) endLoad();
        } else {
          cardMedia?.classList.add('card-media--load-failed');
          endLoad();
        }
      });
    };
    if (img.complete && img.src === url && img.naturalWidth > 0) {
      endLoad();
      return true;
    }
    img.addEventListener('load', endLoad, { once: true });
    img.addEventListener('error', tryFullFallback, { once: true });
    img.src = url;
    img.classList.remove('img-load-failed');
    if (img.complete && img.naturalWidth > 0) endLoad();
    return true;
  }

  function feedImgStorageAttr(image) {
    if (!image || typeof image !== 'string') return '';
    if (window.SupabaseSync?.isStorageRef?.(image)) {
      return ` data-storage-ref="${esc(image)}"`;
    }
    return '';
  }

  function stripFailedFeedMedia(scope) {
    scope.querySelectorAll('.imagegen-feed-media img.img-load-failed').forEach(img => {
      const media = img.closest('.imagegen-feed-media');
      media?.remove();
      const card = img.closest('.imagegen-feed-card');
      if (card) card.classList.add('imagegen-feed-card--no-media');
    });
  }

  async function hydrateFeedImages(root) {
    const scope = root || document;
    if (window.SupabaseSync?.hydrateImageElements) {
      window.SupabaseSync.patchImageSrcFromCache?.(scope);
      await window.SupabaseSync.hydrateImageElements(scope, { onlyMissing: true });
      stripFailedFeedMedia(scope);
      if (isMobileFeedViewport()) resetMobileFeedGridStyles();
      else layoutImageGenFeedMasonry();
      return;
    }
    const imgs = scope.querySelectorAll(
      '.imagegen-feed img[data-image-ref], #imageGenFeed img[data-image-ref], #creationsSideBody img[data-image-ref], #creationsGrid img[data-image-ref], #communityGrid img[data-image-ref], #userProfileGrid img[data-image-ref]'
    );
    const list = [...imgs];
    const concurrency = window.matchMedia('(max-width: 900px)').matches ? 4 : 6;
    let cursor = 0;
    async function worker() {
      while (cursor < list.length) {
        const img = list[cursor++];
        await hydrateFeedImageOne(img);
      }
    }
    await Promise.all(Array.from({ length: Math.min(concurrency, list.length || 1) }, () => worker()));
    stripFailedFeedMedia(scope);
    if (isMobileFeedViewport()) resetMobileFeedGridStyles();
    else layoutImageGenFeedMasonry();
  }

  async function hydrateFeedImageOne(img) {
      const ref = img.getAttribute('data-image-ref');
      const jobId = img.getAttribute('data-job-id') || '';
      const media = img.closest('.imagegen-feed-media') || img.closest('.card-media');
      const sideBtn = img.closest('.community-side-img-btn');
      if (!ref || !isDisplayableImage(ref)) {
        media?.remove();
        img.closest('.imagegen-feed-card')?.classList.add('imagegen-feed-card--no-media');
        return;
      }
      if (media?.classList.contains('imagegen-gen-pending')) return;
      const cur = img.currentSrc || img.src || '';
      if (cur.startsWith('http') && !cur.includes('data:image/svg') && img.complete && img.naturalWidth > 0) {
        if (typeof window.finishCardMediaShine === 'function') window.finishCardMediaShine(media);
        else media?.classList.remove('is-loading');
        return;
      }
      if (media) {
        if (!media.dataset.shineAt) media.dataset.shineAt = String(Date.now());
        media.classList.add('is-loading');
      }
      if (!cur.startsWith('http') || cur.includes('data:image/svg')) {
        img.src = IMG_LOADING_PLACEHOLDER;
      }
      img.classList.remove('img-load-failed');
      const ok = await applyFeedImageSrc(img, ref, jobId || null);
      if (!ok) {
        media?.classList.remove('is-loading');
        const feedCard = img.closest('.imagegen-feed-card');
        if (feedCard) {
          media?.remove();
          feedCard.classList.add('imagegen-feed-card--no-media');
        } else if (media?.classList.contains('card-media')) {
          media.classList.add('card-media--load-failed');
        } else if (sideBtn) {
          img.src = IMG_LOADING_PLACEHOLDER;
        }
      }
  }

  function getPostsByAuthor(authorId) {
    return getAllCommunityPosts().filter(p => p.authorId === authorId);
  }

  function isGenericPostTitle(title) {
    const t = (title || '').trim();
    return !t || t === '未命名' || t === '未命名提示词' || t === '我的作品';
  }

  function getPostTitle(post) {
    const title = (post.title || '').trim();
    if (title && !isGenericPostTitle(title)) return title;
    const prompt = (post.prompt || '').trim();
    if (!prompt) return '暂无提示词';
    if (prompt.length <= 80) return prompt;
    return prompt.slice(0, 80) + '…';
  }

  /** 侧栏标题最多 10 字 */
  function getPostSideTitle(post) {
    const title = (post.title || '').trim();
    if (title && !isGenericPostTitle(title)) {
      return title.length > 10 ? title.slice(0, 10) + '…' : title;
    }
    const prompt = (post.prompt || '').trim();
    if (!prompt) return '提示词详情';
    return prompt.length > 10 ? prompt.slice(0, 10) + '…' : prompt;
  }

  function getPostDesc(post) {
    const title = (post.title || '').trim();
    const prompt = (post.prompt || '').trim();
    if (!title || isGenericPostTitle(title)) return '';
    return prompt || '';
  }

  function formatTime(ts) {
    if (!ts) return '';
    const diff = Date.now() - ts;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)} 分钟前`;
    if (diff < 86400000) return `大约 ${Math.floor(diff / 3600000)} 小时前`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)} 天前`;
    return new Date(ts).toLocaleDateString('zh-CN');
  }

  function makePlaceholderDataUrl(prompt, seed = 0) {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 512;
    const ctx = c.getContext('2d');
    const h = ((prompt || '').length * 17 + seed * 53) % 360;
    const g = ctx.createLinearGradient(0, 0, 512, 512);
    g.addColorStop(0, `hsl(${h}, 45%, 22%)`);
    g.addColorStop(1, `hsl(${(h + 80) % 360}, 50%, 12%)`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 512, 512);
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    ctx.font = '14px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('演示生成', 256, 248);
    ctx.font = '11px Inter, sans-serif';
    ctx.fillText('接入 API 后替换', 256, 268);
    return c.toDataURL('image/jpeg', 0.85);
  }

  function isGenericFeedTitle(title) {
    const t = (title || '').trim();
    return !t || t === '未命名' || t === '未命名提示词' || t === '我的作品' || t === '生成图';
  }

  /** 标题行仅显示真实标题；勿把提示词首行当标题 */
  function resolveFeedCardDisplay(title, prompt) {
    const t = (title || '').trim();
    const p = (prompt || '').trim();
    let showTitle = '';
    if (t && !isGenericFeedTitle(t) && t !== p) {
      if (!(p && p.startsWith(t) && t.length >= 6)) showTitle = t;
    }
    const showPrompt = p || '';
    return { showTitle, showPrompt };
  }

  /** 首屏 HTML 只用占位图，避免缓存 URL 在 Masonry/网格就位前以原尺寸闪现 */
  function feedImgInitialSrc(image, jobId) {
    if (!image || !isDisplayableImage(image)) return '';
    return IMG_LOADING_PLACEHOLDER;
  }

  function setFeedLayoutPending(containerId, pending) {
    const el = typeof containerId === 'string' ? document.getElementById(containerId) : containerId;
    if (!el) return;
    el.classList.toggle('feed-layout-pending', !!pending);
    if (!pending) el.classList.add('feed-layout-ready');
  }

  function communityImgInitialSrc(image) {
    return feedImgInitialSrc(image, null);
  }

  function patchCommunityLikeUI(id) {
    const post = findPost(id);
    if (!post) return;
    const label = `♥ ${post.likes || 0}`;
    const liked = likedIds.has(id);
    document.querySelectorAll(`#communityGrid .card[data-post-id="${id}"] .card-time`).forEach(el => {
      el.textContent = label;
      el.classList.toggle('liked', liked);
    });
    if (openProfileAuthorId) {
      document.querySelectorAll(`#userProfileGrid .card[data-post-id="${id}"] .card-time`).forEach(el => {
        el.textContent = label;
        el.classList.toggle('liked', liked);
      });
    }
  }

  function patchCommunitySidePanelUI(id) {
    if (communitySidePostId !== id) return;
    const post = findPost(id);
    const body = document.getElementById('communitySideBody');
    if (!post || !body) return;
    const liked = likedIds.has(id);
    const faved = favIds.has(id);
    const stats = body.querySelector('.community-side-stats');
    if (stats) {
      stats.innerHTML = `<span>♥ ${post.likes || 0} 点赞</span><span>${faved ? '已收藏' : '未收藏'}</span>`;
    }
    const likeBtn = body.querySelector('[data-action="like"]');
    if (likeBtn) likeBtn.textContent = `♥ ${liked ? '已点赞' : '点赞'}`;
    const favBtn = body.querySelector('[data-action="fav"]');
    if (favBtn) favBtn.textContent = faved ? '已收藏' : '收藏';
  }

  function isMobileFeedViewport() {
    return window.MobileUI?.isMobile?.() || window.matchMedia('(max-width: 900px)').matches;
  }

  function bindImageGenFeedImageRelayout() {
    const wrap = document.getElementById('imageGenFeed');
    if (!wrap) return;
    wrap.querySelectorAll('.imagegen-feed-media img, .imagegen-feed-thumb-btn img').forEach(img => {
      if (img.dataset.masonryRelayoutBound) return;
      img.dataset.masonryRelayoutBound = '1';
      const relayout = () => scheduleImageGenFeedLayout();
      img.addEventListener('load', relayout, { once: true });
      img.addEventListener('error', relayout, { once: true });
    });
  }

  function scheduleImageGenFeedLayout() {
    clearTimeout(imageGenLayoutTimer);
    imageGenLayoutTimer = setTimeout(() => {
      if (isMobileFeedViewport()) enforceMobileImageGenFeed();
      else layoutImageGenFeedMasonry();
    }, 160);
  }

  function resetImageGenFeedCardLayout() {
    const wrap = document.getElementById('imageGenFeed');
    if (!wrap) return;
    if (imageGenMasonry) {
      try { imageGenMasonry.destroy(); } catch (e) { /* ignore */ }
      imageGenMasonry = null;
    }
    wrap.style.height = '';
    wrap.querySelectorAll('.grid-sizer').forEach((el) => el.remove());
    wrap.querySelectorAll('.imagegen-feed-card').forEach((card) => {
      card.removeAttribute('style');
    });
  }

  function layoutImageGenFeedMasonry() {
    if (isMobileFeedViewport()) {
      enforceMobileImageGenFeed();
      return;
    }
    const wrap = document.getElementById('imageGenFeed');
    if (!wrap) return;
    wrap.classList.remove('imagegen-feed--tiles', 'imagegen-feed--desktop-grid', 'mobile-feed-grid');
    wrap.classList.add('imagegen-feed--masonry');

    const runLayout = () => {
      if (typeof Masonry === 'undefined') return;
      const cards = wrap.querySelectorAll('.imagegen-feed-card');
      if (!cards.length) {
        resetImageGenFeedCardLayout();
        setFeedLayoutPending(wrap, false);
        return;
      }
      const gap = getMasonryGap();
      const style = getComputedStyle(wrap);
      const innerW = wrap.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
      if (innerW < 80) {
        scheduleImageGenFeedLayout();
        return;
      }
      const cols = getCardColumns();
      const colWidth = Math.max(140, Math.floor((innerW - gap * (cols - 1)) / cols));
      let sizer = wrap.querySelector('.grid-sizer');
      if (!sizer) {
        sizer = document.createElement('div');
        sizer.className = 'grid-sizer';
        wrap.insertBefore(sizer, wrap.firstChild);
      }
      sizer.style.width = colWidth + 'px';
      cards.forEach((card) => { card.style.width = colWidth + 'px'; });
      const opts = {
        itemSelector: '.imagegen-feed-card',
        columnWidth: '.grid-sizer',
        gutter: gap,
        percentPosition: false,
        horizontalOrder: true,
        transitionDuration: 0
      };
      if (imageGenMasonry) {
        imageGenMasonry.option(opts);
        imageGenMasonry.reloadItems();
        imageGenMasonry.layout();
      } else {
        cards.forEach((card) => {
          card.style.left = '';
          card.style.top = '';
          card.style.position = '';
        });
        imageGenMasonry = new Masonry(wrap, opts);
        imageGenMasonry.layout();
      }
      requestAnimationFrame(() => {
        imageGenMasonry?.layout();
        setFeedLayoutPending(wrap, false);
      });
      bindImageGenFeedImageRelayout();
    };

    if (typeof Masonry !== 'undefined') runLayout();
    else if (typeof window.ensureMasonryScript === 'function') {
      void window.ensureMasonryScript().then(runLayout);
    } else runLayout();
  }

  function feedImgStillPending(img) {
    const src = img?.currentSrc || img?.src || '';
    if (!src || src.includes('data:image/svg')) return true;
    return !(img.complete && img.naturalWidth > 8);
  }

  function layoutCommunityWhenImagesReady(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const run = () => scheduleCommunityLayout(containerId);
    const imgs = [...container.querySelectorAll('.card-img')];
    const pending = imgs.filter((img) => feedImgStillPending(img));
    if (!pending.length) {
      run();
      return;
    }
    let left = pending.length;
    const tick = () => {
      left -= 1;
      if (left <= 0) run();
    };
    pending.forEach((img) => {
      img.addEventListener('load', tick, { once: true });
      img.addEventListener('error', tick, { once: true });
    });
    setTimeout(run, 900);
  }

  function scheduleCommunityLayout(containerId) {
    clearTimeout(layoutCommunityTimer);
    layoutCommunityTimer = setTimeout(() => layoutCommunityMasonry(containerId), 160);
  }

  function bindCommunityGridImageRelayout(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.querySelectorAll('img.card-img, .card-media img').forEach(img => {
      if (img.dataset.masonryRelayoutBound) return;
      img.dataset.masonryRelayoutBound = '1';
      const relayout = () => scheduleCommunityLayout(containerId);
      img.addEventListener('load', relayout, { once: true });
      img.addEventListener('error', relayout, { once: true });
    });
  }

  function scheduleLayoutAfterImages(containerId) {
    scheduleCommunityLayout(containerId);
    bindCommunityGridImageRelayout(containerId);
  }

  function isMobileFeedLayout() {
    return window.MobileUI?.isMobile?.() || window.matchMedia('(max-width: 900px)').matches;
  }

  function useCssGridForCommunityFeed(containerId) {
    if (containerId === 'userProfileGrid') return true;
    if (isMobileFeedLayout() && (containerId === 'communityGrid' || containerId === 'creationsGrid')) {
      return true;
    }
    return false;
  }

  function resetCommunityGridCardLayout(container, containerId) {
    if (containerId === 'creationsGrid' && creationsMasonry) {
      creationsMasonry.destroy();
      creationsMasonry = null;
    } else if (containerId === 'userProfileGrid' && profileMasonry) {
      profileMasonry.destroy();
      profileMasonry = null;
    } else if (communityMasonry) {
      communityMasonry.destroy();
      communityMasonry = null;
    }
    container.style.height = '';
    container.querySelectorAll('.card').forEach((card) => {
      card.style.width = '';
      card.style.left = '';
      card.style.top = '';
      card.style.position = '';
    });
  }

  function layoutCommunityMasonry(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    if (!useCssGridForCommunityFeed(containerId)) {
      container.classList.remove('community-mobile-feed');
    }
    if (useCssGridForCommunityFeed(containerId)) {
      resetCommunityGridCardLayout(container, containerId);
      container.classList.add('community-mobile-feed');
      requestAnimationFrame(() => setFeedLayoutPending(containerId, false));
      if (window.CardImageLoader?.observeContainer) window.CardImageLoader.observeContainer(container);
      return;
    }
    container?.classList.remove('community-mobile-feed');
    const runMasonryLayout = () => {
    if (typeof Masonry === 'undefined') return;
    const cardEls = container.querySelectorAll('.card');
    const isProfile = containerId === 'userProfileGrid';
    const isCreations = containerId === 'creationsGrid';
    let instance = isProfile ? profileMasonry : (isCreations ? creationsMasonry : communityMasonry);

    if (!cardEls.length) {
      if (instance) {
        instance.destroy();
        if (isProfile) profileMasonry = null;
        else if (isCreations) creationsMasonry = null;
        else communityMasonry = null;
      }
      setFeedLayoutPending(containerId, false);
      return;
    }

    const gap = getMasonryGap();
    const style = getComputedStyle(container);
    const innerW = container.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
    if (innerW < 80) {
      scheduleCommunityLayout(containerId);
      return;
    }
    const cols = getCardColumns();
    const colWidth = Math.max(120, Math.floor((innerW - gap * (cols - 1)) / cols));
    let sizer = container.querySelector('.grid-sizer');
    if (!sizer) {
      sizer = document.createElement('div');
      sizer.className = 'grid-sizer';
      container.insertBefore(sizer, container.firstChild);
    }
    sizer.style.width = colWidth + 'px';
    cardEls.forEach(card => { card.style.width = colWidth + 'px'; });
    const opts = {
      itemSelector: '.card',
      columnWidth: '.grid-sizer',
      gutter: gap,
      percentPosition: false,
      horizontalOrder: true,
      transitionDuration: 0
    };
    if (instance) {
      instance.option(opts);
      instance.reloadItems();
      instance.layout();
    } else {
      cardEls.forEach(card => {
        card.style.left = '';
        card.style.top = '';
        card.style.position = '';
      });
      instance = new Masonry(container, opts);
      if (isProfile) profileMasonry = instance;
      else if (isCreations) creationsMasonry = instance;
      else communityMasonry = instance;
    }
    requestAnimationFrame(() => {
      instance?.layout();
      setFeedLayoutPending(containerId, false);
    });
    bindCommunityGridImageRelayout(containerId);
    };
    if (typeof Masonry !== 'undefined') runMasonryLayout();
    else if (typeof window.ensureMasonryScript === 'function') {
      void window.ensureMasonryScript().then(runMasonryLayout);
    } else runMasonryLayout();
  }

  function renderLikeRewardRules() {
    const el = document.getElementById('publishedRewardRules');
    if (!el) return;
    const rules = window.PointsSystem?.LIKE_MILESTONE_REWARDS || [];
    if (!rules.length) {
      el.innerHTML = '';
      return;
    }
    const items = rules
      .slice()
      .sort((a, b) => b.threshold - a.threshold)
      .map(r => `<li>作品累计 <strong>${r.threshold}</strong> 赞 → 奖励 <strong>${r.credits}</strong> 积分（每人最多 ${r.maxClaimsPerUser} 次）</li>`)
      .join('');
    el.innerHTML = `<h4>点赞奖励规则</h4><ul>${items}</ul><p class="panel-hint">仅对你发布到社区的作品生效，达标后自动发放积分。</p>`;
  }

  function purgeBrokenPublishedPosts() {
    const cardList = window.__promptHubCards || [];
    let changed = false;
    communityPosts = communityPosts.filter((p) => {
      if (!p?.sourceCardId) return true;
      const card = cardList.find((c) => c.id === p.sourceCardId);
      if (!card) return false;
      const ok = isDisplayableImage(card.image || p.image) || isCommunityPromptEligible(card.prompt || p.prompt);
      if (!ok) changed = true;
      return ok;
    });
    if (changed) persistCommunity();
    return changed;
  }

  function isMyCommunityPost(p, user, cardIds) {
    if (!p || p.isMock) return false;
    if (p.sourceCardId && cardIds.has(p.sourceCardId)) return true;
    return String(p.authorId) === String(user.id);
  }

  function getMyPublishedPosts() {
    const user = getActiveUser();
    if (user.id === 'guest') return [];
    purgeBrokenPublishedPosts();
    migrateCommunityAuthorIds();
    const cardIds = new Set((window.__promptHubCards || []).map((c) => c.id));
    const seen = new Set();
    return getAllCommunityPosts()
      .filter(p => isMyCommunityPost(p, user, cardIds) && p.sourceCardId)
      .filter((p) => isDisplayableImage(p.image) || isCommunityPromptEligible(p.prompt))
      .filter((p) => {
        const key = communityPostDedupeKey(p, user.id);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
  }

  function isFollowing(authorId) {
    return follows.has(String(authorId));
  }

  function toggleFollow(authorId, authorName) {
    if (!window.AuthGate?.requireAuth?.('community')) return false;
    const user = getActiveUser();
    const id = String(authorId);
    if (!id || id === user.id || id === 'guest') return false;
    if (follows.has(id)) {
      follows.delete(id);
      toast(`已取消关注 ${authorName || '用户'}`);
      persistFollows();
      syncFollowUI(authorId);
      return false;
    }
    follows.add(id);
    pushCommunityEvent({
      type: 'follow',
      targetUserId: id,
      actorId: user.id,
      actorName: user.name,
      message: `${user.name} 关注了你`
    });
    toast(`已关注 ${authorName || '用户'}`);
    persistFollows();
    syncFollowUI(authorId);
    return true;
  }

  function persistFollows() {
    try {
      localStorage.setItem('promptrepo_follows', JSON.stringify([...follows]));
    } catch (e) { /* ignore */ }
    if (window.SupabaseSync?.isLoggedIn?.()) window.scheduleCloudPush?.();
  }

  function loadFollows() {
    try {
      const raw = localStorage.getItem('promptrepo_follows');
      if (raw) follows = new Set(JSON.parse(raw).map(String));
    } catch (e) { follows = new Set(); }
  }

  function pushCommunityEvent(ev) {
    const user = getActiveUser();
    if (user.id === 'guest' || !ev?.targetUserId || String(ev.targetUserId) === String(user.id)) return;
    communityEvents.push({
      id: genId('ce'),
      type: ev.type,
      targetUserId: String(ev.targetUserId),
      actorId: String(ev.actorId || user.id),
      actorName: ev.actorName || user.name,
      postId: ev.postId || null,
      postTitle: ev.postTitle || '',
      likes: ev.likes || 0,
      message: ev.message || '',
      createdAt: Date.now()
    });
    if (communityEvents.length > 200) communityEvents = communityEvents.slice(-200);
    if (window.SupabaseSync?.isLoggedIn?.()) window.scheduleCloudPush?.();
  }

  function ingestCommunityEvents(events) {
    if (!window.getCommunityNotificationsEnabled?.()) return;
    const user = getActiveUser();
    if (user.id === 'guest' || !Array.isArray(events)) return;
    let added = false;
    for (const ev of events) {
      if (!ev || String(ev.targetUserId) !== String(user.id)) continue;
      if (notifications.some(n => n.id === ev.id)) continue;
      notifications.unshift({
        id: ev.id,
        type: ev.type,
        actorId: ev.actorId,
        actorName: ev.actorName || '用户',
        postId: ev.postId || null,
        postTitle: ev.postTitle || '',
        likes: ev.likes || 0,
        message: ev.message || formatNotifyMessage(ev),
        read: false,
        createdAt: ev.createdAt || Date.now()
      });
      added = true;
    }
    if (added) {
      notifications = notifications.slice(0, 100);
      persistNotifications();
      updateNotifyBadge();
    }
  }

  function mergeNotifications(list) {
    if (!Array.isArray(list)) return;
    const map = new Map(notifications.map(n => [n.id, n]));
    for (const n of list) {
      if (!n?.id) continue;
      const prev = map.get(n.id);
      map.set(n.id, prev ? { ...n, ...prev, read: !!(prev.read && n.read) } : n);
    }
    notifications = [...map.values()].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 100);
    persistNotifications();
    updateNotifyBadge();
  }

  function formatNotifyMessage(n) {
    if (n.type === 'follow') return `${n.actorName || '用户'} 关注了你`;
    if (n.type === 'like') {
      const title = (n.postTitle || '').trim();
      return title ? `${n.actorName || '用户'} 赞了你的作品「${title.slice(0, 20)}」` : `${n.actorName || '用户'} 赞了你的作品`;
    }
    return n.message || '新消息';
  }

  function persistNotifications() {
    try {
      localStorage.setItem('promptrepo_notifications', JSON.stringify(notifications));
    } catch (e) { /* ignore */ }
    if (window.SupabaseSync?.isLoggedIn?.()) window.scheduleCloudPush?.();
  }

  function loadNotifications() {
    try {
      const raw = localStorage.getItem('promptrepo_notifications');
      notifications = raw ? JSON.parse(raw) : [];
    } catch (e) { notifications = []; }
  }

  function unreadNotifyCount() {
    return notifications.filter(n => !n.read).length;
  }

  function updateNotifyBadge() {
    const badge = document.getElementById('communityNotifyBadge');
    if (!badge) return;
    const showBadge = window.getCommunityNotifyBadgeEnabled?.() !== false;
    const n = unreadNotifyCount();
    const visible = showBadge && n > 0;
    badge.textContent = n > 99 ? '99+' : String(n);
    badge.classList.toggle('hidden', !visible);
    badge.setAttribute('aria-hidden', visible ? 'false' : 'true');
  }

  function renderNotifyPanel() {
    const listEl = document.getElementById('communityNotifyList');
    if (!listEl) return;
    if (!notifications.length) {
      listEl.innerHTML = '<p class="community-notify-empty">暂无消息</p>';
      return;
    }
    listEl.innerHTML = notifications.map(n => `
      <button type="button" class="community-notify-item${n.read ? '' : ' unread'}" data-notify-id="${esc(n.id)}" data-post-id="${esc(n.postId || '')}">
        <span class="community-notify-item-title">${esc(n.message || formatNotifyMessage(n))}</span>
        <span class="community-notify-item-time">${esc(formatTime(n.createdAt))}</span>
      </button>`).join('');
    listEl.querySelectorAll('.community-notify-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.notifyId;
        const n = notifications.find(x => x.id === id);
        if (n) n.read = true;
        persistNotifications();
        updateNotifyBadge();
        renderNotifyPanel();
        if (n?.postId) {
          closeNotifyPanel();
          if (typeof switchAppPage === 'function') switchAppPage('community');
          openCommunitySidePanel(n.postId);
        }
      });
    });
  }

  function toggleNotifyPanel() {
    const panel = document.getElementById('communityNotifyPanel');
    if (!panel) return;
    panel.classList.toggle('hidden');
    if (!panel.classList.contains('hidden')) renderNotifyPanel();
  }

  function closeNotifyPanel() {
    document.getElementById('communityNotifyPanel')?.classList.add('hidden');
  }

  function markAllNotificationsRead() {
    notifications.forEach(n => { n.read = true; });
    persistNotifications();
    updateNotifyBadge();
    renderNotifyPanel();
  }

  function syncFollowUI(authorId) {
    const btn = document.getElementById('userProfileFollowBtn');
    if (!btn || String(openProfileAuthorId) !== String(authorId)) return;
    const on = isFollowing(authorId);
    btn.textContent = on ? '已关注' : '关注';
    btn.classList.toggle('active', on);
  }

  function bindAuthorLink(el, authorId, authorName) {
    el.addEventListener('click', e => {
      e.stopPropagation();
      e.preventDefault();
      openUserProfile(authorId, authorName);
    });
  }

  async function renderPostsIntoContainer(posts, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const isProfile = containerId === 'userProfileGrid';
    if (isProfile && profileMasonry) {
      profileMasonry.destroy();
      profileMasonry = null;
    } else if (containerId === 'creationsGrid' && creationsMasonry) {
      creationsMasonry.destroy();
      creationsMasonry = null;
    } else if (!isProfile && communityMasonry) {
      communityMasonry.destroy();
      communityMasonry = null;
    }

    if (!posts.length) {
      container.innerHTML = '<div class="feature-empty" style="grid-column:1/-1;padding:40px"><p>暂无已发布作品</p></div>';
      return;
    }

    const imageRefs = posts.map(p => p.image).filter(Boolean);

    const fragment = document.createDocumentFragment();
    const useGrid = useCssGridForCommunityFeed(containerId);
    if (!useGrid) {
      const sizer = document.createElement('div');
      sizer.className = 'grid-sizer';
      fragment.appendChild(sizer);
    }

    posts.forEach((post, idx) => {
      const div = document.createElement('div');
      div.className = 'card card-enter community-post-card';
      div.style.animationDelay = `${Math.min(idx * 0.045, 0.36)}s`;
      div.dataset.postId = post.id;
      const liked = likedIds.has(post.id);
      const showImage = isDisplayableImage(post.image);
      const titleTrim = (post.title || '').trim();
      const hasRealTitle = titleTrim && !isGenericPostTitle(titleTrim);
      const storageAttr = feedImgStorageAttr(post.image);
      const imgSrc = showImage ? IMG_LOADING_PLACEHOLDER : '';
      const imgLoading = showImage;
      const mediaHtml = showImage
        ? `<div class="card-media${imgLoading ? ' is-loading' : ''}"${imgLoading ? ` data-shine-at="${Date.now()}"` : ''}><img class="card-img" src="${esc(imgSrc)}" data-image-ref="${esc(post.image)}"${storageAttr} loading="lazy" decoding="async" draggable="false" alt="" onload="if(typeof finishCardMediaShine==='function')finishCardMediaShine(this.closest('.card-media'));if(typeof FeatureDraft!=='undefined')FeatureDraft.scheduleLayout('${containerId}')"></div>`
        : '';
      const timeLabel = `♥ ${post.likes || 0}`;
      const promptTrim = (post.prompt || '').trim();
      const headHtml = hasRealTitle
        ? `<div class="card-head"><div class="card-title">${esc(titleTrim)}</div><time class="card-time ${liked ? 'liked' : ''}">${esc(timeLabel)}</time></div>`
        : '';
      const descHtml = promptTrim ? `<div class="card-desc">${esc(promptTrim)}</div>` : '';
      const likeInTags = !hasRealTitle
        ? `<span class="card-time card-time-inline ${liked ? 'liked' : ''}">${esc(timeLabel)}</span>`
        : '';
      div.innerHTML = `
        ${mediaHtml}
        <div class="card-body">
          ${headHtml}
          ${descHtml}
          <div class="card-tags">${likeInTags}
            <button type="button" class="tag community-author-link" data-author-id="${esc(post.authorId)}" data-author-name="${esc(post.authorName)}">${esc(post.authorName)}</button>
          </div>
        </div>`;
      div.addEventListener('click', () => {
        if (containerId === 'userProfileGrid') closeUserProfile();
        if (containerId === 'creationsGrid') {
          openPostSidePanel(post.id, 'creations');
          return;
        }
        openCommunitySidePanel(post.id);
      });
      const authorBtn = div.querySelector('.community-author-link');
      if (authorBtn) bindAuthorLink(authorBtn, post.authorId, post.authorName);
      fragment.appendChild(div);
    });

    container.innerHTML = '';
    setFeedLayoutPending(containerId, true);
    container.appendChild(fragment);
    container.classList.add('cards-grid-primed');
    const renderGen = ++communityFeedRenderGen;
    const finishLayout = () => {
      if (renderGen !== communityFeedRenderGen) return;
      layoutCommunityWhenImagesReady(containerId);
      bindCommunityGridImageRelayout(containerId);
    };
    if (useCssGridForCommunityFeed(containerId)) {
      layoutCommunityMasonry(containerId);
    } else {
      finishLayout();
    }
    window.CardImageLoader?.observeContainer?.(container);
    window.SupabaseSync?.patchImageSrcFromCache?.(container);
    void (async () => {
      const mobile = isMobileFeedLayout();
      const cardLike = posts.map((p) => ({ id: p.sourceCardId || p.id, image: p.image }));
      const prefetchP = imageRefs.length && !window.SupabaseSync?.isLoggedIn?.() && window.SupabaseSync?.prefetchCommunityDisplayUrls
        ? window.SupabaseSync.prefetchCommunityDisplayUrls(imageRefs, mobile ? 8000 : 10000)
        : imageRefs.length && window.SupabaseSync?.prefetchCardsImages
          ? window.SupabaseSync.prefetchCardsImages(cardLike, mobile ? 9000 : 12000)
          : imageRefs.length && window.SupabaseSync?.prefetchDisplayUrlsWithCap
            ? window.SupabaseSync.prefetchDisplayUrlsWithCap(imageRefs, mobile ? 8000 : 10000)
            : imageRefs.length && window.SupabaseSync?.prefetchDisplayUrls
              ? window.SupabaseSync.prefetchDisplayUrls(imageRefs)
              : Promise.resolve();
      const hydrateP = hydrateFeedImages(container);
      await Promise.race([
        prefetchP,
        new Promise((r) => setTimeout(r, mobile ? 280 : 1200))
      ]);
      if (renderGen !== communityFeedRenderGen) return;
      window.SupabaseSync?.patchImageSrcFromCache?.(container);
      window.CardImageLoader?.observeContainer?.(container);
      await hydrateP;
      if (renderGen !== communityFeedRenderGen) return;
      if (useCssGridForCommunityFeed(containerId)) {
        layoutCommunityMasonry(containerId);
      } else {
        finishLayout();
      }
    })();
  }

  function filterAndSortPosts(list) {
    const q = (document.getElementById('communitySearch')?.value || '').toLowerCase();
    let filtered = [...list];
    if (q) {
      filtered = filtered.filter(p =>
        (p.title || '').toLowerCase().includes(q) ||
        (p.prompt || '').toLowerCase().includes(q) ||
        (p.authorName || '').toLowerCase().includes(q)
      );
    }
    if (communityMediaFilter === 'image') {
      filtered = filtered.filter(p => isDisplayableImage(p.image));
    } else if (communityMediaFilter === 'text') {
      filtered = filtered.filter(p => !isDisplayableImage(p.image));
    }
    if (communityScope === 'following') {
      filtered = filtered.filter(p => follows.has(String(p.authorId)));
    }
    if (communitySort === 'new') {
      filtered.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    } else {
      filtered.sort((a, b) => (b.likes || 0) - (a.likes || 0));
    }
    return filtered;
  }

  function renderCommunity() {
    const container = document.getElementById('communityGrid');
    if (!container) return;
    communityFeedRenderGen += 1;
    if (window.__promptHubCards?.length) {
      ensureCommunityFromCards();
    }
    let list = filterAndSortPosts(getAllCommunityPosts());
    if (!list.length) {
      if (communityMasonry) { communityMasonry.destroy(); communityMasonry = null; }
      const syncHint = window.SupabaseSync?.isLoggedIn?.()
        ? '<button type="button" class="btn btn-secondary" onclick="syncCloudNow()">从云端同步</button>'
        : '';
      const emptyMsg = communityScope === 'following'
        ? '暂无关注作者的作品，去社区点头像关注作者吧'
        : '暂无社区内容';
      const backfillBtn = window.SupabaseSync?.isLoggedIn?.()
        ? '<button type="button" class="btn btn-secondary" onclick="(function(){var n=syncEligibleCardsToCommunity();if(n)toast(\'已同步 \'+n+\' 条作品到社区\',4000);else toast(\'没有可同步的作品（提示词需至少 15 字）\',5000);})()">同步卡片库作品</button>'
        : '';
      container.innerHTML = `<div class="feature-empty"><p>${emptyMsg}</p><p class="panel-hint">在卡片库编辑作品并开启「发布到提示词社区」后保存；或点下方一键同步（提示词≥15字）</p><button type="button" class="btn btn-primary" onclick="switchAppPage('warehouse')">去卡片库发布</button>${backfillBtn}${syncHint}</div>`;
      return;
    }
    void renderPostsIntoContainer(list, 'communityGrid');
  }

  function renderUserProfileGrid() {
    if (!openProfileAuthorId) return;
    const posts = getPostsByAuthor(openProfileAuthorId);
    posts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    void renderPostsIntoContainer(posts, 'userProfileGrid');
  }

  function openUserProfile(authorId, authorName) {
    if (!authorId) return;
    openProfileAuthorId = authorId;
    const posts = getPostsByAuthor(authorId);
    const overlay = document.getElementById('userProfileOverlay');
    const titleEl = document.getElementById('userProfileTitle');
    const subEl = document.getElementById('userProfileSub');
    const avatarEl = document.getElementById('userProfileAvatar');
    if (titleEl) titleEl.textContent = authorName || '用户';
    if (subEl) subEl.textContent = `已发布 ${posts.length} 个提示词`;
    if (avatarEl) avatarEl.textContent = ((authorName || '?')[0] || '?').toUpperCase();
    const followBtn = document.getElementById('userProfileFollowBtn');
    const me = getActiveUser();
    if (followBtn) {
      if (me.id === 'guest' || String(authorId) === String(me.id)) {
        followBtn.classList.add('hidden');
      } else {
        followBtn.classList.remove('hidden');
        syncFollowUI(authorId);
        followBtn.onclick = (e) => {
          e.stopPropagation();
          toggleFollow(authorId, authorName);
        };
      }
    }
    closeCommunityDetail();
    renderUserProfileGrid();
    if (window.AppModalHub?.open) window.AppModalHub.open('userProfileOverlay');
    else overlay?.classList.add('active');
  }

  function closeUserProfile() {
    if (window.AppModalHub?.close) window.AppModalHub.close('userProfileOverlay');
    else document.getElementById('userProfileOverlay')?.classList.remove('active');
    openProfileAuthorId = null;
    if (profileMasonry) {
      profileMasonry.destroy();
      profileMasonry = null;
    }
  }
  window.closeUserProfile = closeUserProfile;

  function syncCardToCommunity(card, publish, opts = {}) {
    if (!card?.id) return;
    const silent = opts.silent === true;
    const keepPublishFlag = opts.keepPublishFlag === true;
    let idx = card.communityPostId
      ? communityPosts.findIndex(p => p.id === card.communityPostId)
      : -1;
    if (idx < 0) {
      idx = communityPosts.findIndex(p => p.sourceCardId === card.id);
    }
    if (!publish) {
      if (idx >= 0) {
        communityPosts.splice(idx, 1);
        persistCommunity();
      }
      card.publishedToCommunity = false;
      card.communityPostId = null;
      return;
    }
    const promptTrim = (card.prompt || '').trim();
    if (!promptTrim) {
      if (!silent) toast('发布到社区需要填写提示词');
      if (!keepPublishFlag) {
        card.publishedToCommunity = false;
        card.communityPostId = null;
      }
      return;
    }
    if (promptTrim.length < MIN_COMMUNITY_PROMPT_LEN) {
      if (!silent) toast(`发布到社区需要提示词至少 ${MIN_COMMUNITY_PROMPT_LEN} 字`);
      if (!keepPublishFlag) {
        card.publishedToCommunity = false;
        card.communityPostId = null;
      }
      return;
    }
    const user = getActiveUser();
    const post = {
      id: card.communityPostId || genId('cp'),
      sourceCardId: card.id,
      authorId: user.id,
      authorName: user.name,
      title: (card.title || '').trim() || '',
      prompt: card.prompt || '',
      image: card.image || null,
      likes: idx >= 0 ? (communityPosts[idx].likes || 0) : 0,
      createdAt: idx >= 0 ? communityPosts[idx].createdAt : Date.now(),
      updatedAt: Date.now()
    };
    if (idx >= 0) communityPosts[idx] = post;
    else communityPosts.push(post);
    card.publishedToCommunity = true;
    window.TrialTasksUI?.syncTaskProgress?.(true);
    card.communityPostId = post.id;
    persistCommunity();
    renderCommunity();
    if (openProfileAuthorId === user.id) renderUserProfileGrid();
    checkOwnPostMilestones(post.id);
  }

  function removeCommunityByCardId(cardId) {
    const i = communityPosts.findIndex(p => p.sourceCardId === cardId);
    if (i >= 0) {
      const postId = communityPosts[i].id;
      performCommunityPostRemoval(postId, { silent: true });
    }
  }

  function confirmDeleteCommunityPost(id) {
    toast('社区作品与其他人一视同仁。请到卡片库关闭「发布到社区」或删除对应卡片');
  }

  function performCommunityPostRemoval(id, opts = {}) {
    const post = findPost(id);
    if (!post) return;
    if (typeof window.recordCommunityPostDeletion === 'function') {
      window.recordCommunityPostDeletion(id);
    }
    const authorId = post.authorId;
    if (post.sourceCardId) {
      const card = window.__promptHubCards?.find(c => c.id === post.sourceCardId);
      if (card) {
        syncCardToCommunity(card, false);
        if (typeof window.persistPromptHubCards === 'function') void window.persistPromptHubCards();
      } else {
        communityPosts = communityPosts.filter(p => p.id !== id);
        persistCommunity();
      }
    } else {
      communityPosts = communityPosts.filter(p => p.id !== id);
      persistCommunity();
    }
    const cIdx = creations.findIndex(c => c.communityPostId === id);
    if (cIdx >= 0) {
      creations[cIdx].visibility = 'private';
      creations[cIdx].communityPostId = null;
      creations[cIdx].permanent = false;
      persistCreations();
    }
    likedIds.delete(id);
    favIds.delete(id);
    persistLikes();
    if (communitySidePostId === id) closeCommunitySidePanel();
    renderCommunity();
    if (openProfileAuthorId === authorId) renderUserProfileGrid();
    if (document.getElementById('pageImageGen')?.classList.contains('active')) renderImageGenFeed();
    if (!opts.silent) toast('已从社区删除');
  }

  function setPublishCheckbox(card) {
    const btn = document.getElementById('cardPublishToggle');
    if (!btn) return;
    if (card) {
      cardPublishSessionOverride = null;
      const on = !!card.publishedToCommunity;
      btn.classList.toggle('is-on', on);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      return;
    }
    cardPublishSessionOverride = null;
    syncCardPublishFromPrompt(getCardFormPromptText());
  }

  function readPublishCheckbox() {
    if (cardPublishSessionOverride !== null) return cardPublishSessionOverride;
    return document.getElementById('cardPublishToggle')?.classList.contains('is-on');
  }

  function bindPublishToggle() {
    const btn = document.getElementById('cardPublishToggle');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const willOn = !btn.classList.contains('is-on');
      cardPublishSessionOverride = willOn;
      btn.classList.toggle('is-on', willOn);
      btn.setAttribute('aria-pressed', willOn ? 'true' : 'false');
    });
  }

  function findPost(id) {
    return getAllCommunityPosts().find(p => p.id === id);
  }

  /** 点赞（仅增加一次），返回是否为新点赞 */
  function ensureLike(id) {
    if (!window.AuthGate?.requireAuth?.('community')) return false;
    const post = findPost(id);
    if (!post) return false;
    const user = getActiveUser();
    if (user.id !== 'guest' && post.authorId === user.id) {
      toast('不能给自己的作品点赞');
      return false;
    }
    if (likedIds.has(id)) return false;
    likedIds.add(id);
    if (!post.isMock) {
      const p = communityPosts.find(x => x.id === id);
      if (p) p.likes = (p.likes || 0) + 1;
    } else {
      post.likes = (post.likes || 0) + 1;
    }
    persistLikes();
    persistCommunity();
    if (post.authorId !== user.id) {
      pushCommunityEvent({
        type: 'like',
        targetUserId: post.authorId,
        actorId: user.id,
        actorName: user.name,
        postId: id,
        postTitle: post.title || (post.prompt || '').slice(0, 24),
        likes: post.likes || 0,
        message: `${user.name} 赞了你的作品`
      });
    }
    window.PointsSystem?.onPostLikesUpdated?.(post, getActiveUser);
    patchCommunityLikeUI(id);
    patchCommunitySidePanelUI(id);
    if (document.getElementById('pageImageGen')?.classList.contains('active')) {
      document.querySelectorAll(`.imagegen-feed-like[data-like-id="${id}"]`).forEach(btn => {
        btn.textContent = `♥ ${post.likes || 0}`;
        btn.classList.add('liked');
      });
    }
    return true;
  }

  function checkOwnPostMilestones(postId) {
    const post = findPost(postId);
    if (post) window.PointsSystem?.onPostLikesUpdated?.(post, getActiveUser);
  }

  function highlightCommunityCard(id) {
    document.querySelectorAll('#communityGrid .community-post-card').forEach(el => {
      el.classList.toggle('selected', el.dataset.postId === id);
    });
  }

  async function renderCommunitySidePanel(id, opts = {}) {
    const post = findPost(id);
    const bodyId = opts.bodyId || 'communitySideBody';
    const titleId = opts.titleId || 'communitySideTitle';
    const body = document.getElementById(bodyId);
    const titleEl = document.getElementById(titleId);
    if (!post || !body) return;
    if (titleEl) titleEl.textContent = getPostSideTitle(post);
    const faved = favIds.has(id);
    const liked = likedIds.has(id);
    const storageAttr = feedImgStorageAttr(post.image);
    const showSideImg = post.image && isDisplayableImage(post.image);
    const sideInitial = showSideImg ? communityImgInitialSrc(post.image) : '';
    const imgBlock = showSideImg
      ? `<button type="button" class="community-side-img-btn" data-side-zoom title="点击放大"><img class="community-side-img" src="${esc(sideInitial)}" data-image-ref="${esc(post.image)}"${storageAttr} alt=""></button>`
      : '';
    body.innerHTML = `
      ${imgBlock}
      <p class="community-side-author">
        <button type="button" class="community-detail-author-btn" data-author-id="${esc(post.authorId)}" data-author-name="${esc(post.authorName)}">${esc(post.authorName)}</button>
        · ${esc(formatTime(post.createdAt))}
      </p>
      <div class="community-side-prompt">${esc(post.prompt)}</div>
      <div class="community-side-stats">
        <span>♥ ${post.likes || 0} 点赞</span>
        <span>${faved ? '已收藏' : '未收藏'}</span>
      </div>
      <div class="community-side-actions">
        <button type="button" class="btn btn-secondary" data-action="like">♥ ${liked ? '已点赞' : '点赞'}</button>
        <button type="button" class="btn btn-secondary" data-action="copy">复制</button>
        <button type="button" class="btn btn-secondary" data-action="fav">${faved ? '已收藏' : '收藏'}</button>
        <button type="button" class="btn btn-primary" data-action="remix">制作同款</button>
      </div>
      <p class="panel-hint">点赞、收藏、制作同款需单独点击；「复制」仅复制提示词。自己的作品请到卡片库下架或删除</p>`;
    body.querySelector('[data-action="like"]')?.addEventListener('click', () => likeCommunityPostOnly(id));
    body.querySelector('[data-action="copy"]')?.addEventListener('click', () => copyPostPrompt(post));
    body.querySelector('[data-action="fav"]')?.addEventListener('click', () => favoritePost(id, post));
    body.querySelector('[data-action="remix"]')?.addEventListener('click', () => remixToImageGen(post));
    body.querySelector('[data-side-zoom]')?.addEventListener('click', () => {
      void (async () => {
        const url = await resolveImageDisplayUrl(post.image, null, id);
        if (url && typeof window.openLightbox === 'function') window.openLightbox(url);
        else toast('图片尚未加载完成，请稍候再试');
      })();
    });
    const authorBtn = body.querySelector('.community-detail-author-btn');
    if (authorBtn) bindAuthorLink(authorBtn, post.authorId, post.authorName);
    highlightCommunityCard(id);
    if (showSideImg) await hydrateFeedImages(body);
    const timeEl = document.querySelector(`#communityGrid .card[data-post-id="${id}"] .card-time`);
    if (timeEl) {
      timeEl.textContent = `♥ ${post.likes || 0}`;
      if (likedIds.has(id)) timeEl.classList.add('liked');
    }
  }

  function isMobileFeaturePanel() {
    return window.MobileUI?.isMobile?.() || window.matchMedia('(max-width: 900px)').matches;
  }

  function mountFeatureSidePanel(panelId) {
    const panel = document.getElementById(panelId);
    if (!panel || !isMobileFeaturePanel()) return;
    if (panel.dataset.mountedOnBody === '1') return;
    panel._phOriginalParent = panel.parentElement;
    panel._phOriginalNext = panel.nextSibling;
    document.body.appendChild(panel);
    panel.dataset.mountedOnBody = '1';
  }

  function unmountFeatureSidePanel(panelId) {
    const panel = document.getElementById(panelId);
    if (!panel || panel.dataset.mountedOnBody !== '1') return;
    const parent = panel._phOriginalParent;
    if (parent) {
      if (panel._phOriginalNext && panel._phOriginalNext.parentNode === parent) {
        parent.insertBefore(panel, panel._phOriginalNext);
      } else {
        parent.appendChild(panel);
      }
    }
    delete panel.dataset.mountedOnBody;
  }

  function openPostSidePanel(id, ctx) {
    const post = findPost(id);
    if (!post) return;
    const isCreations = ctx === 'creations';
    communitySidePostId = id;
    openPostId = id;
    const panelId = isCreations ? 'creationsSidePanel' : 'communitySidePanel';
    mountFeatureSidePanel(panelId);
    document.getElementById(panelId)?.classList.remove('hidden');
    document.body.classList.add('community-panel-open');
    if (isMobileFeaturePanel()) {
      window.MobileUI?.closeDrawers?.();
    }
    void renderCommunitySidePanel(id, {
      bodyId: isCreations ? 'creationsSideBody' : 'communitySideBody',
      titleId: isCreations ? 'creationsSideTitle' : 'communitySideTitle'
    });
    requestAnimationFrame(() => scheduleCommunityLayout(isCreations ? 'creationsGrid' : 'communityGrid'));
  }

  function openCommunitySidePanel(id) {
    openPostSidePanel(id, 'community');
  }

  function closeCommunitySidePanel() {
    document.getElementById('communitySidePanel')?.classList.add('hidden');
    unmountFeatureSidePanel('communitySidePanel');
    const creationsOpen = !document.getElementById('creationsSidePanel')?.classList.contains('hidden');
    if (!creationsOpen) document.body.classList.remove('community-panel-open');
    communitySidePostId = null;
    openPostId = null;
    document.querySelectorAll('#communityGrid .community-post-card.selected').forEach(el => el.classList.remove('selected'));
  }

  function openCommunityDetail(id) {
    if (document.getElementById('pageCommunity')?.classList.contains('active')) {
      openCommunitySidePanel(id);
      return;
    }
    openCommunitySidePanel(id);
  }

  function closeCommunityDetail() {
    closeCommunitySidePanel();
  }

  function copyPostPromptOnly(post) {
    if (!window.AuthGate?.requireAuth?.('copy')) return;
    const text = post?.prompt || '';
    if (!text) { toast('暂无提示词'); return; }
    navigator.clipboard.writeText(text).then(() => toast('已复制提示词'));
  }

  function copyPostPrompt(post) {
    copyPostPromptOnly(post);
  }

  function favoritePost(id, post) {
    if (!window.AuthGate?.requireAuth?.('community')) return;
    ensureLike(id);
    if (favIds.has(id)) {
      toast('已在卡片库中');
      if (communitySidePostId === id) patchCommunitySidePanelUI(id);
      return;
    }
    favIds.add(id);
    addCardFromPost(post);
    persistFavs();
    toast('已收藏到卡片库，已为作者点赞');
    if (communitySidePostId === id) patchCommunitySidePanelUI(id);
  }

  function addCardFromPost(post) {
    if (typeof window.addCardFromCommunity === 'function') {
      window.addCardFromCommunity(post);
    }
  }

  function remixToImageGen(post) {
    closeCommunitySidePanel();
    if (typeof switchAppPage === 'function') switchAppPage('imagegen');
    imageGenFeedTab = 'community';
    document.querySelectorAll('[data-feed-tab]').forEach(b => {
      b.classList.toggle('active', b.dataset.feedTab === 'community');
    });
    updateImageGenFeedHint();
    fillFromCommunityPost(post, true);
  }

  function saveGeneratedToWarehouse(opts) {
    if (!opts?.image && !(opts?.prompt || '').trim()) {
      toast('暂无内容可保存');
      return Promise.resolve(false);
    }
    return Promise.resolve(window.addCardFromGenerated?.({
      prompt: opts.prompt,
      image: opts.image,
      sourceId: opts.sourceId,
      jobId: opts.jobId || null,
      title: opts.title,
      publishToCommunity: !!opts.publishToCommunity,
      silentToast: !!opts.silentToast
    })).then((r) => r?.ok ?? false);
  }

  const LS_SESSION_GEN_JOBS = 'promptrepo_session_gen_jobs';

  function getSessionGenJobIds() {
    try {
      const raw = sessionStorage.getItem(LS_SESSION_GEN_JOBS);
      const list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list.map(String) : [];
    } catch (e) {
      return [];
    }
  }

  function trackSessionGenJob(jobId) {
    if (!jobId) return;
    const id = String(jobId);
    const list = getSessionGenJobIds().filter((x) => x !== id);
    list.push(id);
    while (list.length > 40) list.shift();
    try {
      sessionStorage.setItem(LS_SESSION_GEN_JOBS, JSON.stringify(list));
    } catch (e) { /* ignore */ }
  }

  function clearSessionGenJob(jobId) {
    if (!jobId) return;
    const id = String(jobId);
    const list = getSessionGenJobIds().filter((x) => x !== id);
    try {
      sessionStorage.setItem(LS_SESSION_GEN_JOBS, JSON.stringify(list));
    } catch (e) { /* ignore */ }
  }

  function isSessionGenJob(jobId) {
    return jobId && getSessionGenJobIds().includes(String(jobId));
  }

  function hasWarehouseCardForJob(jobId) {
    if (!jobId) return false;
    const card = (window.__promptHubCards || []).find((c) => c.genJobId === jobId);
    if (!card?.image) return false;
    if (!isDisplayableImage(card.image)) return false;
    return true;
  }

  async function repairWarehouseCardImageFromJob(card, imageUrl, jobId) {
    if (!card?.id || !imageUrl) return false;
    let stored = imageUrl;
    if (window.SupabaseSync?.persistGenerationImage) {
      try {
        stored = await window.SupabaseSync.persistGenerationImage(card.id, imageUrl);
      } catch (e) {
        console.warn('恢复生图：归档到 Storage 失败，使用任务链接', e);
      }
    }
    card.image = stored || imageUrl;
    card.updatedAt = Date.now();
    if (typeof window.persistPromptHubCards === 'function') await window.persistPromptHubCards();
    return true;
  }

  /** 用户删卡片时：标记 job 已删，避免 API 恢复把它拉回来 */
  function onCardDeletedForGen(card) {
    if (!card) return;
    const jobId = card.genJobId;
    if (jobId) {
      window.recordGenerationJobDeletion?.(jobId);
      clearSessionGenJob(jobId);
      const cre = creations.find((c) => c.jobId === jobId);
      if (cre) recordCreationDeletion(cre.id, jobId);
    }
  }

  async function listRecoverableOrphanJobs() {
    if (!window.PromptHubApi?.listRecentGenerationJobs) return [];
    const r = await window.PromptHubApi.listRecentGenerationJobs();
    if (!r?.ok || !Array.isArray(r.data?.jobs)) return [];
    return r.data.jobs.filter((job) => {
      if (!job?.id || job.status !== 'completed' || !job.imageUrl) return false;
      if (isGenerationJobDeleted(job.id)) return false;
      if (hasWarehouseCardForJob(job.id)) return false;
      if (creations.some((c) => c.jobId === job.id)) return false;
      return true;
    });
  }

  async function recoverLostGenerationsManual() {
    if (!window.AuthGate?.requireAuth?.('imagegen')) return;
    const orphans = await listRecoverableOrphanJobs();
    if (!orphans.length) {
      toast('没有可恢复的生图（您删除过的不会出现在此列表）');
      return;
    }
    const sample = orphans.slice(0, 2).map((j) => (j.prompt || '').slice(0, 20)).join('、');
    const extra = orphans.length > 2 ? ` 等 ${orphans.length} 张` : '';
    const msg = `服务器上有 ${orphans.length} 张本地缺失的生图（${sample}${extra}）。\n恢复后写入卡片仓库；您已删除的生图不会被恢复。`;
    const run = () => void recoverRecentGenerationJobs({ manual: true });
    if (typeof window.customConfirm === 'function') window.customConfirm(msg, run);
    else if (confirm(msg)) run();
  }

  function highlightCreationCard(id) {
    document.querySelectorAll('#creationsGrid .creation-post-card').forEach(el => {
      el.classList.toggle('selected', el.dataset.creationId === id);
    });
  }

  async function renderCreationsSidePanel(id) {
    const body = document.getElementById('creationsSideBody');
    const c = creations.find(x => x.id === id);
    if (!body || !c) return;
    const badge = c.visibility === 'published' ? '已发布' : '私密';
    const storageAttr = feedImgStorageAttr(c.image);
    const jobAttr = c.jobId ? ` data-job-id="${esc(c.jobId)}"` : '';
    const showImg = c.image && isDisplayableImage(c.image);
    const imgHtml = showImg
      ? `<button type="button" class="community-side-img-btn" data-side-zoom title="点击放大"><img class="community-side-img" src="${IMG_LOADING_PLACEHOLDER}" data-image-ref="${esc(c.image)}"${storageAttr}${jobAttr} alt=""></button>`
      : '';
    body.innerHTML = `
      ${imgHtml}
      <p class="community-side-author">${esc(badge)} · ${esc((c.resolution || '1k').toUpperCase())} · ${esc(formatExpiryLabel(c))}</p>
      <div class="community-side-prompt">${esc(c.prompt || '')}</div>
      <div class="community-side-actions">
        <button type="button" class="btn btn-secondary" data-action="remix">再生成</button>
        <button type="button" class="btn btn-secondary" data-action="del">删除记录</button>
      </div>
      <p class="panel-hint">生成记录保留 1～3 天。发布到社区请打开卡片库对应卡片并开启「发布到提示词社区」</p>`;
    body.querySelector('[data-side-zoom]')?.addEventListener('click', () => {
      void (async () => {
        const url = await resolveImageDisplayUrl(c.image, c.jobId || null, id);
        if (url && typeof window.openLightbox === 'function') window.openLightbox(url);
        else toast('图片尚未加载完成，请稍候再试');
      })();
    });
    body.querySelector('[data-action="remix"]')?.addEventListener('click', () => remixCreation(id));
    body.querySelector('[data-action="del"]')?.addEventListener('click', () => {
      const doDel = () => {
        deleteCreation(id);
        closeCreationsSidePanel();
      };
      if (typeof window.customConfirm === 'function') {
        window.customConfirm('确定删除该创作？无回收站，删除后不可恢复。', doDel);
      } else if (confirm('确定删除该创作？')) doDel();
    });
    highlightCreationCard(id);
    if (showImg) await hydrateFeedImages(body);
  }

  function openCreationsSidePanel(id) {
    const c = creations.find(x => x.id === id);
    if (!c) return;
    creationsSideId = id;
    mountFeatureSidePanel('creationsSidePanel');
    document.getElementById('creationsSidePanel')?.classList.remove('hidden');
    document.body.classList.add('community-panel-open');
    if (isMobileFeaturePanel()) window.MobileUI?.closeDrawers?.();
    void renderCreationsSidePanel(id);
    scheduleCommunityLayout('creationsGrid');
  }

  function closeCreationsSidePanel() {
    document.getElementById('creationsSidePanel')?.classList.add('hidden');
    unmountFeatureSidePanel('creationsSidePanel');
    document.body.classList.remove('community-panel-open');
    creationsSideId = null;
    communitySidePostId = null;
    openPostId = null;
    document.querySelectorAll('#creationsGrid .community-post-card.selected').forEach(el => el.classList.remove('selected'));
  }

  async function renderCreations() {
    const container = document.getElementById('creationsGrid');
    const hintEl = document.getElementById('creationsHint');
    if (!container) return;
    renderLikeRewardRules();
    const user = getActiveUser();
    if (window.__promptHubCards?.length) {
      ensureCommunityFromCards();
      if (typeof window.persistPromptHubCards === 'function') {
        void window.persistPromptHubCards();
      }
    } else {
      dedupeCommunityPosts();
      migrateCommunityAuthorIds();
    }
    if (hintEl) {
      hintEl.textContent = user.id === 'guest'
        ? '登录后在此查看你发布到社区的作品'
        : '你在卡片库公开到社区的作品 · 点击卡片查看详情与点赞数';
    }
    if (creationsMasonry) {
      creationsMasonry.destroy();
      creationsMasonry = null;
    }
    if (user.id === 'guest') {
      closeCreationsSidePanel();
      container.innerHTML = '<div class="feature-empty"><p>请先登录后查看发布作品</p><button type="button" class="btn btn-primary" onclick="openAuthModal()">登录</button></div>';
      return;
    }
    const list = getMyPublishedPosts();
    if (!list.length) {
      closeCreationsSidePanel();
      container.innerHTML = '<div class="feature-empty"><p>暂无发布作品</p><p class="panel-hint">在卡片库保存作品并开启「发布到提示词社区」，或在生图页开启「生成后公开」</p><button type="button" class="btn btn-primary" onclick="switchAppPage(\'warehouse\')">去卡片库</button><button type="button" class="btn btn-secondary" onclick="(function(){var n=syncEligibleCardsToCommunity();if(n)toast(\'已同步 \'+n+\' 条作品\',4000);else toast(\'没有可同步的作品（提示词需至少 15 字）\',5000);})()">同步卡片库作品</button></div>';
      return;
    }
    void renderPostsIntoContainer(list, 'creationsGrid');
  }

  function publishCreation(id, opts) {
    toast('发布到社区请先在卡片库保存该作品，并开启「发布到提示词社区」');
  }

  function confirmDeleteCreation(id) {
    const msg = '确定删除该生成记录？无回收站，删除后不可恢复。';
    const doDel = () => deleteCreation(id);
    if (typeof window.customConfirm === 'function') window.customConfirm(msg, doDel);
    else if (confirm(msg)) doDel();
  }

  function recordCreationDeletion(id, jobId) {
    if (id == null) return;
    try {
      const key = 'promptrepo_deleted_creations';
      const raw = localStorage.getItem(key);
      const map = raw ? JSON.parse(raw) : {};
      map[String(id)] = Date.now();
      localStorage.setItem(key, JSON.stringify(map));
    } catch (e) { /* ignore */ }
    if (typeof window.recordCreationDeletionGlobal === 'function') {
      window.recordCreationDeletionGlobal(id, jobId);
    }
  }

  function deleteCreation(id) {
    if (creationsSideId === id) closeCreationsSidePanel();
    if (imageGenPreviewId === id) closeImageGenPreview();
    const removed = creations.find(c => c.id === id);
    if (removed?.communityPostId) {
      const post = findPost(removed.communityPostId);
      if (post?.sourceCreationId === id && !post?.sourceCardId) {
        performCommunityPostRemoval(removed.communityPostId, { silent: true });
      }
    }
    recordCreationDeletion(id, removed?.jobId);
    creations = creations.filter(c => c.id !== id);
    persistCreations();
    if (window.SupabaseSync?.isLoggedIn?.() && typeof window.pushToCloud === 'function') {
      void window.pushToCloud({ skipSafety: true }).catch(() => {
        if (typeof window.scheduleCloudPush === 'function') window.scheduleCloudPush();
      });
    }
    renderCreations();
    if (document.getElementById('pageImageGen')?.classList.contains('active')) {
      renderImageGenFeed();
    }
    toast('已删除');
  }

  function remixCreation(id) {
    const c = creations.find(x => x.id === id);
    if (!c) return;
    if (typeof switchAppPage === 'function') switchAppPage('imagegen');
    imageGenFeedTab = 'warehouse';
    document.querySelectorAll('[data-feed-tab]').forEach(b => {
      b.classList.toggle('active', b.dataset.feedTab === 'warehouse');
    });
    updateImageGenFeedHint();
    applyHistoryToForm(c);
  }

  function initImageGenForm() {
    const draft = loadJson(LS_IMAGEGEN, null);
    if (draft) {
      const promptEl = document.getElementById('imageGenPrompt');
      if (promptEl && draft.prompt) promptEl.value = draft.prompt;
      if (draft.refImages?.length) setImageGenRefs(draft.refImages);
      else if (draft.refImage) setImageGenRefs([draft.refImage]);
      else clearImageGenRef();
      const resEl = document.getElementById('imageGenResolution');
      if (resEl && draft.resolution) resEl.value = draft.resolution;
      const qEl = document.getElementById('imageGenQuality');
      if (qEl && draft.quality) qEl.value = draft.quality;
      const modelEl = document.getElementById('imageGenModel');
      if (modelEl && draft.model) modelEl.value = draft.model;
      const szEl = document.getElementById('imageGenSize');
      if (szEl && draft.size) szEl.value = draft.size;
    }
    bindImageGenUpload();
    bindImageGenGenPublic();
    syncImageGenGenPublicUI();
    updateImageGenPricingUI();
    applyImageGenPrefill();
    updateImageGenFeedHint();
    syncImageGenGenPublicFromPrompt();
    renderImageGenFeed();
    window.PointsSystem?.updateCreditsUI?.();
  }

  function getImageGenQuality() {
    return document.getElementById('imageGenQuality')?.value || 'standard';
  }

  function getImageGenModel() {
    return document.getElementById('imageGenModel')?.value || 'quanneng2';
  }

  function normalizeImageGenResolution(res) {
    const r = String(res || '1k').toLowerCase();
    return ['1k', '2k', '4k'].includes(r) ? r : '1k';
  }

  function getImageGenFormMeta() {
    const rawRes = document.getElementById('imageGenResolution')?.value || '1k';
    return {
      model: getImageGenModel(),
      resolution: normalizeImageGenResolution(rawRes),
      quality: getImageGenQuality(),
      size: document.getElementById('imageGenSize')?.value || '1:1'
    };
  }

  function getImageGenPrimaryRef() {
    return imageGenRefImages[0] || null;
  }

  function updateImageGenResolutionSelect() {
    const sel = document.getElementById('imageGenResolution');
    if (!sel) return;
    const current = sel.value || '1k';
    const resolutions = ['1k', '2k', '4k'];
    sel.innerHTML = '';
    resolutions.forEach(res => {
      const opt = document.createElement('option');
      opt.value = res;
      opt.textContent = res.toUpperCase();
      sel.appendChild(opt);
    });
    if (resolutions.includes(current)) sel.value = current;
    else sel.value = '1k';
  }

  function getImageGenAutoPublishDefault() {
    return window.getDefaultImageGenAutoPublish?.() !== false;
  }

  function syncImageGenAutoPublishUI() {
    const btn = document.getElementById('imageGenAutoPublishBtn');
    if (!btn) return;
    const globalOn = getImageGenAutoPublishDefault();
    const on = imageGenAutoPublishSession === null ? globalOn : imageGenAutoPublishSession;
    btn.classList.toggle('is-on', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function isImageGenAutoPublishChecked() {
    return document.getElementById('imageGenAutoPublishBtn')?.classList.contains('is-on') === true;
  }

  function bindImageGenAutoPublish() {
    const btn = document.getElementById('imageGenAutoPublishBtn');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => {
      const on = !btn.classList.contains('is-on');
      btn.classList.toggle('is-on', on);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      imageGenAutoPublishSession = on;
    });
  }

  function getImageGenAutoSaveDefault() {
    return window.getDefaultImageGenAutoSaveWarehouse?.() !== false;
  }

  function syncImageGenAutoSaveUI() {
    const btn = document.getElementById('imageGenAutoSaveBtn');
    if (!btn) return;
    const globalOn = getImageGenAutoSaveDefault();
    const on = imageGenAutoSaveSession === null ? globalOn : imageGenAutoSaveSession;
    btn.classList.toggle('is-on', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function isImageGenAutoSaveChecked() {
    return document.getElementById('imageGenAutoSaveBtn')?.classList.contains('is-on') === true;
  }

  function bindImageGenAutoSave() {
    const btn = document.getElementById('imageGenAutoSaveBtn');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => {
      const on = !btn.classList.contains('is-on');
      btn.classList.toggle('is-on', on);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      imageGenAutoSaveSession = on;
    });
  }

  function getImageGenGenPublicDefault() {
    return window.getDefaultImageGenAutoPublish?.() !== false;
  }

  function syncImageGenGenPublicFromPrompt() {
    const btn = document.getElementById('imageGenGenPublicBtn');
    if (!btn) return;
    if (imageGenGenPublicSession !== null) {
      btn.classList.toggle('is-on', imageGenGenPublicSession);
      btn.setAttribute('aria-pressed', imageGenGenPublicSession ? 'true' : 'false');
      return;
    }
    const prompt = document.getElementById('imageGenPrompt')?.value || '';
    const on = computeAutoCommunityToggle(prompt, getImageGenGenPublicDefault(), null);
    btn.classList.toggle('is-on', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function syncImageGenGenPublicUI() {
    syncImageGenGenPublicFromPrompt();
  }

  function isImageGenGenPublicChecked() {
    const btn = document.getElementById('imageGenGenPublicBtn');
    if (!btn) return getImageGenGenPublicDefault();
    return btn.classList.contains('is-on');
  }

  function bindImageGenGenPublic() {
    const btn = document.getElementById('imageGenGenPublicBtn');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const willOn = !btn.classList.contains('is-on');
      imageGenGenPublicSession = willOn;
      btn.classList.toggle('is-on', willOn);
      btn.setAttribute('aria-pressed', willOn ? 'true' : 'false');
    });
  }

  function restoreImageGenSubmitLabel() {
    updateImageGenCostHint();
  }

  let imageGenCostHintSeq = 0;
  let imageGenCostDebounceTimer = null;

  function applyImageGenCostDisplay(detail, final, quality, size) {
    const hint = document.getElementById('imageGenCostHint');
    const btn = document.getElementById('imageGenSubmit');
    if (btn && !btn.disabled) {
      btn.textContent = `生成图片 · ${final} 积分`;
    }
    if (!hint) return;
    const modelLabel = detail?.modelLabel || '全能模型2';
    const sizeLabel =
      document.getElementById('imageGenSize')?.selectedOptions?.[0]?.textContent?.trim() || size;
    const qualLabel =
      { standard: '标准', high: '高清', ultra: '超清' }[quality] || quality;
    const parts = [modelLabel, qualLabel, sizeLabel];
    if (detail?.saved > 0 && detail.label) {
      parts.push(`会员${detail.label} 省 ${detail.saved}`);
    } else if (detail?.fixed) {
      parts.push('固定价');
    }
    if (imageGenRefImages.length) {
      parts.push(`参考图 ${imageGenRefImages.length} 张`);
    }
    hint.textContent = parts.join(' · ');
  }

  function updateImageGenCostHint() {
    const { model, resolution, quality, size } = getImageGenFormMeta();
    const detail = window.PointsSystem?.getImageGenCostDetail?.(model, resolution);
    const final = detail?.final ?? 10;
    applyImageGenCostDisplay(detail, final, quality, size);
    clearTimeout(imageGenCostDebounceTimer);
    imageGenCostDebounceTimer = setTimeout(() => {
      void refreshImageGenCostFromApi(model, resolution, quality, size);
    }, 800);
  }

  async function refreshImageGenCostFromApi(model, resolution, quality, size) {
    if (!window.PointsSystem?.useApiForAccount?.()) return;
    const seq = ++imageGenCostHintSeq;
    try {
      const quote = await window.PromptHubApi.getGenerationCost(resolution, quality, model);
      if (seq !== imageGenCostHintSeq) return;
      if (!quote.ok || quote.data?.final == null) return;

      const local = window.PointsSystem?.getImageGenCostDetail?.(model, resolution);
      const expectedBase = local?.base;
      if (quote.data.base != null && expectedBase != null && quote.data.base !== expectedBase) {
        return;
      }

      const detail = Object.assign({}, local || {}, {
        base: quote.data.base ?? local?.base,
        final: quote.data.final,
        saved:
          quote.data.base != null && quote.data.base > quote.data.final
            ? quote.data.base - quote.data.final
            : local?.saved,
        label: quote.data.discountLabel || local?.label,
        modelLabel: quote.data.modelLabel || local?.modelLabel
      });
      applyImageGenCostDisplay(detail, quote.data.final, quality, size);
    } catch (e) { /* 保持本地估价 */ }
  }

  function updateImageGenPricingUI() {
    updateImageGenResolutionSelect();
    updateImageGenCostHint();
  }

  window.updateImageGenPricingUI = updateImageGenPricingUI;

  function getGenHistoryItems() {
    pruneCreations();
    const seen = new Set();
    const list = [];
    for (const c of creations) {
      if (!(c.prompt || '').trim()) continue;
      const key = c.jobId ? `job:${c.jobId}` : `id:${String(c.id)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      list.push(c);
    }
    list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    return list;
  }

  function fillFormFromData({ prompt, refImage, refImages, model, resolution, quality, size, sourceId, sourceType }) {
    const promptEl = document.getElementById('imageGenPrompt');
    if (promptEl) promptEl.value = prompt || '';
    const refs = (refImages || []).filter(r => isDisplayableImage(r));
    const singleRef = refImage && isDisplayableImage(refImage) ? refImage : null;
    if (refs.length) setImageGenRefs(refs);
    else if (singleRef) setImageGenRefs([singleRef]);
    else clearImageGenRef();
    const modelEl = document.getElementById('imageGenModel');
    if (modelEl && model) modelEl.value = model;
    const resEl = document.getElementById('imageGenResolution');
    if (resEl && resolution) resEl.value = resolution;
    const qEl = document.getElementById('imageGenQuality');
    if (qEl && quality) qEl.value = quality;
    const szEl = document.getElementById('imageGenSize');
    if (szEl && size) szEl.value = size;
    updateImageGenPricingUI();
    if (sourceType === 'personal' && sourceId) imageGenActiveHistoryId = sourceId;
    syncImageGenGenPublicFromPrompt();
    renderImageGenFeed();
    toast('已填入生图框');
  }

  function fillFormPromptOnly(prompt) {
    const promptEl = document.getElementById('imageGenPrompt');
    if (promptEl) promptEl.value = prompt || '';
    syncImageGenGenPublicFromPrompt();
    toast('已填入提示词');
  }

  function fillFormRefOnly(refImage, refImages) {
    const refs = (refImages || []).filter(r => isDisplayableImage(r));
    const single = refImage && isDisplayableImage(refImage) ? refImage : null;
    if (refs.length) setImageGenRefs(refs);
    else if (single) setImageGenRefs([single]);
    else {
      toast('当前作品没有可填入的参考图');
      return;
    }
    toast('已填入参考图');
  }

  function applyHistoryToForm(item) {
    if (!item) return;
    const payload = {
      prompt: item.prompt,
      model: item.model,
      resolution: item.resolution,
      quality: item.quality,
      size: item.size,
      sourceId: item.id,
      sourceType: 'personal'
    };
    if (item.hasRefImage) {
      if (item.refImages?.length) payload.refImages = item.refImages;
      else if (item.refImage) payload.refImage = item.refImage;
    }
    fillFormFromData(payload);
  }

  function fillFromCommunityPost(post, autoLike) {
    if (!post) return;
    if (autoLike) ensureLike(post.id);
    fillFormFromData({ prompt: post.prompt });
  }

  function likeCommunityPostOnly(postId) {
    const wasNew = ensureLike(postId);
    toast(wasNew ? '已点赞' : '你已经点过赞了');
  }

  function applyImageGenPrefill() {
    const raw = sessionStorage.getItem(PREFILL_KEY);
    if (!raw) return;
    sessionStorage.removeItem(PREFILL_KEY);
    try {
      const data = JSON.parse(raw);
      fillFormFromData({
        prompt: data.prompt,
        refImages: data.refImages,
        refImage: data.refImage,
        resolution: data.resolution
      });
    } catch (e) { /* ignore */ }
  }

  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(new Error('read failed'));
      r.readAsDataURL(file);
    });
  }

  async function addImageGenRefFiles(fileList) {
    const files = Array.from(fileList || []).filter(f => f.type && f.type.startsWith('image/'));
    if (!files.length) return;
    let added = 0;
    for (const f of files) {
      if (imageGenRefImages.length >= MAX_REF_IMAGES) {
        toast(`最多 ${MAX_REF_IMAGES} 张参考图`);
        break;
      }
      if (f.size > 12 * 1024 * 1024) {
        toast(`「${f.name || '图片'}」超过 12MB，已跳过`);
        continue;
      }
      try {
        const url = await readFileAsDataUrl(f);
        imageGenRefImages.push(url);
        added++;
      } catch (e) { /* ignore */ }
    }
    if (added) {
      renderImageGenRefGallery();
      if (added > 1) toast(`已添加 ${added} 张参考图`);
    }
  }

  function removeImageGenRefAt(idx) {
    imageGenRefImages.splice(idx, 1);
    renderImageGenRefGallery();
  }

  function renderImageGenRefGallery() {
    const gallery = document.getElementById('imageGenRefGallery');
    const box = document.getElementById('imageGenRefBox');
    if (!gallery || !box) return;
    if (!imageGenRefImages.length) {
      gallery.hidden = true;
      gallery.innerHTML = '';
      box.classList.remove('has-refs');
      return;
    }
    gallery.hidden = false;
    box.classList.add('has-refs');
    gallery.innerHTML = imageGenRefImages.map((src, i) => `
      <div class="imagegen-ref-thumb">
        <button type="button" class="imagegen-ref-preview-btn" data-ref-idx="${i}" title="点击放大">
          <img src="${esc(src)}" alt="参考图 ${i + 1}">
        </button>
        <button type="button" class="imagegen-ref-rm" data-ref-idx="${i}" aria-label="移除">×</button>
      </div>
    `).join('');
    gallery.querySelectorAll('.imagegen-ref-preview-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const src = imageGenRefImages[Number(btn.dataset.refIdx)];
        if (src && typeof window.openLightbox === 'function') window.openLightbox(src);
      });
    });
    gallery.querySelectorAll('.imagegen-ref-rm').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        removeImageGenRefAt(Number(btn.dataset.refIdx));
      });
    });
    updateImageGenCostHint();
  }

  function setImageGenRefs(urls) {
    if (typeof urls === 'string' && urls) {
      imageGenRefImages = [urls];
    } else {
      imageGenRefImages = Array.isArray(urls) ? urls.filter(Boolean).slice(0, MAX_REF_IMAGES) : [];
    }
    renderImageGenRefGallery();
  }

  function clearImageGenRef() {
    imageGenRefImages = [];
    renderImageGenRefGallery();
  }

  function bindImageGenUpload() {
    const drop = document.getElementById('imageGenRefDrop');
    const box = document.getElementById('imageGenRefBox');
    const input = document.getElementById('imageGenRefInput');
    if (!drop || !input || !box) return;
    if (drop.dataset.bound === '1') return;
    drop.dataset.bound = '1';

    const bindDragZone = (el) => {
      ['dragenter', 'dragover'].forEach(ev => {
        el.addEventListener(ev, e => {
          if (!document.getElementById('pageImageGen')?.classList.contains('active')) return;
          e.preventDefault();
          e.stopPropagation();
          box.classList.add('drag-over');
        });
      });
      el.addEventListener('dragleave', e => {
        if (!box.contains(e.relatedTarget)) box.classList.remove('drag-over');
      });
      el.addEventListener('drop', e => {
        if (!document.getElementById('pageImageGen')?.classList.contains('active')) return;
        e.preventDefault();
        e.stopPropagation();
        box.classList.remove('drag-over');
        if (e.dataTransfer?.files?.length) addImageGenRefFiles(e.dataTransfer.files);
      });
    };

    drop.addEventListener('click', e => {
      if (e.target.closest('.imagegen-ref-rm') || e.target.closest('.imagegen-ref-preview-btn')) return;
      input.click();
    });
    input.addEventListener('change', () => {
      if (input.files?.length) addImageGenRefFiles(input.files);
      input.value = '';
    });
    bindDragZone(drop);
    bindDragZone(box);

    if (!document.body.dataset.imageGenPasteBound) {
      document.body.dataset.imageGenPasteBound = '1';
      document.addEventListener('paste', e => {
        if (!document.getElementById('pageImageGen')?.classList.contains('active')) return;
        const items = e.clipboardData?.items;
        if (!items) return;
        const files = [];
        for (let i = 0; i < items.length; i++) {
          const item = items[i];
          if (item.type.startsWith('image/')) {
            const f = item.getAsFile();
            if (f) files.push(f);
          }
        }
        if (files.length) {
          e.preventDefault();
          addImageGenRefFiles(files);
        }
      });
    }
  }

  async function resolveRefUrlsForApi() {
    if (!imageGenRefImages.length) return [];
    const urls = [];
    for (let i = 0; i < imageGenRefImages.length; i++) {
      const src = imageGenRefImages[i];
      try {
        let apiUrl = null;
        if (/^https?:\/\//i.test(src)) {
          apiUrl = src;
        } else if (window.SupabaseSync?.isStorageRef?.(src)) {
          apiUrl = await window.SupabaseSync.resolveDisplayUrl(src);
        } else if (window.SupabaseSync?.isDataUrl?.(src)) {
          if (window.SupabaseSync?.isLoggedIn?.() && window.SupabaseSync?.uploadImageGenRef) {
            const stored = await window.SupabaseSync.uploadImageGenRef(genId('ref'), src);
            apiUrl = await window.SupabaseSync.resolveDisplayUrl(stored);
          } else {
            apiUrl = src;
          }
        } else if (String(src).startsWith('blob:')) {
          if (window.SupabaseSync?.isLoggedIn?.() && window.SupabaseSync?.uploadImageGenRef) {
            const stored = await window.SupabaseSync.uploadImageGenRef(genId('ref'), src);
            apiUrl = await window.SupabaseSync.resolveDisplayUrl(stored);
          }
        }
        if (apiUrl && /^https?:\/\//i.test(apiUrl)) urls.push(apiUrl);
        else if (apiUrl && window.SupabaseSync?.isDataUrl?.(apiUrl)) urls.push(apiUrl);
      } catch (e) {
        console.warn('参考图解析失败', e);
      }
    }
    return urls;
  }

  function removePendingJob(pendingId) {
    imageGenPendingJobs = imageGenPendingJobs.filter(j => j.id !== pendingId);
  }

  async function pollGenerationJobUntilDone(jobId, pendingId, ctx) {
    const maxAttempts = 80;
    const finishFromPoll = async (poll) => {
      removePendingJob(pendingId);
      if (poll.data.status === 'failed') {
        await window.PointsSystem?.refreshCreditsFromServer?.();
        renderImageGenFeed();
        toast(poll.data.message || poll.data.errorMessage || '生图失败，积分已全额退回');
        return true;
      }
      if (poll.data.status === 'completed') {
        const imageUrl = poll.data.imageUrl;
        if (!imageUrl) {
          await window.PointsSystem?.refreshCreditsFromServer?.();
          renderImageGenFeed();
          toast('生图未返回图片，若积分未退回请点同步或联系客服');
          return true;
        }
        if (ctx.jobId && creations.some(c => c.jobId === ctx.jobId)) {
          renderImageGenFeed();
          return true;
        }
        void finishImageGenRun({
          ...ctx,
          image: imageUrl,
          cost: ctx.cost,
          jobId: ctx.jobId || jobId,
          silentToast: !!ctx.silentToast,
          isRecovery: !!ctx.isRecovery
        });
        return true;
      }
      return false;
    };

    for (let i = 0; i < maxAttempts; i++) {
      await new Promise(r => setTimeout(r, i === 0 ? 1500 : 3000));
      const poll = await window.PromptHubApi.getGenerationJob(jobId);
      if (!poll.ok) {
        if ((poll.code === 'NETWORK_ERROR' || poll.code === 'RATE_LIMITED') && i < maxAttempts - 1) {
          await new Promise(r => setTimeout(r, poll.code === 'RATE_LIMITED' ? 5000 : 2000));
          continue;
        }
        removePendingJob(pendingId);
        await window.PointsSystem?.refreshCreditsFromServer?.();
        renderImageGenFeed();
        if (poll.code === 'RATE_LIMITED') {
          toast('查询进度稍慢（服务器繁忙），正在后台恢复结果…');
        } else {
          toast(poll.message || '查询生图进度失败，正在尝试恢复…');
        }
        void recoverRecentGenerationJobs({ sessionOnly: true });
        return;
      }

      if (typeof poll.data.creditsRemaining === 'number') {
        window.PointsSystem?.setCreditsFromServer?.(poll.data.creditsRemaining);
        window.PointsSystem?.updateCreditsUI?.();
      }

      if (poll.data.status === 'processing') {
        if (imageGenFeedTab === 'warehouse') renderImageGenFeed();
        continue;
      }

      if (await finishFromPoll(poll)) return;
    }

    const last = await window.PromptHubApi.getGenerationJob(jobId);
    if (last.ok && await finishFromPoll(last)) return;

    removePendingJob(pendingId);
    toast('生图时间较长，正在恢复本次任务…');
    void recoverRecentGenerationJobs({ sessionOnly: true });
    renderImageGenFeed();
  }

  /**
   * 从 API 恢复生图结果。
   * - sessionOnly：仅恢复「本会话提交」的任务（轮询失败时用）
   * - manual：用户点「恢复丢失的生图」并确认后
   * 永不自动恢复：用户已删除（job 墓碑）或已有仓库卡片
   */
  async function recoverRecentGenerationJobs(opts = {}) {
    if (!window.PromptHubApi?.listRecentGenerationJobs) return;
    const sessionOnly = opts.sessionOnly === true;
    const manual = opts.manual === true;
    if (!sessionOnly && !manual) return;

    const r = await window.PromptHubApi.listRecentGenerationJobs();
    if (!r?.ok || !Array.isArray(r.data?.jobs)) return;

    let changed = false;
    let recovered = 0;
    for (const job of r.data.jobs) {
      if (!job?.id) continue;
      if (isGenerationJobDeleted(job.id)) continue;

      const meta = {
        prompt: job.prompt || '',
        model: job.model || 'quanneng2',
        resolution: job.resolution || '1k',
        quality: job.quality || 'standard',
        size: job.size || '1:1',
        cost: job.creditsCharged || 0,
        jobId: job.id
      };
      const inSession = isSessionGenJob(job.id);

      if (job.status === 'processing') {
        if (sessionOnly && !inSession) continue;
        if (manual) continue;
        const hasCreation = creations.some((c) => c.jobId === job.id);
        const alreadyPending = imageGenPendingJobs.some((j) => j.jobId === job.id);
        if (!alreadyPending && !hasCreation) {
          const pendingId = genId('pending');
          imageGenPendingJobs.unshift({
            id: pendingId,
            jobId: job.id,
            prompt: meta.prompt,
            model: meta.model,
            modelLabel: job.modelLabel || '全能模型2',
            resolution: meta.resolution,
            quality: meta.quality,
            size: meta.size,
            cost: meta.cost,
            startedAt: Date.parse(job.createdAt) || Date.now()
          });
          changed = true;
          void pollGenerationJobUntilDone(job.id, pendingId, meta);
        }
        continue;
      }

      if (job.status !== 'completed' || !job.imageUrl) continue;

      const existingCard = (window.__promptHubCards || []).find((c) => c.genJobId === job.id);
      if (existingCard && hasWarehouseCardForJob(job.id)) continue;
      if (!existingCard && creations.some((c) => c.jobId === job.id)) continue;

      if (manual) {
        /* 用户确认后的孤儿恢复 */
      } else if (sessionOnly && inSession) {
        /* 本会话提交、轮询失败 */
      } else {
        continue;
      }

      changed = true;
      if (existingCard && !existingCard.image) {
        const ok = await repairWarehouseCardImageFromJob(existingCard, job.imageUrl, job.id);
        if (ok) {
          recovered += 1;
          continue;
        }
      }

      recovered += 1;
      await finishImageGenRun({
        ...meta,
        image: job.imageUrl,
        cost: meta.cost,
        silentToast: true,
        isRecovery: true
      });
    }

    if (changed) renderImageGenFeed();
    if (manual && recovered > 0) {
      toast(`已恢复 ${recovered} 张生图到卡片仓库（不重复扣积分）`);
    } else if (manual && recovered === 0 && changed) {
      toast('已更新进行中的生图任务');
    }
  }

  async function runImageGenDemo() {
    if (!window.AuthGate?.requireAuth?.('imagegen')) return;
    const prompt = document.getElementById('imageGenPrompt')?.value?.trim();
    if (!prompt) {
      toast('请先填写提示词');
      return;
    }
    const meta = getImageGenFormMeta();
    const { model, resolution, quality, size } = meta;
    let cost = window.PointsSystem?.getImageGenCost?.(model, resolution) ?? 10;
    let balance = window.PointsSystem?.getCredits?.() ?? 0;

    const btn = document.getElementById('imageGenSubmit');
    const useApi = window.PointsSystem?.useApiForAccount?.();

    if (useApi) {
      const quote = await window.PromptHubApi.getGenerationCost(resolution, quality, model);
      if (quote.ok && quote.data?.final != null) cost = quote.data.final;
      balance = window.PointsSystem?.getCredits?.() ?? 0;
    }

    if (balance < cost) {
      toast(`积分不足（需要 ${cost}，当前 ${balance}）。请使用激活码兑换`);
      return;
    }

    if (!useApi && !window.PointsSystem?.deductCredits?.(cost)) {
      toast('积分扣除失败');
      return;
    }

    saveJson(LS_IMAGEGEN, {
      prompt,
      model,
      refImages: imageGenRefImages,
      refImage: getImageGenPrimaryRef(),
      resolution,
      quality,
      size
    });

    const modelLabel = window.PointsSystem?.getImageGenModel?.(model)?.label || model;
    const pendingId = genId('pending');
    const pendingJob = {
      id: pendingId,
      prompt,
      model,
      modelLabel,
      resolution,
      quality,
      size,
      cost,
      startedAt: Date.now()
    };
    imageGenPendingJobs.unshift(pendingJob);
    imageGenFeedTab = 'warehouse';
    document.querySelectorAll('[data-feed-tab]').forEach(b => {
      b.classList.toggle('active', b.dataset.feedTab === 'warehouse');
    });
    updateImageGenFeedHint();
    renderImageGenFeed();
    if (window.MobileUI?.isMobile?.() && window.MobileUI?.setImageGenView) {
      window.MobileUI.setImageGenView('feed');
    }

    if (btn) {
      btn.disabled = true;
      btn.textContent = '提交中…';
    }

    function friendlyGenErrorMessage(msg) {
      const s = String(msg || '');
      if (/insufficient balance/i.test(s) || (/insufficient/i.test(s) && /balance/i.test(s))) {
        return '生图服务商账户余额不足，请联系站长充值；您的积分已全额退回';
      }
      if (/invalid.*api.*key|unauthorized|401/i.test(s)) {
        return '生图接口密钥无效或已过期，请联系站长检查配置；您的积分已全额退回';
      }
      if (s.length > 120) return s.slice(0, 120) + '…';
      return s || '生图失败，您的积分已全额退回';
    }

    if (useApi) {
      const refUrls = await resolveRefUrlsForApi();
      if (imageGenRefImages.length && !refUrls.length) {
        removePendingJob(pendingId);
        renderImageGenFeed();
        if (btn) {
          btn.disabled = false;
          restoreImageGenSubmitLabel();
        }
        toast('参考图无法用于生图（须为网络图片），请去掉参考图或重新上传后再试');
        return;
      }
      if (imageGenRefImages.length && refUrls.length < imageGenRefImages.length) {
        toast(`已使用 ${refUrls.length}/${imageGenRefImages.length} 张参考图继续生成`);
      }
      const gen = await window.PromptHubApi.generateImage({
        prompt,
        model,
        resolution,
        quality,
        size,
        refImageUrls: refUrls.length ? refUrls : undefined
      });
      if (btn) {
        btn.disabled = false;
        restoreImageGenSubmitLabel();
      }
      if (!gen.ok) {
        removePendingJob(pendingId);
        renderImageGenFeed();
        await window.PointsSystem?.refreshCreditsFromServer?.();
        toast(friendlyGenErrorMessage(gen.message));
        return;
      }
      if (typeof gen.data.creditsRemaining === 'number') {
        window.PointsSystem?.setCreditsFromServer?.(gen.data.creditsRemaining);
        window.PointsSystem?.updateCreditsUI?.();
      }
      cost = gen.data.creditsCharged ?? cost;
      pendingJob.cost = cost;

      if (gen.data.status === 'completed' && gen.data.imageUrl) {
        removePendingJob(pendingId);
        if (gen.data.jobId) trackSessionGenJob(gen.data.jobId);
        void finishImageGenRun({
          prompt,
          model,
          resolution,
          quality,
          size,
          image: gen.data.imageUrl,
          cost,
          jobId: gen.data.jobId
        });
        return;
      }

      const jobId = gen.data.jobId;
      if (!jobId) {
        removePendingJob(pendingId);
        renderImageGenFeed();
        toast('未收到任务编号，请重试');
        return;
      }
      pendingJob.jobId = jobId;
      trackSessionGenJob(jobId);
      toast('已提交生图，右侧可查看进度，可继续点击生成');
      void pollGenerationJobUntilDone(jobId, pendingId, {
        prompt,
        model,
        resolution,
        quality,
        size,
        cost,
        jobId
      });
      return;
    }

    removePendingJob(pendingId);
    renderImageGenFeed();
    if (btn) {
      btn.disabled = false;
      restoreImageGenSubmitLabel();
    }
    toast('请登录并连接后端 API 后使用真实生图（演示占位已关闭）');
  }

  async function finishImageGenRun({ prompt, model, resolution, quality, size, image, cost, btn, jobId, silentToast, isRecovery }) {
    if (!image) {
      toast('图片地址无效，请重试');
      return;
    }
    const jid = jobId || null;
    if (jid) {
      if (isGenerationJobDeleted(jid)) return;
      if (creations.some(c => c.jobId === jid)) {
        clearSessionGenJob(jid);
        imageGenFeedTab = 'warehouse';
        renderImageGenFeed();
        return;
      }
      if (finishingJobIds.has(jid)) return;
      finishingJobIds.add(jid);
    }
    try {
    const creationId = genId('cr');
    let storedImage = image;
    if (window.SupabaseSync?.persistGenerationImage) {
      try {
        storedImage = await window.SupabaseSync.persistGenerationImage(creationId, image);
      } catch (e) {
        console.warn('生成图客户端归档跳过，使用服务端/临时链接', e);
        if (window.SupabaseSync?.isStorageRef?.(image)) storedImage = image;
        else if (/^https?:\/\//i.test(image)) storedImage = image;
      }
    }
    imageGenLastResult = storedImage;
    const primaryRef = getImageGenPrimaryRef();
    const modelId = model || 'quanneng2';
    const modelLabel = window.PointsSystem?.getImageGenModel?.(modelId)?.label || modelId;
    const creation = {
      id: creationId,
      jobId: jobId || null,
      prompt,
      image: storedImage,
      refImage: primaryRef,
      refImages: imageGenRefImages.length ? [...imageGenRefImages] : null,
      model: modelId,
      modelLabel,
      resolution,
      quality: quality || 'standard',
      size: size || '1:1',
      hasRefImage: imageGenRefImages.length > 0,
      visibility: 'private',
      createdAt: Date.now(),
      expiresAt: Date.now() + randomGenRetentionMs()
    };
    creations = dedupeCreationsByJobId([creation, ...creations]);
    imageGenActiveHistoryId = creation.id;
    persistCreations();
    imageGenFeedTab = 'warehouse';
    document.querySelectorAll('[data-feed-tab]').forEach(b => {
      b.classList.toggle('active', b.dataset.feedTab === 'warehouse');
    });
    updateImageGenFeedHint();
    window.PointsSystem?.updateCreditsUI?.();
    if (btn) { btn.disabled = false; restoreImageGenSubmitLabel(); }
    const publish = isImageGenGenPublicChecked();
    const saved = await saveGeneratedToWarehouse({
      prompt: creation.prompt,
      image: storedImage || image,
      sourceId: creation.id,
      jobId: jid,
      title: '',
      publishToCommunity: publish,
      silentToast: !!silentToast
    });
    renderImageGenFeed();
    if (isRecovery) {
      /* 恢复流程在 recoverRecentGenerationJobs 末尾统一提示 */
    } else if (!silentToast) {
      if (saved) {
        toast(publish
          ? `已生成并保存到仓库（已公开到社区，-${cost} 积分）`
          : `已生成并保存到仓库（-${cost} 积分）`);
      } else {
        toast(`已生成（-${cost} 积分）`);
      }
    }
    if (window.MobileUI?.isMobile?.() && window.MobileUI?.setImageGenView) {
      window.MobileUI.setImageGenView('feed');
    }
    if (jid) clearSessionGenJob(jid);
    } finally {
      if (jid) finishingJobIds.delete(jid);
    }
  }

  function updateImageGenFeedHint() {
    const el = document.getElementById('imageGenFeedHint');
    const recoverRow = document.getElementById('imageGenRecoverRow');
    if (!el) return;
    const mobile = window.MobileUI?.isMobile?.();
    const warehouse = imageGenFeedTab === 'warehouse';
    if (recoverRow) recoverRow.classList.toggle('hidden', !warehouse);
    if (warehouse) {
      el.textContent = mobile
        ? '两列浏览 · 生成完成后自动入库 · 真丢图可点「恢复丢失的生图」'
        : '卡片仓库 · 生成中任务显示在顶部 · 丢失的生图请点「恢复丢失的生图」（已删除的不会恢复）';
    } else if (imageGenFeedTab === 'community') {
      el.textContent = mobile
        ? '社区作品 · 点图放大 · 按钮复制或填入生图'
        : '社区作品 · 点击图片放大 · 点击卡片查看详情';
    }
  }

  function copyFeedPromptText(prompt) {
    const text = (prompt || '').trim();
    if (!text) {
      toast('暂无提示词');
      return;
    }
    navigator.clipboard.writeText(text).then(() => toast('已复制提示词'));
  }

  function fillFeedPromptToImageGen(prompt) {
    fillFormPromptOnly(prompt || '');
    if (window.MobileUI?.isMobile?.()) window.MobileUI?.setImageGenView?.('form');
  }


  function buildFeedPendingCardHtml(job) {
    const badges = [job.modelLabel || '生图中', (job.resolution || '1k').toUpperCase()];
    const badgeHtml = badges.map(b => `<span class="imagegen-feed-badge">${esc(b)}</span>`).join('');
    return `<article class="imagegen-feed-card imagegen-feed-card-tile imagegen-feed-card--pending" data-feed-id="${esc(job.id)}" data-pending="1">
      <div class="imagegen-feed-media imagegen-gen-pending" aria-busy="true">
        <span class="imagegen-gen-pending-label">生成中</span>
      </div>
      <div class="imagegen-feed-content">
        <p class="imagegen-feed-prompt">${esc((job.prompt || '').slice(0, 120))}</p>
        <div class="imagegen-feed-tags">${badgeHtml}</div>
        <div class="imagegen-feed-foot">
          <span class="imagegen-feed-meta">预计 1–3 分钟 · 可继续提交</span>
        </div>
      </div>
    </article>`;
  }

  function resetMobileFeedGridStyles() {
    enforceMobileImageGenFeed();
  }

  function enforceMobileImageGenFeed() {
    if (!isMobileFeedViewport()) return;
    if (imageGenMasonry) {
      imageGenMasonry.destroy();
      imageGenMasonry = null;
    }
    const wrap = document.getElementById('imageGenFeed');
    if (!wrap) return;
    wrap.classList.remove('imagegen-feed--masonry');
    wrap.classList.add('imagegen-feed--tiles', 'mobile-feed-grid');
    wrap.removeAttribute('style');
    wrap.querySelectorAll('.grid-sizer').forEach((el) => el.remove());
    wrap.querySelectorAll('.imagegen-feed-card').forEach((el) => el.removeAttribute('style'));
  }

  function buildFeedCardHtml(opts) {
    const {
      id, prompt, image, jobId, title, badges = [], metaLine = '', meta = '', active = false,
      showLike = false, liked = false, likeCount = 0, showSave = false, showDel = false
    } = opts;
    const { showTitle, showPrompt } = resolveFeedCardDisplay(title, prompt);
    const storageAttr = feedImgStorageAttr(image);
    const jobAttr = jobId ? ` data-job-id="${esc(jobId)}"` : '';
    const imgSrc = isDisplayableImage(image) ? IMG_LOADING_PLACEHOLDER : '';
    const loadingCls = isDisplayableImage(image) ? ' is-loading' : '';
    const shineAt = loadingCls ? ` data-shine-at="${Date.now()}"` : '';
    const imgBlock = isDisplayableImage(image)
      ? `<div class="imagegen-feed-media${loadingCls}"${shineAt}><button type="button" class="imagegen-feed-thumb-btn" title="放大预览"><img src="${esc(imgSrc || IMG_LOADING_PLACEHOLDER)}" data-image-ref="${esc(image)}"${storageAttr}${jobAttr} alt="" decoding="async" loading="lazy" onload="if(typeof finishCardMediaShine==='function')finishCardMediaShine(this.closest('.imagegen-feed-media'));else this.closest('.imagegen-feed-media')?.classList.remove('is-loading')"></button></div>`
      : '';
    const badgeHtml = badges.map(b => `<span class="imagegen-feed-badge">${esc(b)}</span>`).join('');
    const metaRowHtml = (metaLine || '').trim()
      ? `<p class="imagegen-feed-meta-row">${esc(metaLine.trim())}</p>`
      : (badgeHtml ? `<div class="imagegen-feed-tags">${badgeHtml}</div>` : '');
    const metaTrim = (meta || '').trim();
    const metaRedundant = !metaTrim || badges.some(b => b === metaTrim) || metaTrim === showTitle;
    const metaHtml = metaTrim && !metaRedundant
      ? `<span class="imagegen-feed-meta">${esc(metaTrim)}</span>`
      : '';
    const likeBtn = showLike
      ? `<button type="button" class="imagegen-feed-like ${liked ? 'liked' : ''}" data-like-id="${esc(id)}" title="点赞">♥ ${likeCount}</button>`
      : '';
    const saveBtn = showSave
      ? '<button type="button" class="btn btn-ghost btn-sm imagegen-feed-save-btn" data-save-feed="1">存仓库</button>'
      : '';
    const delBtn = showDel
      ? '<button type="button" class="imagegen-feed-del" data-delete-feed="1" title="删除" aria-label="删除">×</button>'
      : '';
    const titleHtml = showTitle
      ? `<p class="imagegen-feed-title">${esc(showTitle)}</p>`
      : '';
    const promptHtml = showPrompt
      ? `<p class="imagegen-feed-prompt">${esc(showPrompt)}</p>`
      : '<p class="imagegen-feed-prompt imagegen-feed-prompt--empty">暂无提示词</p>';
    const noMedia = !imgBlock ? ' imagegen-feed-card--no-media' : '';
    const mobileActs = window.MobileUI?.isMobile?.()
      ? `<div class="imagegen-feed-mobile-actions mobile-only">
          <button type="button" class="imagegen-feed-mobile-btn" data-feed-copy>复制</button>
          <button type="button" class="imagegen-feed-mobile-btn" data-feed-fill-prompt>填入生图</button>
        </div>`
      : '';
    const fillHint = window.MobileUI?.isMobile?.()
      ? ''
      : '<span class="imagegen-feed-fill-hint">点击查看详情 · 在侧栏填入或复制</span>';
    return `<article class="imagegen-feed-card imagegen-feed-card-tile${noMedia}${active ? ' active' : ''}" data-feed-id="${esc(id)}" data-feed-prompt="${esc(prompt || '')}" tabindex="0">
      ${imgBlock}
      <div class="imagegen-feed-content">
        ${titleHtml}
        ${promptHtml}
        ${metaRowHtml}
        <div class="imagegen-feed-foot">
          ${metaHtml}
          <div class="imagegen-feed-actions">${likeBtn}${saveBtn}${delBtn}</div>
        </div>
        ${mobileActs}
        ${fillHint}
      </div>
    </article>`;
  }

  function closeImageGenPreview() {
    imageGenPreviewId = null;
    imageGenPreviewKind = null;
    document.getElementById('imageGenPreviewPanel')?.classList.add('hidden');
    document.querySelector('.imagegen-side')?.classList.remove('imagegen-preview-open');
    document.querySelectorAll('.imagegen-feed-card.active-preview').forEach(el => el.classList.remove('active-preview'));
    if (isMobileFeedViewport()) enforceMobileImageGenFeed();
    else requestAnimationFrame(() => scheduleImageGenFeedLayout());
  }

  function buildPreviewFillActions(hasRef, extraActionsHtml) {
    const refDisabled = hasRef ? '' : ' disabled title="暂无参考图"';
    return `
      <div class="imagegen-preview-copy-row">
        <button type="button" class="btn btn-secondary btn-sm" data-preview-copy-prompt>复制提示词</button>
      </div>
      <div class="imagegen-preview-fill">
        <span class="imagegen-preview-fill-label">填入生图框</span>
        <div class="imagegen-preview-fill-btns">
          <button type="button" class="btn btn-primary btn-sm" data-preview-fill-all>全部</button>
          <button type="button" class="btn btn-secondary btn-sm" data-preview-fill-prompt>仅提示词</button>
          <button type="button" class="btn btn-secondary btn-sm" data-preview-fill-ref${refDisabled}>仅参考图</button>
        </div>
      </div>
      ${extraActionsHtml ? `<div class="imagegen-preview-actions-secondary">${extraActionsHtml}</div>` : ''}`;
  }

  async function renderImageGenPreview() {
    const body = document.getElementById('imageGenPreviewBody');
    if (!body || !imageGenPreviewId || !imageGenPreviewKind) return;
    let prompt = '';
    let image = '';
    let jobId = '';
    let refImages = null;
    let refImage = null;
    let extraActions = '';
    if (imageGenPreviewKind === 'personal') {
      closeImageGenPreview();
      return;
    } else if (imageGenPreviewKind === 'community') {
      const post = findPost(imageGenPreviewId);
      if (!post) { closeImageGenPreview(); return; }
      prompt = post.prompt || '';
      image = post.image || '';
      const liked = likedIds.has(post.id);
      extraActions = `
        <button type="button" class="btn btn-secondary btn-sm" data-preview-like>♥ ${liked ? '已赞' : '点赞'}</button>`;
    } else {
      const rawId = imageGenPreviewId.replace(/^wh_/, '');
      const c = (window.getWarehouseCardsForImageGen?.() || []).find(x => x.id === rawId);
      if (!c) { closeImageGenPreview(); return; }
      prompt = c.prompt || '';
      image = c.image || '';
      if (isDisplayableImage(c.image)) refImage = c.image;
    }
    const hasRef = !!(refImages?.length || (refImage && isDisplayableImage(refImage)));
    const fillHtml = buildPreviewFillActions(hasRef, extraActions);
    const imgHtml = isDisplayableImage(image)
      ? `<button type="button" class="imagegen-preview-img-btn" data-preview-zoom title="点击放大"><span class="media-skeleton"></span></button>`
      : '';
    body.innerHTML = `${imgHtml}<div class="imagegen-preview-prompt">${esc(prompt)}</div>${fillHtml}`;
    body.dataset.previewPrompt = prompt;
    body.dataset.previewRef = refImage || '';
    if (refImages?.length) body.dataset.previewRefs = JSON.stringify(refImages);
    else delete body.dataset.previewRefs;
    const zoomBtn = body.querySelector('[data-preview-zoom]');
    if (zoomBtn && isDisplayableImage(image)) {
      void resolveImageDisplayUrl(image, jobId, imageGenPreviewId).then(url => {
        if (!url) { zoomBtn.remove(); return; }
        const img = document.createElement('img');
        img.src = url;
        img.alt = '';
        zoomBtn.replaceChildren(img);
        zoomBtn.addEventListener('click', () => {
          if (typeof window.openLightbox === 'function') window.openLightbox(url);
        });
      });
    }
    const getPreviewRefs = () => {
      let refs = [];
      try {
        if (body.dataset.previewRefs) refs = JSON.parse(body.dataset.previewRefs) || [];
      } catch (e) { /* ignore */ }
      return { refImages: refs, refImage: body.dataset.previewRef || '' };
    };
    body.querySelector('[data-preview-fill-all]')?.addEventListener('click', () => {
      const { refImages: ri, refImage: r1 } = getPreviewRefs();
      fillFormFromData({
        prompt: body.dataset.previewPrompt || '',
        refImages: ri.length ? ri : undefined,
        refImage: ri.length ? undefined : r1
      });
    });
    body.querySelector('[data-preview-fill-prompt]')?.addEventListener('click', () => {
      fillFormPromptOnly(body.dataset.previewPrompt || '');
    });
    body.querySelector('[data-preview-fill-ref]')?.addEventListener('click', () => {
      const { refImages: ri, refImage: r1 } = getPreviewRefs();
      fillFormRefOnly(r1, ri);
    });
    body.querySelector('[data-preview-like]')?.addEventListener('click', () => {
      likeCommunityPostOnly(imageGenPreviewId);
      renderImageGenPreview();
    });
    body.querySelector('[data-preview-copy-prompt]')?.addEventListener('click', () => {
      const text = body.dataset.previewPrompt || '';
      if (!text) { toast('暂无提示词'); return; }
      navigator.clipboard.writeText(text).then(() => toast('已复制提示词'));
    });
  }

  function openImageGenPreview(kind, id) {
    imageGenPreviewKind = kind;
    imageGenPreviewId = id;
    document.getElementById('imageGenPreviewPanel')?.classList.remove('hidden');
    document.querySelector('.imagegen-side')?.classList.add('imagegen-preview-open');
    document.querySelectorAll('.imagegen-feed-card').forEach(el => {
      const fid = el.dataset.feedId;
      el.classList.toggle('active-preview', kind === 'warehouse' ? fid === 'wh_' + id : fid === id);
    });
    void renderImageGenPreview();
    if (!isMobileFeedViewport()) {
      requestAnimationFrame(() => scheduleImageGenFeedLayout());
      setTimeout(() => scheduleImageGenFeedLayout(), 120);
      setTimeout(() => scheduleImageGenFeedLayout(), 400);
    }
  }

  function closeImageGenFilterSheet() {
    const overlay = document.getElementById('imageGenFilterSheetOverlay');
    if (!overlay) return;
    overlay.classList.remove('open');
    overlay.hidden = true;
  }

  function openImageGenFilterSheet(kind) {
    if (!isMobileFeedViewport()) return;
    const opts = window.getImageGenWarehouseFilterOptions?.() || { groups: [], tags: [] };
    const list = kind === 'group' ? opts.groups : opts.tags;
    const current = kind === 'group' ? imageGenWhGroup : imageGenWhTag;
    const titleEl = document.getElementById('imageGenFilterSheetTitle');
    const listEl = document.getElementById('imageGenFilterSheetList');
    const overlay = document.getElementById('imageGenFilterSheetOverlay');
    if (!titleEl || !listEl || !overlay) return;
    titleEl.textContent = kind === 'group' ? '选择分组' : '选择标签';
    listEl.innerHTML = list.map((o) =>
      `<button type="button" class="filter-sheet-row${o.value === current ? ' selected' : ''}" data-value="${esc(o.value)}">
        <span class="filter-sheet-name">${esc(o.label)}</span>
        <span class="filter-sheet-check" aria-hidden="true"></span>
      </button>`
    ).join('');
    listEl.querySelectorAll('.filter-sheet-row').forEach((btn) => {
      btn.addEventListener('click', () => {
        const v = btn.getAttribute('data-value') || 'all';
        if (kind === 'group') imageGenWhGroup = v;
        else imageGenWhTag = v;
        closeImageGenFilterSheet();
        syncImageGenWarehouseFiltersUI();
        renderImageGenFeed();
      });
    });
    overlay.hidden = false;
    overlay.style.removeProperty('display');
    overlay.style.pointerEvents = '';
    overlay.classList.add('open');
  }

  function bindImageGenWarehouseFilterMobileUI() {
    document.getElementById('imageGenWhGroupBtn')?.addEventListener('click', () => openImageGenFilterSheet('group'));
    document.getElementById('imageGenWhTagBtn')?.addEventListener('click', () => openImageGenFilterSheet('tag'));
  }

  function syncImageGenCommunityFiltersUI() {
    const bar = document.getElementById('imageGenCommunityFilters');
    if (!bar) return;
    const show = imageGenFeedTab === 'community';
    bar.classList.toggle('hidden', !show);
    if (!show) return;
    document.querySelectorAll('[data-imagegen-community-sort]').forEach(btn => {
      btn.classList.toggle('active', (btn.dataset.imagegenCommunitySort || 'hot') === communitySort);
    });
    document.querySelectorAll('[data-imagegen-community-scope]').forEach(btn => {
      btn.classList.toggle('active', (btn.dataset.imagegenCommunityScope || 'all') === communityScope);
    });
    document.querySelectorAll('[data-imagegen-community-media]').forEach(btn => {
      btn.classList.toggle('active', (btn.dataset.imagegenCommunityMedia || 'all') === communityMediaFilter);
    });
  }

  function syncImageGenWarehouseFiltersUI() {
    const bar = document.getElementById('imageGenWarehouseFilters');
    const commBar = document.getElementById('imageGenCommunityFilters');
    if (commBar) commBar.classList.toggle('hidden', imageGenFeedTab !== 'community');
    const groupEl = document.getElementById('imageGenWhGroup');
    const tagEl = document.getElementById('imageGenWhTag');
    if (!bar || !groupEl || !tagEl) return;
    const show = imageGenFeedTab === 'warehouse';
    bar.classList.toggle('hidden', !show);
    if (!show) return;
    const opts = window.getImageGenWarehouseFilterOptions?.() || { groups: [], tags: [] };
    const mkOpts = (list, current) => list.map(o =>
      `<option value="${esc(o.value)}"${o.value === current ? ' selected' : ''}>${esc(o.label)}</option>`
    ).join('');
    groupEl.innerHTML = mkOpts(opts.groups, imageGenWhGroup);
    tagEl.innerHTML = mkOpts(opts.tags, imageGenWhTag);
    if (!opts.groups.some(o => o.value === imageGenWhGroup)) imageGenWhGroup = 'all';
    if (!opts.tags.some(o => o.value === imageGenWhTag)) imageGenWhTag = 'all';
    groupEl.value = imageGenWhGroup;
    tagEl.value = imageGenWhTag;
    const gLabel = opts.groups.find((o) => o.value === imageGenWhGroup)?.label || '全部分组';
    const tLabel = opts.tags.find((o) => o.value === imageGenWhTag)?.label || '全部标签';
    const gLabelEl = document.getElementById('imageGenWhGroupLabel');
    const tLabelEl = document.getElementById('imageGenWhTagLabel');
    if (gLabelEl) gLabelEl.textContent = gLabel;
    if (tLabelEl) tLabelEl.textContent = tLabel;
  }

  async function renderImageGenFeed() {
    const wrap = document.getElementById('imageGenFeed');
    if (!wrap) return;
    syncImageGenWarehouseFiltersUI();
    syncImageGenCommunityFiltersUI();
    let html = '';
    if (imageGenFeedTab === 'warehouse') {
      const pending = imageGenPendingJobs.slice(0, 8);
      const list = typeof window.getWarehouseCardsForImageGen === 'function'
        ? window.getWarehouseCardsForImageGen({ group: imageGenWhGroup, tag: imageGenWhTag }) : [];
      if (!pending.length && !list.length) {
        html = '<p class="imagegen-feed-empty">仓库暂无卡片<br><button type="button" class="btn btn-primary btn-sm" onclick="createNewCard({forceOpenPanel:true})">新建卡片</button></p>';
      } else {
        html = pending.map(j => buildFeedPendingCardHtml(j)).join('') + list.map(c => {
          const groupLabel = c.group || '未分类';
          const titleTrim = (c.title || '').trim();
          const tagPart = (c.tags || []).slice(0, 2).join(' · ');
          const whMeta = tagPart ? `${groupLabel} · ${tagPart}` : groupLabel;
          return buildFeedCardHtml({
            id: 'wh_' + c.id,
            prompt: c.prompt,
            image: c.image,
            title: titleTrim,
            metaLine: whMeta,
            meta: ''
          });
        }).join('');
      }
    } else if (imageGenFeedTab === 'community') {
      const list = filterAndSortPosts(getAllCommunityPosts()).slice(0, 40);
      if (!list.length) {
        const emptyMsg = communityScope === 'following'
          ? '暂无关注作者的作品'
          : '社区暂无内容';
        html = `<p class="imagegen-feed-empty">${esc(emptyMsg)}</p>`;
      } else {
        html = list.map(p => {
          const postTitle = (p.title || '').trim();
          const useTitle = postTitle && !isGenericPostTitle(postTitle) ? postTitle : '';
          const author = (p.authorName || '').trim() || '用户';
          const model = (p.modelLabel || '全能模型2').trim();
          return buildFeedCardHtml({
            id: p.id,
            prompt: p.prompt,
            image: p.image,
            title: useTitle,
            metaLine: `${author} · ${model}`,
            meta: `♥ ${p.likes || 0} · ${formatTime(p.createdAt)}`,
            showLike: true,
            liked: likedIds.has(p.id),
            likeCount: p.likes || 0
          });
        }).join('');
      }
    }
    const refsToPrefetch = [];
    if (imageGenFeedTab === 'warehouse') {
      (typeof window.getWarehouseCardsForImageGen === 'function'
        ? window.getWarehouseCardsForImageGen({ group: imageGenWhGroup, tag: imageGenWhTag }) : []
      ).forEach(c => { if (c.image) refsToPrefetch.push(c.image); });
    } else if (imageGenFeedTab === 'community') {
      filterAndSortPosts(getAllCommunityPosts()).slice(0, 40).forEach(p => { if (p.image) refsToPrefetch.push(p.image); });
    }
    const mobileFeed = isMobileFeedViewport();
    const prefetchLimit = mobileFeed ? 24 : 40;
    const refsSlice = refsToPrefetch.slice(0, prefetchLimit);

    resetImageGenFeedCardLayout();
    setFeedLayoutPending(wrap, true);
    wrap.className = mobileFeed
      ? 'imagegen-feed imagegen-feed--tiles mobile-feed-grid'
      : 'imagegen-feed imagegen-feed--masonry';

    wrap.innerHTML = html;
    if (!html.includes('grid-sizer') && !mobileFeed) {
      const sizer = document.createElement('div');
      sizer.className = 'grid-sizer';
      wrap.insertBefore(sizer, wrap.firstChild);
    }
    resetMobileFeedGridStyles();
    bindImageGenFeedCardEvents(wrap);
    bindImageGenFeedImageRelayout();
    if (mobileFeed) {
      enforceMobileImageGenFeed();
      setFeedLayoutPending(wrap, false);
    } else {
      layoutImageGenFeedMasonry();
    }

    void (async () => {
      const prefetchPromise = refsSlice.length && window.SupabaseSync?.prefetchDisplayUrlsWithCap
        ? window.SupabaseSync.prefetchDisplayUrlsWithCap(refsSlice, mobileFeed ? 8000 : 3500)
        : refsSlice.length && window.SupabaseSync?.prefetchDisplayUrls
          ? window.SupabaseSync.prefetchDisplayUrls(refsSlice)
          : Promise.resolve();
      const hydrateP = hydrateFeedImages(wrap);
      await Promise.race([
        prefetchPromise,
        new Promise((r) => setTimeout(r, mobileFeed ? 280 : 1200))
      ]);
      window.SupabaseSync?.patchImageSrcFromCache?.(wrap);
      await hydrateP;
      bindImageGenFeedImageRelayout();
      if (mobileFeed) {
        enforceMobileImageGenFeed();
        setFeedLayoutPending(wrap, false);
      } else {
        layoutImageGenFeedMasonry();
      }
      window.SupabaseSync?.patchImageSrcFromCache?.(wrap);
    })();
  }

  function bindImageGenFeedCardEvents(wrap) {
    if (!wrap) return;
    wrap.querySelectorAll('.imagegen-feed-card').forEach(card => {
      if (card.dataset.pending === '1') return;
      const feedId = card.dataset.feedId;
      card.querySelector('.imagegen-feed-thumb-btn')?.addEventListener('click', e => {
        e.stopPropagation();
        const btnEl = e.currentTarget;
        const imgEl = btnEl.querySelector('img');
        const rawRef = imgEl?.getAttribute('data-image-ref');
        const jobId = imgEl?.getAttribute('data-job-id');
        const src = imgEl?.src && !imgEl.src.startsWith('data:image/svg') ? imgEl.src : '';
        void (async () => {
          let url = src;
          if (rawRef) url = await resolveImageDisplayUrl(rawRef, jobId, card.dataset.feedId?.replace(/^wh_/, ''));
          if (url && typeof window.openLightbox === 'function') window.openLightbox(url);
        })();
      });
      card.querySelector('[data-feed-copy]')?.addEventListener('click', e => {
        e.stopPropagation();
        copyFeedPromptText(card.dataset.feedPrompt || '');
      });
      card.querySelector('[data-feed-fill-prompt]')?.addEventListener('click', e => {
        e.stopPropagation();
        fillFeedPromptToImageGen(card.dataset.feedPrompt || '');
      });
      card.addEventListener('click', e => {
        if (e.target.closest('.imagegen-feed-like')) return;
        if (e.target.closest('.imagegen-feed-thumb-btn')) return;
        if (e.target.closest('.imagegen-feed-save-btn')) return;
        if (e.target.closest('[data-delete-feed]')) return;
        if (e.target.closest('.imagegen-feed-mobile-actions')) return;
        if (window.MobileUI?.isMobile?.()) return;
        if (imageGenFeedTab === 'warehouse') {
          openImageGenPreview('warehouse', feedId.replace(/^wh_/, ''));
        } else if (imageGenFeedTab === 'community') {
          openImageGenPreview('community', feedId);
        }
      });
      card.querySelector('.imagegen-feed-like')?.addEventListener('click', e => {
        e.stopPropagation();
        likeCommunityPostOnly(feedId);
      });
    });
  }

  function formatExpiryLabel(c) {
    if (c.permanent || c.visibility === 'published') return '永久保留';
    if (!c.expiresAt) return '';
    const left = c.expiresAt - Date.now();
    if (left <= 0) return '已过期';
    const h = Math.ceil(left / 3600000);
    if (h < 24) return `约 ${h} 小时后清理`;
    return `约 ${Math.ceil(h / 24)} 天后清理`;
  }

  function bindUI() {
    document.getElementById('communitySearch')?.addEventListener('input', () => renderCommunity());
    document.querySelectorAll('[data-community-sort]').forEach(btn => {
      btn.addEventListener('click', () => {
        communitySort = btn.dataset.communitySort;
        document.querySelectorAll('[data-community-sort]').forEach(b => b.classList.toggle('active', b === btn));
        document.querySelectorAll('[data-imagegen-community-sort]').forEach(b => {
          b.classList.toggle('active', (b.dataset.imagegenCommunitySort || 'hot') === communitySort);
        });
        renderCommunity();
      });
    });
    document.querySelectorAll('[data-community-media]').forEach(btn => {
      btn.addEventListener('click', () => {
        communityMediaFilter = btn.dataset.communityMedia || 'all';
        document.querySelectorAll('[data-community-media]').forEach(b => {
          b.classList.toggle('active', b === btn);
        });
        document.querySelectorAll('[data-imagegen-community-media]').forEach(b => {
          b.classList.toggle('active', (b.dataset.imagegenCommunityMedia || 'all') === communityMediaFilter);
        });
        closeCommunitySidePanel();
        renderCommunity();
        if (document.getElementById('pageImageGen')?.classList.contains('active')) renderImageGenFeed();
      });
    });
    document.querySelectorAll('[data-community-scope]').forEach(btn => {
      btn.addEventListener('click', () => {
        communityScope = btn.dataset.communityScope || 'all';
        document.querySelectorAll('[data-community-scope]').forEach(b => {
          b.classList.toggle('active', b === btn);
        });
        document.querySelectorAll('[data-imagegen-community-scope]').forEach(b => {
          b.classList.toggle('active', (b.dataset.imagegenCommunityScope || 'all') === communityScope);
        });
        closeCommunitySidePanel();
        renderCommunity();
        if (document.getElementById('pageImageGen')?.classList.contains('active')) renderImageGenFeed();
      });
    });
    document.getElementById('communityNotifyBtn')?.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleNotifyPanel();
    });
    document.getElementById('communityNotifyMarkRead')?.addEventListener('click', markAllNotificationsRead);
    document.addEventListener('click', (e) => {
      const panel = document.getElementById('communityNotifyPanel');
      if (!panel || panel.classList.contains('hidden')) return;
      if (e.target.closest('#communityNotifyPanel, #communityNotifyBtn')) return;
      closeNotifyPanel();
    });
    document.getElementById('communitySideClose')?.addEventListener('click', closeCommunitySidePanel);
    document.getElementById('creationsSideClose')?.addEventListener('click', closeCreationsSidePanel);
    bindPublishToggle();
    const onCardPromptInput = () => syncCardPublishFromPrompt(getCardFormPromptText());
    document.getElementById('cardPrompt')?.addEventListener('input', onCardPromptInput);
    document.getElementById('floatingPromptText')?.addEventListener('input', onCardPromptInput);
    document.getElementById('imageGenPrompt')?.addEventListener('input', syncImageGenGenPublicFromPrompt);
    document.getElementById('userProfileClose')?.addEventListener('click', closeUserProfile);
    document.getElementById('userProfileBack')?.addEventListener('click', closeUserProfile);
    document.getElementById('userProfileOverlay')?.addEventListener('click', e => {
      if (e.target.id === 'userProfileOverlay') closeUserProfile();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && document.getElementById('userProfileOverlay')?.classList.contains('active')) {
        closeUserProfile();
      }
    });
    document.getElementById('imageGenSubmit')?.addEventListener('click', runImageGenDemo);
    document.getElementById('imageGenResolution')?.addEventListener('change', updateImageGenPricingUI);
    document.querySelectorAll('[data-feed-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        imageGenFeedTab = btn.dataset.feedTab;
        document.querySelectorAll('[data-feed-tab]').forEach(b => b.classList.toggle('active', b === btn));
        closeImageGenPreview();
        updateImageGenFeedHint();
        renderImageGenFeed();
      });
    });
    document.querySelectorAll('[data-imagegen-community-sort]').forEach(btn => {
      btn.addEventListener('click', () => {
        communitySort = btn.dataset.imagegenCommunitySort || 'hot';
        document.querySelectorAll('[data-imagegen-community-sort]').forEach(b => b.classList.toggle('active', b === btn));
        document.querySelectorAll('[data-community-sort]').forEach(b => {
          b.classList.toggle('active', (b.dataset.communitySort || 'hot') === communitySort);
        });
        renderImageGenFeed();
        if (document.getElementById('pageCommunity')?.classList.contains('active')) renderCommunity();
      });
    });
    document.querySelectorAll('[data-imagegen-community-scope]').forEach(btn => {
      btn.addEventListener('click', () => {
        communityScope = btn.dataset.imagegenCommunityScope || 'all';
        document.querySelectorAll('[data-imagegen-community-scope]').forEach(b => b.classList.toggle('active', b === btn));
        document.querySelectorAll('[data-community-scope]').forEach(b => {
          b.classList.toggle('active', (b.dataset.communityScope || 'all') === communityScope);
        });
        renderImageGenFeed();
        if (document.getElementById('pageCommunity')?.classList.contains('active')) renderCommunity();
      });
    });
    document.querySelectorAll('[data-imagegen-community-media]').forEach(btn => {
      btn.addEventListener('click', () => {
        communityMediaFilter = btn.dataset.imagegenCommunityMedia || 'all';
        document.querySelectorAll('[data-imagegen-community-media]').forEach(b => b.classList.toggle('active', b === btn));
        document.querySelectorAll('[data-community-media]').forEach(b => {
          b.classList.toggle('active', (b.dataset.communityMedia || 'all') === communityMediaFilter);
        });
        renderImageGenFeed();
        if (document.getElementById('pageCommunity')?.classList.contains('active')) renderCommunity();
      });
    });
    document.getElementById('imageGenPreviewClose')?.addEventListener('click', closeImageGenPreview);
    document.getElementById('imageGenWhGroup')?.addEventListener('change', e => {
      imageGenWhGroup = e.target.value || 'all';
      renderImageGenFeed();
    });
    document.getElementById('imageGenWhTag')?.addEventListener('change', e => {
      imageGenWhTag = e.target.value || 'all';
      renderImageGenFeed();
    });
    bindImageGenWarehouseFilterMobileUI();
    bindImageGenUpload();
    document.getElementById('imageGenRecoverBtn')?.addEventListener('click', () => {
      void recoverLostGenerationsManual();
    });
    document.getElementById('imageGenModel')?.addEventListener('change', updateImageGenPricingUI);
    document.getElementById('imageGenResolution')?.addEventListener('input', updateImageGenCostHint);
    document.getElementById('imageGenQuality')?.addEventListener('change', updateImageGenCostHint);
    document.getElementById('imageGenSize')?.addEventListener('change', updateImageGenCostHint);
    window.addEventListener('resize', () => {
      if (document.getElementById('pageCommunity')?.classList.contains('active')) {
        scheduleCommunityLayout('communityGrid');
      }
      if (document.getElementById('pageCreations')?.classList.contains('active')) {
        scheduleCommunityLayout('creationsGrid');
      }
      if (document.getElementById('pageImageGen')?.classList.contains('active')) {
        scheduleImageGenFeedLayout();
      }
      if (document.getElementById('userProfileOverlay')?.classList.contains('active')) {
        scheduleCommunityLayout('userProfileGrid');
      }
    });
    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      if (document.getElementById('userProfileOverlay')?.classList.contains('active')) closeUserProfile();
      else if (imageGenPreviewId) closeImageGenPreview();
      else if (communitySidePostId && document.getElementById('pageCreations')?.classList.contains('active')) closeCreationsSidePanel();
      else if (document.body.classList.contains('community-panel-open')) closeCommunitySidePanel();
    });
  }

  function onAppChange(app) {
    const fab = document.getElementById('fabNewBtn');
    if (fab) fab.classList.toggle('hidden-by-app', app !== 'warehouse');
    if (app === 'community') {
      if (window.__promptHubCards?.length) {
        ensureCommunityFromCards();
      }
      renderCommunity();
      const warmPosts = filterAndSortPosts(getAllCommunityPosts()).slice(0, 36);
      const warmImages = warmPosts.map((p) => p.image).filter(Boolean);
      const warmCards = warmPosts.map((p) => ({ id: p.sourceCardId || p.id, image: p.image })).filter((c) => c.image);
      if (warmImages.length && !window.SupabaseSync?.isLoggedIn?.() && window.SupabaseSync?.prefetchCommunityDisplayUrls) {
        void window.SupabaseSync.prefetchCommunityDisplayUrls(warmImages, 8000);
      } else if (warmCards.length && window.SupabaseSync?.prefetchCardsImages) {
        void window.SupabaseSync.prefetchCardsImages(warmCards, 8000);
      }
      requestAnimationFrame(() => {
        requestAnimationFrame(() => scheduleCommunityLayout('communityGrid'));
      });
    }
    if (app === 'creations') {
      void renderCreations();
      requestAnimationFrame(() => {
        requestAnimationFrame(() => scheduleCommunityLayout('creationsGrid'));
      });
    }
    if (app !== 'community') closeCommunitySidePanel();
    if (app !== 'creations') closeCreationsSidePanel();
    if (app !== 'imagegen') closeImageGenPreview();
    if (app === 'imagegen') {
      imageGenGenPublicSession = null;
      syncImageGenGenPublicUI();
      window.MobileUI?.initImageGenMobileView?.();
      pruneCreations();
      initImageGenForm();
      updateImageGenFeedHint();
      renderImageGenFeed();
      void window.PointsSystem?.refreshCreditsFromServer?.();
      window.PointsSystem?.updateCreditsUI?.();
    }
  }

  function init() {
    loadStores();
    bindUI();
    bindPublishToggle();
    onAppChange(localStorage.getItem('promptrepo_app_page') || 'warehouse');
  }

  function refreshImageGenCost() {
    updateImageGenCostHint();
  }

  function getCloudSlice() {
    return {
      communityPosts: communityPosts.filter(p => !p.isMock),
      creations: filterCreationsForCloud(creations),
      communityLikes: [...likedIds],
      communityFavorites: [...favIds],
      follows: [...follows],
      communityEvents,
      notifications
    };
  }

  function applyCloudSlice(payload) {
    if (!payload || typeof payload !== 'object') return;
    if (Array.isArray(payload.communityPosts)) {
      const normalizePost = (p) => {
        if (!p?.image || !window.SupabaseSync?.normalizeImageRef) return p;
        return { ...p, image: window.SupabaseSync.normalizeImageRef(p.image) };
      };
      const cloudPosts = payload.communityPosts.filter((p) => !p.isMock).map(normalizePost);
      const localPosts = communityPosts.filter((p) => !p.isMock);
      communityPosts = window.CloudSyncSafety?.mergeCommunityPostsList
        ? window.CloudSyncSafety.mergeCommunityPostsList(localPosts, cloudPosts)
        : (cloudPosts.length ? cloudPosts : localPosts);
      dedupeCommunityPosts({ persist: false });
      migrateCommunityAuthorIds();
      pruneOrphanFeatureData();
      if (window.__promptHubCards?.length) {
        reconcileCommunityWithCards(window.__promptHubCards);
      }
      saveJson(LS_COMMUNITY, communityPosts);
    }
    if (Array.isArray(payload.creations)) {
      const tomb = window.getDeletedCreationTombstones?.() || {};
      const normalizeCre = (c) => {
        if (!c?.image || !window.SupabaseSync?.normalizeImageRef) return c;
        return { ...c, image: window.SupabaseSync.normalizeImageRef(c.image) };
      };
      const cloudCreations = payload.creations
        .filter((c) => c && c.id != null && !tomb[String(c.id)])
        .filter((c) => !c.jobId || !isGenerationJobDeleted(c.jobId))
        .map(normalizeCre);
      const localCreations = filterCreationsForCloud(creations);
      const mergedCreations = window.CloudSyncSafety?.mergeCreationsList
        ? window.CloudSyncSafety.mergeCreationsList(localCreations, cloudCreations, tomb)
        : (cloudCreations.length ? cloudCreations : localCreations);
      creations = dedupeCreationsByJobId(mergedCreations);
      pruneCreations();
      saveJson(LS_CREATIONS, creations);
    }
    if (Array.isArray(payload.communityLikes)) {
      likedIds = new Set(payload.communityLikes);
      saveJson(LS_LIKES, [...likedIds]);
    }
    if (Array.isArray(payload.communityFavorites)) {
      favIds = new Set(payload.communityFavorites);
      saveJson(LS_FAVS, [...favIds]);
    }
    if (Array.isArray(payload.follows)) {
      follows = new Set(payload.follows.map(String));
      persistFollows();
    }
    if (Array.isArray(payload.communityEvents)) {
      communityEvents = payload.communityEvents.slice(-200);
      ingestCommunityEvents(communityEvents);
    }
    if (Array.isArray(payload.notifications)) {
      mergeNotifications(payload.notifications);
    }
    if (document.getElementById('pageCommunity')?.classList.contains('active')) {
      renderCommunity();
    }
    if (document.getElementById('pageCreations')?.classList.contains('active')) {
      renderCreations();
    }
    updateNotifyBadge();
  }

  window.FeatureDraft = {
    init,
    onAppChange,
    clearSensitiveLocalStateOnSignOut,
    reloadStores,
    refreshImageGenCost,
    syncCardToCommunity,
    removeCommunityByCardId,
    setPublishCheckbox,
    readPublishCheckbox,
    syncCardPublishFromPrompt,
    getCloudSlice,
    applyCloudSlice,
    reconcileCommunityWithCards,
    materializeCommunityFromCards,
    syncEligibleCardsToCommunity,
    refreshFeedsAfterCardsSync,
    ensureCommunityFromCards,
    renderCommunity,
    pruneOrphanFeatureData,
    hydrateFeedImages,
    resetMobileFeedGridStyles,
    enforceMobileImageGenFeed,
    closeImageGenFilterSheet,
    renderImageGenFeed,
    isDisplayableImage,
    scheduleImageGenFeedLayout: scheduleImageGenFeedLayout,
    scheduleLayout: scheduleCommunityLayout,
    onCardDeletedForGen,
    recoverLostGenerationsManual,
    recoverRecentGenerationJobs,
    renderCreations,
    scheduleCreationsLayout: () => scheduleCommunityLayout('creationsGrid'),
    fillFormPromptOnly,
    copyFeedPromptText,
    fillFeedPromptToImageGen,
    updateNotifyBadge,
    getCommunityPostsForTasks() {
      return communityPosts
        .filter(p => !p.isMock)
        .map(p => ({
          prompt: p.prompt || '',
          title: p.title || '',
          image: p.image || null
        }));
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
