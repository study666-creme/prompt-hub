(function () {
  const PLACEHOLDER = /YOUR_/;
  const BUCKET = 'card-images';
  const STORAGE_PREFIX = `storage://${BUCKET}/`;
  const SIGNED_TTL_SEC = 3600;
  const signedUrlCache = new Map();
  const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
  const MAX_SIDE = 1280;
  const JPEG_QUALITY = 0.8;
  /** 瀑布流/社区网格：签名时缩略，避免拉 2MB 原图 */
  const VARIANT_GRID = 'grid';
  const VARIANT_FULL = 'full';
  const GRID_SIGN_TRANSFORM = { width: 640, quality: 76, resize: 'contain' };
  const GRID_SIGN_CONCURRENCY = 8;

  function configured() {
    return !!(window.SUPABASE_URL && window.SUPABASE_ANON_KEY
      && !PLACEHOLDER.test(window.SUPABASE_URL)
      && !PLACEHOLDER.test(window.SUPABASE_ANON_KEY)
      && window.supabase?.createClient);
  }

  let client = null;
  let session = null;
  let onAuthChange = null;

  function getClient() {
    if (!configured()) return null;
    if (!client) {
      client = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true
        }
      });
    }
    return client;
  }

  function getUserId() {
    return session?.user?.id || null;
  }

  let ensureSessionPromise = null;

  async function ensureSession() {
    if (session?.access_token) {
      const expMs = session.expires_at ? session.expires_at * 1000 : 0;
      if (!expMs || expMs > Date.now() + 60_000) return session;
    }
    if (ensureSessionPromise) return ensureSessionPromise;
    ensureSessionPromise = (async () => {
      const sb = getClient();
      if (!sb) throw new Error('Supabase 未配置');
      const { data, error } = await sb.auth.getSession();
      if (error) throw error;
      if (!data.session?.user) throw new Error('登录已过期，请重新登录');
      session = data.session;
      return session;
    })();
    try {
      return await ensureSessionPromise;
    } finally {
      ensureSessionPromise = null;
    }
  }

  function isConfigured() { return configured(); }
  function isLoggedIn() { return !!session?.user; }
  function getSession() { return session; }

  /** 在 access_token 将过期时刷新，避免 UI 仍显示已登录但 API 返回「登录已过期」 */
  async function getValidAccessToken() {
    const sb = getClient();
    if (!sb) return null;
    if (!session?.access_token) {
      try {
        const { data } = await sb.auth.getSession();
        session = data?.session ?? null;
      } catch (e) {
        return null;
      }
    }
    if (!session?.access_token) return null;
    const exp = session.expires_at;
    const now = Math.floor(Date.now() / 1000);
    if (exp != null && exp - now < 120) {
      try {
        const { data, error } = await sb.auth.refreshSession();
        if (!error && data?.session) {
          session = data.session;
        }
      } catch (e) { /* 仍尝试用旧 token */ }
    }
    return session?.access_token || null;
  }
  function getUserEmail() { return session?.user?.email || ''; }

  function isDataUrl(str) {
    return typeof str === 'string' && str.startsWith('data:image/');
  }

  function formatError(err) {
    if (!err) return '未知错误';
    if (typeof err === 'string') return err;
    const msg = String(err.message || err.error_description || err.msg || err.error || '').trim();
    if (/bucket not found/i.test(msg)) {
      return msg + '（请在 Supabase 运行 supabase/storage.sql）';
    }
    if (/relation.*user_data|user_data.*does not exist/i.test(msg)) {
      return msg + '（请在 Supabase 运行 supabase/schema.sql）';
    }
    if (/row-level security|violates.*policy|permission denied/i.test(msg)) {
      return msg + '（若已运行过 SQL，请再运行 supabase/fix-policies.sql 后退出并重新登录）';
    }
    if (msg) return msg;
    if (err.error && typeof err.error !== 'string') return formatError(err.error);
    try { return JSON.stringify(err); } catch (e) { return '同步失败'; }
  }

  function isStorageUrl(str) {
    return isStorageRef(str);
  }

  function isStorageRef(str) {
    if (!str || typeof str !== 'string') return false;
    if (str.startsWith(STORAGE_PREFIX)) return true;
    if (!window.SUPABASE_URL) return false;
    const base = window.SUPABASE_URL.replace(/\/$/, '');
    return (
      str.startsWith(`${base}/storage/v1/object/public/${BUCKET}/`) ||
      str.startsWith(`${base}/storage/v1/object/sign/${BUCKET}/`) ||
      str.startsWith(`${base}/storage/v1/object/authenticated/${BUCKET}/`)
    );
  }

  function storagePathFromUrl(url) {
    if (!url || typeof url !== 'string') return null;
    if (url.startsWith(STORAGE_PREFIX)) return url.slice(STORAGE_PREFIX.length).split('?')[0];
    const markers = [
      `/storage/v1/object/public/${BUCKET}/`,
      `/storage/v1/object/sign/${BUCKET}/`,
      `/storage/v1/object/authenticated/${BUCKET}/`
    ];
    for (const marker of markers) {
      const i = url.indexOf(marker);
      if (i !== -1) return url.slice(i + marker.length).split('?')[0];
    }
    return null;
  }

  function storagePathFromRef(value) {
    return storagePathFromUrl(value);
  }

  function toStorageRef(path) {
    return STORAGE_PREFIX + path.replace(/^\//, '');
  }

  function publicUrlFromPath(path) {
    if (!path || !window.SUPABASE_URL) return null;
    const base = window.SUPABASE_URL.replace(/\/$/, '');
    return `${base}/storage/v1/object/public/${BUCKET}/${path.replace(/^\//, '')}`;
  }

  function isResolvableStorageRef(value) {
    return !!value && typeof value === 'string' && value.startsWith(STORAGE_PREFIX);
  }

  function normalizeImageRef(value) {
    if (!value || typeof value !== 'string') return value;
    const path = storagePathFromRef(value);
    if (path) return toStorageRef(path);
    return value;
  }

  function clearSignedUrlCache() {
    signedUrlCache.clear();
  }

  function signedCacheKey(path, variant) {
    const p = String(path || '').replace(/^\//, '');
    return variant === VARIANT_FULL ? p : `${p}@g640`;
  }

  function displayVariantFromOpts(opts) {
    if (!opts || typeof opts !== 'object') return VARIANT_GRID;
    return opts.variant === VARIANT_FULL ? VARIANT_FULL : VARIANT_GRID;
  }

  async function getSignedUrlForPath(path, opts) {
    const variant = displayVariantFromOpts(opts);
    const fileKey = path.replace(/^\//, '');
    const cacheKey = signedCacheKey(fileKey, variant);
    const cached = signedUrlCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now() + 120000) return cached.url;
    await ensureSession();
    const sb = getClient();
    const transform = variant === VARIANT_FULL ? undefined : GRID_SIGN_TRANSFORM;
    const signOpts = transform ? { transform } : undefined;
    try {
      const { data, error } = await sb.storage
        .from(BUCKET)
        .createSignedUrl(fileKey, SIGNED_TTL_SEC, signOpts);
      if (error) throw error;
      signedUrlCache.set(cacheKey, {
        url: data.signedUrl,
        expiresAt: Date.now() + (SIGNED_TTL_SEC - 120) * 1000
      });
      return data.signedUrl;
    } catch (e) {
      if (variant === VARIANT_GRID) {
        console.warn('[SupabaseSync] 缩略图签名失败，回退原图', fileKey, e);
        return getSignedUrlForPath(path, { variant: VARIANT_FULL });
      }
      throw e;
    }
  }

  function cardImageStoragePath(cardId) {
    const uid = getUserId();
    if (!uid || !cardId) return null;
    const base = String(cardId).replace(/[^a-zA-Z0-9_-]/g, '_');
    return `${uid}/${base}.jpg`;
  }

  function listImagePathCandidates(image, assetId) {
    const paths = [];
    const add = (p) => {
      const key = (p || '').replace(/^\//, '');
      if (key && !paths.includes(key)) paths.push(key);
    };
    add(storagePathFromRef(image));
    const canonical = cardImageStoragePath(assetId);
    if (canonical) add(canonical);
    const uid = getUserId();
    if (uid && assetId) {
      const stripped = String(assetId).replace(/^wh_/, '');
      if (stripped !== String(assetId)) add(`${uid}/${stripped}.jpg`);
    }
    return paths;
  }

  async function signPathViaCommunityApi(path, variant) {
    if (!window.PromptHubApi?.isConfigured?.() || !window.PromptHubApi.signCommunityMediaRef) return null;
    try {
      const r = await window.PromptHubApi.signCommunityMediaRef(toStorageRef(path), { variant });
      if (r.ok && r.data?.url) {
        const v = variant || VARIANT_GRID;
        signedUrlCache.set(signedCacheKey(path.replace(/^\//, ''), v), {
          url: r.data.url,
          expiresAt: Date.now() + (SIGNED_TTL_SEC - 120) * 1000
        });
        return r.data.url;
      }
    } catch (e) {
      console.warn('[SupabaseSync] community api sign failed', path, e);
    }
    return null;
  }

  async function signPathViaApi(path, variant) {
    if (!window.PromptHubApi?.isConfigured?.() || !window.PromptHubApi.signMediaRef) return null;
    try {
      const r = await window.PromptHubApi.signMediaRef(toStorageRef(path), { variant });
      if (r.ok && r.data?.url) {
        const v = variant || VARIANT_GRID;
        signedUrlCache.set(signedCacheKey(path.replace(/^\//, ''), v), {
          url: r.data.url,
          expiresAt: Date.now() + (SIGNED_TTL_SEC - 120) * 1000
        });
        return r.data.url;
      }
    } catch (e) {
      console.warn('[SupabaseSync] api sign failed', path, e);
    }
    return null;
  }

  async function resolvePathToUrl(path, variant, opts) {
    const v = variant || VARIANT_GRID;
    const communityFeed = opts?.communityFeed === true;
    if (!isLoggedIn() && communityFeed) {
      const guestUrl = await signPathViaCommunityApi(path, v);
      if (guestUrl) return guestUrl;
      return null;
    }
    try {
      return await getSignedUrlForPath(path, { variant: v });
    } catch (e) {
      console.warn('[SupabaseSync] signed url failed', path, e);
    }
    return signPathViaApi(path, v);
  }

  async function verifyImageUrl(url) {
    if (!url || url.startsWith('data:image/svg')) return false;
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img.naturalWidth > 0);
      img.onerror = () => resolve(false);
      img.src = url;
    });
  }

  async function findCardImageInStorage(cardId) {
    if (!isLoggedIn() || !cardId) return null;
    await ensureSession();
    const uid = getUserId();
    const sb = getClient();
    if (!sb || !uid) return null;
    const cid = String(cardId).replace(/^wh_/, '');
    try {
      const { data, error } = await sb.storage.from(BUCKET).list(uid, {
        limit: 200,
        sortBy: { column: 'name', order: 'asc' }
      });
      if (error || !data?.length) return null;
      const matches = data.filter((f) => {
        const name = f?.name || '';
        return name === `${cid}.jpg` || name.startsWith(`${cid}.`) || name.includes(cid);
      });
      for (const file of matches) {
        const path = `${uid}/${file.name}`;
        const ref = toStorageRef(path);
        const url = await resolveDisplayUrl(ref, { assetId: cardId });
        if (url && await verifyImageUrl(url)) return ref;
      }
    } catch (e) {
      console.warn('[SupabaseSync] list storage failed', e);
    }
    return null;
  }

  async function repairCardImageIfMissing(cardId, currentRef) {
    const found = await findCardImageInStorage(cardId);
    if (found && found !== currentRef) return found;
    if (currentRef) {
      const url = await resolveDisplayUrl(currentRef, { assetId: cardId });
      if (url && await verifyImageUrl(url)) return normalizeImageRef(currentRef);
    }
    return null;
  }

  function isCommunityFeedOpts(opts) {
    return !!(opts && typeof opts === 'object' && opts.communityFeed === true);
  }

  async function resolveDisplayUrl(image, opts) {
    if (!image || typeof image !== 'string') return image;
    if (isDataUrl(image) || image.startsWith('blob:')) return image;
    const assetId = opts && typeof opts === 'object' ? opts.assetId : undefined;
    const variant = displayVariantFromOpts(opts);
    const communityFeed = isCommunityFeedOpts(opts);
    const normalized = normalizeImageRef(image);
    const bucketPath = storagePathFromRef(normalized);
    if (bucketPath && (isLoggedIn() || communityFeed)) {
      const candidates = listImagePathCandidates(normalized, assetId);
      for (const path of candidates) {
        const cached = signedUrlCache.get(signedCacheKey(path.replace(/^\//, ''), variant));
        if (cached?.url && cached.expiresAt > Date.now() + 120000) return cached.url;
      }
      for (const path of candidates) {
        const url = await resolvePathToUrl(path, variant, { communityFeed });
        if (url) return url;
      }
      return null;
    }
    if (/^https?:\/\//i.test(image)) {
      const legacyPath = storagePathFromRef(image);
      if (legacyPath && isLoggedIn()) {
        return resolveDisplayUrl(toStorageRef(legacyPath), { assetId });
      }
      if (window.PromptHubApi?.fetchMediaAsBlobUrl) {
        const blobUrl = await window.PromptHubApi.fetchMediaAsBlobUrl(image);
        if (blobUrl) return blobUrl;
      }
      return image;
    }
    return image;
  }

  async function prefetchCommunityDisplayUrls(images, capMs) {
    if (isLoggedIn() || !window.PromptHubApi?.signCommunityMediaRef) return;
    const paths = [...new Set(
      (images || []).map((img) => storagePathFromRef(img)).filter(Boolean).map((p) => p.replace(/^\//, ''))
    )];
    if (!paths.length) return;
    const limit = Math.max(800, Number(capMs) || 6000);
    const started = Date.now();
    let i = 0;
    const concurrency = 4;
    async function worker() {
      while (i < paths.length && Date.now() - started < limit) {
        const path = paths[i++];
        if (signedUrlCache.get(signedCacheKey(path, VARIANT_GRID))?.expiresAt > Date.now() + 120000) continue;
        await signPathViaCommunityApi(path, VARIANT_GRID);
      }
    }
    await Promise.all(Array.from({ length: Math.min(concurrency, paths.length) }, () => worker()));
  }

  async function prefetchDisplayUrls(images) {
    if (!isLoggedIn()) return;
    const paths = [...new Set(
      (images || []).map(storagePathFromRef).filter(Boolean).map(p => p.replace(/^\//, ''))
    )];
    if (!paths.length) return;
    const pending = paths.filter(p => {
      const cached = signedUrlCache.get(signedCacheKey(p, VARIANT_GRID));
      return !(cached && cached.expiresAt > Date.now() + 120000);
    });
    if (!pending.length) return;
    await ensureSession();
    for (let i = 0; i < pending.length; i += GRID_SIGN_CONCURRENCY) {
      const batch = pending.slice(i, i + GRID_SIGN_CONCURRENCY);
      await Promise.all(
        batch.map((p) => getSignedUrlForPath(p, { variant: VARIANT_GRID }).catch(() => {}))
      );
    }
  }

  function getCachedDisplayUrl(image, assetIdOrOpts) {
    if (!image || typeof image !== 'string') return image;
    if (isDataUrl(image) || image.startsWith('blob:')) return image;
    const opts = typeof assetIdOrOpts === 'object' ? assetIdOrOpts : { assetId: assetIdOrOpts };
    const assetId = opts?.assetId;
    const variant = displayVariantFromOpts(opts);
    if (isLoggedIn() && (storagePathFromRef(image) || assetId)) {
      for (const path of listImagePathCandidates(image, assetId)) {
        const cached = signedUrlCache.get(signedCacheKey(path.replace(/^\//, ''), variant));
        if (cached?.url && cached.expiresAt > Date.now() + 120000) return cached.url;
      }
    }
    const path = storagePathFromRef(image);
    if (!path) {
      if (/^https?:\/\//i.test(image)) return image;
      return '';
    }
    const cached = signedUrlCache.get(signedCacheKey(path.replace(/^\//, ''), variant));
    if (cached?.url) return cached.url;
    if (/^https?:\/\//i.test(image)) return image;
    return '';
  }

  /** 按卡片 id 收集 canonical 路径，一次 batch 签完（避免列表每张图多次试探） */
  async function prefetchCardsImages(cards, capMs) {
    if (!isLoggedIn()) return;
    const pathSet = new Set();
    for (const c of cards || []) {
      if (!c?.image) continue;
      for (const p of listImagePathCandidates(c.image, c.id)) {
        pathSet.add(p.replace(/^\//, ''));
      }
    }
    if (!pathSet.size) return;
    const refs = [...pathSet].map((p) => toStorageRef(p));
    if (capMs != null && prefetchDisplayUrlsWithCap) {
      await prefetchDisplayUrlsWithCap(refs, capMs);
    } else {
      await prefetchDisplayUrls(refs);
    }
  }

  function imgPlaceholderSrc() {
    return 'data:image/svg+xml,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="4" height="3"><rect fill="#e4e4ea" width="4" height="3"/></svg>'
    );
  }

  function isPlaceholderImgSrc(src) {
    return !src || (typeof src === 'string' && src.includes('data:image/svg'));
  }

  function isResolvableDisplayUrl(url) {
    return !!(
      url &&
      typeof url === 'string' &&
      !url.startsWith(STORAGE_PREFIX) &&
      !isPlaceholderImgSrc(url)
    );
  }

  function setCardMediaLoadState(media, state) {
    if (!media) return;
    media.classList.remove('card-media--missing', 'card-media--load-failed');
    if (state === 'loading') {
      media.classList.add('is-loading');
      return;
    }
    media.classList.remove('is-loading');
    if (state === 'failed') media.classList.add('card-media--load-failed');
  }

  function safeImgSrc(image) {
    if (!image) return '';
    if (isDataUrl(image) || image.startsWith('blob:') || /^https?:\/\//i.test(image)) {
      return image;
    }
    if (isStorageRef(image)) {
      const cached = getCachedDisplayUrl(image);
      if (cached && !cached.startsWith(STORAGE_PREFIX)) return cached;
      return imgPlaceholderSrc();
    }
    return image;
  }

  function patchImageSrcFromCache(root) {
    const scope = root || document;
    scope.querySelectorAll('img[data-image-ref], img[data-storage-ref]').forEach((img) => {
      const ref = img.getAttribute('data-image-ref') || img.getAttribute('data-storage-ref');
      if (!ref) return;
      const cur = img.currentSrc || img.src || '';
      if (cur.startsWith('http') && !cur.includes('data:image/svg')) return;
      const assetId = img.closest('.card[data-id]')?.dataset?.id
        || img.closest('.card[data-post-id]')?.dataset?.postId
        || undefined;
      const url = getCachedDisplayUrl(ref, { assetId, variant: VARIANT_GRID });
      if (url && /^https?:\/\//i.test(url)) {
        const media = img.closest('.card-media, .imagegen-feed-media');
        if (media && !media.dataset.shineAt) media.dataset.shineAt = String(Date.now());
        if (media && !media.classList.contains('is-loading')) media.classList.add('is-loading');
        const done = () => {
          if (typeof window.finishCardMediaShine === 'function') window.finishCardMediaShine(media);
          else media?.classList.remove('is-loading');
        };
        if (img.complete && img.naturalWidth > 0 && img.src === url) done();
        else {
          img.addEventListener('load', done, { once: true });
          img.addEventListener('error', done, { once: true });
          img.src = url;
        }
      }
    });
  }

  async function prefetchDisplayUrlsWithCap(images, capMs) {
    const limit = Math.max(800, Number(capMs) || 5000);
    await Promise.race([
      prefetchDisplayUrls(images),
      new Promise((r) => setTimeout(r, limit))
    ]);
  }

  async function hydrateImageElements(root, opts) {
    const onlyMissing = opts?.onlyMissing === true;
    const scope = root || document;
    const imgs = [...scope.querySelectorAll('img[data-storage-ref], img[data-image-ref]')];
    imgs.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      const aVis = ar.top < window.innerHeight && ar.bottom > 0;
      const bVis = br.top < window.innerHeight && br.bottom > 0;
      if (aVis !== bVis) return aVis ? -1 : 1;
      return ar.top - br.top;
    });
    const concurrency = window.matchMedia('(max-width: 900px)').matches ? 8 : 6;
    let idx = 0;
    async function hydrateOne(img) {
      const ref = img.getAttribute('data-storage-ref') || img.getAttribute('data-image-ref');
      if (!ref) return;
      const media = img.closest('.card-media, .imagegen-feed-media');
      if (media?.classList.contains('imagegen-gen-pending')) return;
      const cur = img.currentSrc || img.src || '';
      if (onlyMissing && cur.startsWith('http') && !cur.includes('data:image/svg')) {
        media?.classList.remove('is-loading');
        return;
      }
      const assetId = img.closest('.card[data-id]')?.dataset?.id
        || img.closest('.card[data-post-id]')?.dataset?.postId
        || img.closest('.card[data-creation-id]')?.dataset?.creationId
        || img.closest('[data-feed-id]')?.dataset?.feedId?.replace(/^wh_/, '')
        || undefined;
      const communityFeed = !isLoggedIn() && !!img.closest('#communityGrid, #creationsGrid, #userProfileGrid');
      const resolveOpts = { assetId, variant: VARIANT_GRID, communityFeed };
      const cached = getCachedDisplayUrl(ref, { assetId, variant: VARIANT_GRID });
      if (cached && isResolvableDisplayUrl(cached)) {
        if (cur !== cached) {
          if (!media?.dataset.shineAt) media.dataset.shineAt = String(Date.now());
          setCardMediaLoadState(media, 'loading');
          img.src = cached;
          if (img.complete && img.naturalWidth > 0) {
            if (typeof window.finishCardMediaShine === 'function') window.finishCardMediaShine(media);
            else media?.classList.remove('is-loading');
          }
        } else if (!isPlaceholderImgSrc(cur)) {
          media?.classList.remove('is-loading');
        }
        return;
      }
      if (!media?.dataset.shineAt) media.dataset.shineAt = String(Date.now());
      setCardMediaLoadState(media, 'loading');
      if (!img.getAttribute('src') || isPlaceholderImgSrc(img.getAttribute('src'))) {
        img.src = imgPlaceholderSrc();
      }
      const endShine = () => {
        if (typeof window.finishCardMediaShine === 'function') window.finishCardMediaShine(media);
        else media?.classList.remove('is-loading');
      };
      try {
        const url = await resolveDisplayUrl(ref, resolveOpts);
        if (isResolvableDisplayUrl(url)) {
          const onFail = () => {
            if (media?.classList.contains('is-loading')) return;
            img.src = imgPlaceholderSrc();
            img.classList.remove('img-load-failed');
            setCardMediaLoadState(media, 'failed');
            endShine();
          };
          if (img.complete && img.src === url && img.naturalWidth > 0) endShine();
          else {
            img.addEventListener('load', () => {
              setCardMediaLoadState(media, 'loading');
              media?.classList.remove('card-media--load-failed');
              endShine();
            }, { once: true });
            img.addEventListener('error', onFail, { once: true });
            img.src = url;
          }
          img.classList.remove('img-load-failed');
          if (img.complete && img.naturalWidth > 0) endShine();
        } else if (!isPlaceholderImgSrc(cur) && cur.startsWith('http')) {
          endShine();
        } else {
          setCardMediaLoadState(media, 'loading');
        }
      } catch (e) {
        console.warn('[SupabaseSync] hydrate failed', ref, e);
        setCardMediaLoadState(media, 'loading');
      }
      if (!img.dataset.hydrateBound) {
        img.dataset.hydrateBound = '1';
        img.addEventListener('error', () => {
          if (media?.classList.contains('is-loading')) return;
          if (img.dataset.retryHydrate === '1') {
            setCardMediaLoadState(media, 'failed');
            return;
          }
          img.dataset.retryHydrate = '1';
          setCardMediaLoadState(media, 'loading');
          void resolveDisplayUrl(ref, resolveOpts).then((url) => {
            if (isResolvableDisplayUrl(url)) {
              img.src = url;
              img.classList.remove('img-load-failed');
              media?.classList.remove('card-media--load-failed');
            } else {
              setCardMediaLoadState(media, 'failed');
            }
          });
        });
      }
    }
    async function worker() {
      while (idx < imgs.length) {
        const i = idx++;
        await hydrateOne(imgs[i]);
      }
    }
    const workers = Array.from({ length: Math.min(concurrency, imgs.length) }, () => worker());
    await Promise.all(workers);
  }

  async function verifyStorageRef(ref, assetId, opts = {}) {
    if (!ref || !isStorageRef(ref)) return false;
    const attempts = opts.quick ? 1 : 3;
    const candidates = listImagePathCandidates(normalizeImageRef(ref), assetId);
    for (let round = 0; round < attempts; round++) {
      for (const path of candidates) {
        try {
          const url = await resolvePathToUrl(path.replace(/^\//, ''));
          if (url && await verifyImageUrl(url)) return true;
        } catch (e) {
          console.warn('[SupabaseSync] verifyStorageRef', path, e);
        }
      }
      if (round < attempts - 1) {
        await new Promise((r) => setTimeout(r, opts.quick ? 120 : 400 * (round + 1)));
      }
    }
    return false;
  }

  async function uploadStorageBlob(path, blob, opts = {}) {
    const maxAttempts = Math.max(1, opts.maxAttempts || 3);
    await ensureSession();
    const sb = getClient();
    if (!sb) throw new Error('未登录');
    const cleanPath = String(path || '').replace(/^\//, '');
    if (!cleanPath) throw new Error('图片路径无效');
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const { error } = await sb.storage.from(BUCKET).upload(cleanPath, blob, {
        contentType: 'image/jpeg',
        upsert: true,
        cacheControl: '3600'
      });
      if (error) {
        lastErr = error;
        if (attempt < maxAttempts) {
          await new Promise((r) => setTimeout(r, 350 * attempt));
          continue;
        }
        break;
      }
      const url = await resolvePathToUrl(cleanPath);
      if (url && await verifyImageUrl(url)) return toStorageRef(cleanPath);
      await new Promise((r) => setTimeout(r, 450));
      const retryUrl = await resolvePathToUrl(cleanPath);
      if (retryUrl && await verifyImageUrl(retryUrl)) return toStorageRef(cleanPath);
      lastErr = new Error('上传后校验失败');
      if (attempt < maxAttempts) await new Promise((r) => setTimeout(r, 350 * attempt));
    }
    throw lastErr || new Error('图片上传失败，请检查网络后重试');
  }

  async function persistGenerationImage(assetId, image) {
    if (!image || typeof image !== 'string') return image;
    if (!isLoggedIn()) return image;
    if (isStorageRef(image)) {
      const normalized = normalizeImageRef(image);
      if (await verifyStorageRef(normalized, assetId)) return normalized;
      return normalized;
    }
    await ensureSession();
    const id = String(assetId || Date.now());
    if (isDataUrl(image) || image.startsWith('blob:')) {
      return uploadGeneratedImage(id, image);
    }
    if (/^https?:\/\//i.test(image)) {
      try {
        const res = await fetch(image, { mode: 'cors' });
        if (res.ok) {
          const blob = await res.blob();
          return uploadGeneratedImage(id, blob);
        }
      } catch (e) {
        console.warn('[SupabaseSync] 生成图 CORS 拉取失败，保留 Worker 链接', e);
      }
      return image;
    }
    return image;
  }

  async function uploadGeneratedImage(assetId, source) {
    await ensureSession();
    const uid = getUserId();
    if (!uid || !assetId) throw new Error('未登录');
    const blob = await compressImage(source);
    const path = `${uid}/generated/${assetId}.jpg`;
    return uploadStorageBlob(path, blob);
  }

  function loadImageFromSource(source) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('图片无法读取'));
      if (typeof source === 'string') img.src = source;
      else if (source instanceof Blob) img.src = URL.createObjectURL(source);
      else reject(new Error('不支持的图片格式'));
    });
  }

  async function compressImage(source) {
    const img = await loadImageFromSource(source);
    if (typeof source !== 'string' && source instanceof Blob) {
      try { URL.revokeObjectURL(img.src); } catch (e) { /* ignore */ }
    }
    let w = img.naturalWidth;
    let h = img.naturalHeight;
    if (!w || !h) throw new Error('图片尺寸无效');
    const scale = Math.min(1, MAX_SIDE / Math.max(w, h));
    w = Math.round(w * scale);
    h = Math.round(h * scale);
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, w, h);
    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob(b => (b ? resolve(b) : reject(new Error('图片压缩失败'))), 'image/jpeg', JPEG_QUALITY);
    });
    if (blob.size > MAX_IMAGE_BYTES) {
      throw new Error('图片过大，请换一张较小的图（建议小于 5MB）');
    }
    return blob;
  }

  async function uploadImageGenRef(refId, source) {
    await ensureSession();
    const uid = getUserId();
    if (!uid || !refId) throw new Error('未登录或参考图无效');
    const blob = await compressImage(source);
    const path = `${uid}/imagegen/${refId}.jpg`;
    return uploadStorageBlob(path, blob);
  }

  async function uploadCardImage(cardId, source) {
    await ensureSession();
    const path = cardImageStoragePath(cardId);
    if (!path) throw new Error('未登录或卡片无效');
    const blob = await compressImage(source);
    return uploadStorageBlob(path, blob);
  }

  async function deleteCardImageByUrl(url) {
    if (!url || !isStorageRef(url)) return;
    const sb = getClient();
    const path = storagePathFromRef(url);
    if (!sb || !path) return;
    await sb.storage.from(BUCKET).remove([path]);
  }

  async function resolveCardImageForSave(cardId, imageValue, previousUrl) {
    if (!imageValue) {
      if (previousUrl && isStorageRef(previousUrl)) await deleteCardImageByUrl(previousUrl);
      return null;
    }
    if (!isLoggedIn()) return imageValue;
    if (isStorageRef(imageValue)) {
      const normalized = normalizeImageRef(imageValue);
      if (await verifyStorageRef(normalized, cardId)) return normalized;
      throw new Error('图片在云端已丢失，请重新上传后再保存');
    }
    if (isDataUrl(imageValue) || imageValue.startsWith('blob:')) {
      const url = await uploadCardImage(cardId, imageValue);
      if (previousUrl && previousUrl !== url && isStorageRef(previousUrl)) {
        await deleteCardImageByUrl(previousUrl);
      }
      return url;
    }
    if (/^https?:\/\//i.test(imageValue)) {
      try {
        const res = await fetch(imageValue, { mode: 'cors' });
        if (res.ok) {
          const blob = await res.blob();
          const url = await uploadCardImage(cardId, blob);
          if (previousUrl && previousUrl !== url && isStorageRef(previousUrl)) {
            await deleteCardImageByUrl(previousUrl);
          }
          return url;
        }
      } catch (e) {
        console.warn('[SupabaseSync] card image fetch failed', e);
      }
      throw new Error('远程图片下载失败，请换一张本地图片重试');
    }
    return imageValue;
  }

  async function resolveLocalImageFallback(cardId, currentImage) {
    if (currentImage && isDataUrl(currentImage)) return currentImage;
    if (currentImage && typeof currentImage === 'string' && currentImage.startsWith('blob:')) {
      return currentImage;
    }
    if (typeof window.getCardImageBackup === 'function') {
      const backup = await window.getCardImageBackup(cardId);
      if (backup && isDataUrl(backup)) return backup;
    }
    const sel = cardId ? `.card[data-id="${CSS.escape(String(cardId))}"] .card-img` : null;
    const img = sel ? document.querySelector(sel) : null;
    if (img?.src && isDataUrl(img.src)) return img.src;
    if (img?.src && /^https?:\/\//i.test(img.src) && img.naturalWidth > 8) {
      try {
        const res = await fetch(img.src, { mode: 'cors' });
        if (res.ok) return await res.blob();
      } catch (e) {
        console.warn('[SupabaseSync] fallback fetch card img failed', cardId, e);
      }
    }
    return null;
  }

  async function repairAllCardImagesBeforeSync(cards, opts = {}) {
    if (!isLoggedIn() || !Array.isArray(cards) || !cards.length) {
      return { fixed: 0, warnings: [] };
    }
    const capMs = Math.max(2000, Number(opts.capMs) || 8000);
    const deadline = Date.now() + capMs;
    const warnings = [];
    let fixed = 0;
    for (const card of cards) {
      if (Date.now() > deadline) {
        warnings.push('图片检查超时，已继续同步文字数据');
        break;
      }
      if (!card?.id) continue;
      let needsUpload = false;
      if (card.image && isDataUrl(card.image)) needsUpload = true;
      else if (card.image && isStorageRef(card.image)) {
        needsUpload = !(await verifyStorageRef(card.image, card.id, { quick: true }));
      } else if (!card.image) {
        needsUpload = true;
      }
      if (!needsUpload) continue;
      const source = await resolveLocalImageFallback(card.id, card.image);
      if (!source) {
        if (card.image && isStorageRef(card.image)) {
          const label = (card.title || card.prompt || card.id || '').toString().slice(0, 24);
          warnings.push(`「${label}」找不到可上传的图片源`);
        }
        continue;
      }
      try {
        card.image = await uploadCardImage(card.id, source);
        if (typeof window.clearCardImageBackup === 'function') {
          await window.clearCardImageBackup(card.id);
        }
        fixed += 1;
      } catch (e) {
        warnings.push(formatError(e));
      }
    }
    return { fixed, warnings: [...new Set(warnings)] };
  }

  async function prepareCardsForCloud(cards) {
    if (!isLoggedIn() || !Array.isArray(cards)) return { cards: cards || [], warnings: [] };
    const list = cards || [];
    const warnings = [];
    const out = await Promise.all(list.map(async (card) => {
      const copy = { ...card };
      if (copy.image && isStorageRef(copy.image)) {
        copy.image = normalizeImageRef(copy.image);
        let ok = await verifyStorageRef(copy.image, copy.id);
        if (!ok) {
          const repaired = await findCardImageInStorage(copy.id);
          if (repaired) {
            copy.image = repaired;
            ok = true;
          }
        }
        if (!ok) {
          const fallback = await resolveLocalImageFallback(copy.id, copy.image);
          if (fallback) {
            try {
              copy.image = await uploadCardImage(copy.id, fallback);
              if (typeof window.clearCardImageBackup === 'function') {
                await window.clearCardImageBackup(copy.id);
              }
              return copy;
            } catch (e) {
              warnings.push(formatError(e));
            }
          }
          const backup = typeof window.getCardImageBackup === 'function'
            ? await window.getCardImageBackup(copy.id)
            : null;
          if (backup && isDataUrl(backup)) {
            try {
              copy.image = await uploadCardImage(copy.id, backup);
              if (typeof window.clearCardImageBackup === 'function') {
                await window.clearCardImageBackup(copy.id);
              }
              return copy;
            } catch (e) {
              warnings.push(formatError(e));
            }
          }
          const label = (copy.title || copy.prompt || copy.id || '').toString().slice(0, 24);
          warnings.push(`「${label}」图片暂无法校验，已保留引用未从云端删除`);
        }
      } else if (copy.image && isDataUrl(copy.image)) {
        try {
          copy.image = await uploadCardImage(copy.id, copy.image);
          if (typeof window.clearCardImageBackup === 'function') {
            await window.clearCardImageBackup(copy.id);
          }
        } catch (e) {
          warnings.push(formatError(e));
        }
      }
      return copy;
    }));
    return { cards: out, warnings: [...new Set(warnings)] };
  }

  async function auditBrokenCardImages(cards) {
    if (!isLoggedIn() || !Array.isArray(cards)) return { broken: [], repaired: [] };
    const broken = [];
    const repaired = [];
    for (const card of cards) {
      if (!card?.image) continue;
      if (isDataUrl(card.image) || card.image.startsWith('blob:')) continue;
      if (!isStorageRef(card.image)) continue;
      const ok = await verifyStorageRef(card.image, card.id);
      if (ok) continue;
      let fixed = await findCardImageInStorage(card.id);
      if (!fixed && typeof window.getCardImageBackup === 'function') {
        const backup = await window.getCardImageBackup(card.id);
        if (backup && isDataUrl(backup)) {
          try {
            fixed = await uploadCardImage(card.id, backup);
            if (typeof window.clearCardImageBackup === 'function') {
              await window.clearCardImageBackup(card.id);
            }
          } catch (e) {
            console.warn('[SupabaseSync] backup re-upload failed', card.id, e);
          }
        }
      }
      if (fixed) {
        repaired.push({
          id: card.id,
          title: card.title || card.prompt || card.id,
          from: card.image,
          to: fixed
        });
        card.image = fixed;
      } else {
        broken.push({
          id: card.id,
          title: (card.title || card.prompt || card.id || '').toString().slice(0, 40)
        });
      }
    }
    return { broken, repaired };
  }

  async function init(callback) {
    onAuthChange = callback;
    const sb = getClient();
    if (!sb) return null;
    const { data } = await sb.auth.getSession();
    session = data.session;
    let initialHandled = false;
    sb.auth.onAuthStateChange((event, newSession) => {
      session = newSession;
      if (event === 'INITIAL_SESSION') {
        if (initialHandled) return;
        initialHandled = true;
      }
      if (typeof onAuthChange === 'function') onAuthChange(newSession, event);
    });
    if (!initialHandled && typeof onAuthChange === 'function') {
      initialHandled = true;
      onAuthChange(session, 'INITIAL_SESSION');
    }
    return session;
  }

  function formatAuthError(err) {
    if (!err) return '操作失败';
    const msg = String(err.message || err.error_description || err.msg || '').toLowerCase();
    if (/invalid login|invalid credentials|invalid email or password/.test(msg)) {
      return '邮箱或密码错误，请检查后重试';
    }
    if (/email not confirmed|confirm your email/.test(msg)) {
      return '邮箱尚未验证，请查收邮件中的确认链接（或在 Supabase 关闭邮箱验证）';
    }
    if (/user already registered|already been registered|already exists/.test(msg)) {
      return '该邮箱已注册，请直接登录';
    }
    if (/password should be at least|weak password|too short/.test(msg)) {
      return '密码至少 6 位，建议使用字母与数字组合';
    }
    if (/unable to validate email|invalid email/.test(msg)) {
      return '邮箱格式不正确';
    }
    if (/rate limit|too many requests/.test(msg)) {
      return '操作过于频繁，请稍后再试';
    }
    if (/network|fetch failed|failed to fetch/.test(msg)) {
      return '网络连接失败，请检查网络后重试';
    }
    if (/signup is disabled/.test(msg)) {
      return '注册功能未开启，请联系管理员';
    }
    if (/phone|sms|otp|invalid token|token has expired/.test(msg)) {
      if (/invalid token|token has expired|expired/.test(msg)) return '验证码错误或已过期';
      if (/phone provider|sms provider|phone auth/.test(msg)) {
        return '手机登录未在 Supabase 配置，请先在控制台开启 Phone 并配置短信服务';
      }
      if (/invalid phone/.test(msg)) return '手机号格式不正确';
    }
    return err.message || '操作失败，请稍后重试';
  }

  function normalizePhone(raw) {
    const s = String(raw || '').trim();
    if (!s) return null;
    if (s.startsWith('+')) {
      const digits = s.replace(/\D/g, '');
      return digits.length >= 10 ? '+' + digits : null;
    }
    const digits = s.replace(/\D/g, '');
    if (digits.length === 11 && digits.startsWith('1')) return '+86' + digits;
    if (digits.length === 13 && digits.startsWith('86')) return '+' + digits;
    return null;
  }

  function isPhoneAuthEnabled() {
    return window.AUTH_PHONE_ENABLED === true;
  }

  function isWeChatAuthEnabled() {
    return window.WECHAT_OAUTH_ENABLED === true && !!window.WECHAT_OAUTH_URL;
  }

  async function sendPhoneOtp(phone) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    const normalized = normalizePhone(phone);
    if (!normalized) throw new Error('请输入正确的 11 位中国大陆手机号');
    const { error } = await sb.auth.signInWithOtp({ phone: normalized });
    if (error) throw new Error(formatAuthError(error));
  }

  async function verifyPhoneOtp(phone, token) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    const normalized = normalizePhone(phone);
    if (!normalized) throw new Error('请输入正确的手机号');
    const code = String(token || '').trim();
    if (!/^\d{6}$/.test(code)) throw new Error('请输入 6 位数字验证码');
    const { data, error } = await sb.auth.verifyOtp({
      phone: normalized,
      token: code,
      type: 'sms'
    });
    if (error) throw new Error(formatAuthError(error));
    session = data.session;
    return data;
  }

  /** 已登录账号在任务中心绑定/验证手机号 */
  async function sendPhoneOtpForBind(phone) {
    await ensureSession();
    const sb = getClient();
    if (!sb || !session?.user) throw new Error('请先登录');
    const normalized = normalizePhone(phone);
    if (!normalized) throw new Error('请输入正确的 11 位中国大陆手机号');
    const { error } = await sb.auth.updateUser({ phone: normalized });
    if (error) throw new Error(formatAuthError(error));
  }

  async function verifyPhoneOtpForBind(phone, token) {
    await ensureSession();
    const sb = getClient();
    if (!sb || !session?.user) throw new Error('请先登录');
    const normalized = normalizePhone(phone);
    if (!normalized) throw new Error('请输入正确的手机号');
    const code = String(token || '').trim();
    if (!/^\d{6}$/.test(code)) throw new Error('请输入 6 位数字验证码');
    const { data, error } = await sb.auth.verifyOtp({
      phone: normalized,
      token: code,
      type: 'phone_change'
    });
    if (error) throw new Error(formatAuthError(error));
    session = data.session;
    return data;
  }

  async function signUp(email, password) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    const { data, error } = await sb.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: window.location.origin + window.location.pathname }
    });
    if (error) throw new Error(formatAuthError(error));
    if (data.session) session = data.session;
    return data;
  }

  async function signIn(email, password) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw new Error(formatAuthError(error));
    session = data.session;
    if (!session) {
      const { data: fresh } = await sb.auth.getSession();
      session = fresh.session;
    }
    return { ...data, session: session || data.session };
  }

  async function resetPassword(email) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    const { error } = await sb.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin + window.location.pathname
    });
    if (error) throw new Error(formatAuthError(error));
  }

  async function updatePassword(newPassword) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    await ensureSession();
    const { error } = await sb.auth.updateUser({ password: newPassword });
    if (error) throw new Error(formatAuthError(error));
  }

  async function signOut() {
    const sb = getClient();
    if (!sb) return;
    await sb.auth.signOut();
    session = null;
    clearSignedUrlCache();
  }

  async function pullCloudData() {
    await ensureSession();
    const sb = getClient();
    const uid = getUserId();
    if (!sb || !uid) return null;
    const { data, error } = await sb.from('user_data').select('data, updated_at').eq('user_id', uid).maybeSingle();
    if (error) throw error;
    return data?.data || null;
  }

  async function pushCloudData(payload, opts = {}) {
    await ensureSession();
    const sb = getClient();
    const uid = getUserId();
    if (!sb || !uid) return { warnings: [] };

    let cloudPayload = null;
    if (!opts.skipSafety && window.CloudSyncSafety?.validatePush) {
      try {
        const { data, error: pullErr } = await sb
          .from('user_data')
          .select('data')
          .eq('user_id', uid)
          .maybeSingle();
        if (pullErr) throw pullErr;
        cloudPayload = data?.data || null;
        const check = window.CloudSyncSafety.validatePush(payload, cloudPayload);
        if (!check.allow) {
          throw new Error(check.reason || '为保护云端数据，已取消同步');
        }
        if (check.merged) payload = check.merged;
      } catch (e) {
        if (e.message && e.message.includes('已阻止')) throw e;
        if (!opts.allowWithoutCloudCheck) {
          throw new Error('无法校验云端数据，已取消上传：' + formatError(e));
        }
      }
    }

    const imageSnapshot = (payload.cards || []).map((c) => ({
      id: c?.id,
      image: c?.image
    }));
    const { cards: preparedCards, warnings } = await prepareCardsForCloud(payload.cards || []);
    const restoredCards = (preparedCards || []).map((c) => {
      const snap = imageSnapshot.find((s) => String(s.id) === String(c.id));
      if (snap?.image && !c.image) return { ...c, image: snap.image };
      return c;
    });
    const prepared = {
      ...payload,
      cards: restoredCards,
      schemaVersion: window.CloudSyncSafety?.SCHEMA_VERSION || 2
    };
    const { error } = await sb.from('user_data').upsert({
      user_id: uid,
      data: prepared,
      updated_at: new Date().toISOString()
    }, { onConflict: 'user_id' });
    if (error) throw new Error(formatError(error));
    if (Array.isArray(prepared.cards)) payload.cards = prepared.cards;
    return { warnings, data: prepared };
  }

  window.SupabaseSync = {
    isConfigured,
    isLoggedIn,
    getUserId,
    getSession,
    getValidAccessToken,
    getUserEmail,
    isDataUrl,
    isStorageUrl,
    isStorageRef,
    storagePathFromRef,
    normalizeImageRef,
    resolveDisplayUrl,
    prefetchDisplayUrls,
    prefetchDisplayUrlsWithCap,
    prefetchCardsImages,
    prefetchCommunityDisplayUrls,
    patchImageSrcFromCache,
    getCachedDisplayUrl,
    VARIANT_GRID,
    VARIANT_FULL,
    safeImgSrc,
    publicUrlFromPath,
    repairAllCardImagesBeforeSync,
    resolveLocalImageFallback,
    uploadStorageBlob,
    auditBrokenCardImages,
    repairCardImageIfMissing,
    findCardImageInStorage,
    hydrateImageElements,
    persistGenerationImage,
    uploadGeneratedImage,
    clearSignedUrlCache,
    init,
    signUp,
    signIn,
    signOut,
    resetPassword,
    updatePassword,
    sendPhoneOtp,
    verifyPhoneOtp,
    sendPhoneOtpForBind,
    verifyPhoneOtpForBind,
    normalizePhone,
    isPhoneAuthEnabled,
    isWeChatAuthEnabled,
    formatAuthError,
    pullCloudData,
    pushCloudData,
    uploadCardImage,
    uploadImageGenRef,
    deleteCardImageByUrl,
    resolveCardImageForSave,
    prepareCardsForCloud,
    formatError
  };
})();
