(function () {
  const PLACEHOLDER = /YOUR_/;
  const BUCKET = 'card-images';
  const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
  const MAX_SIDE = 1600;
  const JPEG_QUALITY = 0.82;

  function configured() {
    return !!(window.SUPABASE_URL && window.SUPABASE_ANON_KEY
      && !PLACEHOLDER.test(window.SUPABASE_URL)
      && !PLACEHOLDER.test(window.SUPABASE_ANON_KEY)
      && window.supabase?.createClient);
  }

  let client = null;
  let session = null;
  let onAuthChange = null;

  function getClient() {
    if (!configured()) return null;
    if (!client) {
      client = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true
        }
      });
    }
    return client;
  }

  function getUserId() {
    return session?.user?.id || null;
  }

  function isConfigured() { return configured(); }
  function isLoggedIn() { return !!session?.user; }
  function getSession() { return session; }
  function getUserEmail() { return session?.user?.email || ''; }

  function isDataUrl(str) {
    return typeof str === 'string' && str.startsWith('data:image/');
  }

  function isStorageUrl(str) {
    if (!str || typeof str !== 'string') return false;
    if (!window.SUPABASE_URL) return false;
    const base = window.SUPABASE_URL.replace(/\/$/, '');
    return str.startsWith(`${base}/storage/v1/object/public/${BUCKET}/`);
  }

  function storagePathFromUrl(url) {
    if (!isStorageUrl(url)) return null;
    const marker = `/storage/v1/object/public/${BUCKET}/`;
    const i = url.indexOf(marker);
    if (i === -1) return null;
    return url.slice(i + marker.length).split('?')[0];
  }

  function loadImageFromSource(source) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('图片无法读取'));
      if (typeof source === 'string') img.src = source;
      else if (source instanceof Blob) img.src = URL.createObjectURL(source);
      else reject(new Error('不支持的图片格式'));
    });
  }

  async function compressImage(source) {
    const img = await loadImageFromSource(source);
    if (typeof source !== 'string' && source instanceof Blob) {
      try { URL.revokeObjectURL(img.src); } catch (e) { /* ignore */ }
    }
    let w = img.naturalWidth;
    let h = img.naturalHeight;
    if (!w || !h) throw new Error('图片尺寸无效');
    const scale = Math.min(1, MAX_SIDE / Math.max(w, h));
    w = Math.round(w * scale);
    h = Math.round(h * scale);
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, w, h);
    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob(b => (b ? resolve(b) : reject(new Error('图片压缩失败'))), 'image/jpeg', JPEG_QUALITY);
    });
    if (blob.size > MAX_IMAGE_BYTES) {
      throw new Error('图片过大，请换一张较小的图（建议小于 5MB）');
    }
    return blob;
  }

  async function uploadCardImage(cardId, source) {
    const sb = getClient();
    const uid = getUserId();
    if (!sb || !uid || !cardId) throw new Error('未登录或卡片无效');
    const blob = await compressImage(source);
    const path = `${uid}/${cardId}.jpg`;
    const { error } = await sb.storage.from(BUCKET).upload(path, blob, {
      contentType: 'image/jpeg',
      upsert: true,
      cacheControl: '3600'
    });
    if (error) throw error;
    const { data } = sb.storage.from(BUCKET).getPublicUrl(path);
    return data.publicUrl;
  }

  async function deleteCardImageByUrl(url) {
    if (!url || !isStorageUrl(url)) return;
    const sb = getClient();
    const path = storagePathFromUrl(url);
    if (!sb || !path) return;
    await sb.storage.from(BUCKET).remove([path]);
  }

  async function resolveCardImageForSave(cardId, imageValue, previousUrl) {
    if (!imageValue) {
      if (previousUrl && isStorageUrl(previousUrl)) await deleteCardImageByUrl(previousUrl);
      return null;
    }
    if (!isLoggedIn()) return imageValue;
    if (isStorageUrl(imageValue)) return imageValue;
    if (isDataUrl(imageValue) || imageValue.startsWith('blob:')) {
      const url = await uploadCardImage(cardId, imageValue);
      if (previousUrl && previousUrl !== url) await deleteCardImageByUrl(previousUrl);
      return url;
    }
    return imageValue;
  }

  async function prepareCardsForCloud(cards) {
    if (!isLoggedIn() || !Array.isArray(cards)) return cards;
    const out = [];
    for (const card of cards) {
      const copy = { ...card };
      if (copy.image && isDataUrl(copy.image)) {
        copy.image = await uploadCardImage(copy.id, copy.image);
      }
      out.push(copy);
    }
    return out;
  }

  async function init(callback) {
    onAuthChange = callback;
    const sb = getClient();
    if (!sb) return null;
    const { data } = await sb.auth.getSession();
    session = data.session;
    sb.auth.onAuthStateChange((_event, newSession) => {
      session = newSession;
      if (typeof onAuthChange === 'function') onAuthChange(newSession);
    });
    if (typeof onAuthChange === 'function') onAuthChange(session);
    return session;
  }

  async function signUp(email, password) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    const { data, error } = await sb.auth.signUp({ email, password });
    if (error) throw error;
    return data;
  }

  async function signIn(email, password) {
    const sb = getClient();
    if (!sb) throw new Error('Supabase 未配置');
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    session = data.session;
    return data;
  }

  async function signOut() {
    const sb = getClient();
    if (!sb) return;
    await sb.auth.signOut();
    session = null;
  }

  async function pullCloudData() {
    const sb = getClient();
    const uid = getUserId();
    if (!sb || !uid) return null;
    const { data, error } = await sb.from('user_data').select('data, updated_at').eq('user_id', uid).maybeSingle();
    if (error) throw error;
    return data?.data || null;
  }

  async function pushCloudData(payload) {
    const sb = getClient();
    const uid = getUserId();
    if (!sb || !uid) return;
    const prepared = { ...payload, cards: await prepareCardsForCloud(payload.cards || []) };
    const { error } = await sb.from('user_data').upsert({
      user_id: uid,
      data: prepared,
      updated_at: new Date().toISOString()
    }, { onConflict: 'user_id' });
    if (error) throw error;
    if (Array.isArray(prepared.cards)) {
      payload.cards = prepared.cards;
    }
  }

  window.SupabaseSync = {
    isConfigured,
    isLoggedIn,
    getSession,
    getUserEmail,
    isDataUrl,
    isStorageUrl,
    init,
    signUp,
    signIn,
    signOut,
    pullCloudData,
    pushCloudData,
    uploadCardImage,
    deleteCardImageByUrl,
    resolveCardImageForSave,
    prepareCardsForCloud
  };
})();
